const { VirtualCurrency, UserWallet, Transaction, User } = require('../models');
const { sequelize } = require('../database/index');
const crypto = require('crypto');
const logger = require('../utils/logger');

/**
 * Service pour le nouveau système économique TwitCoins
 * Système officiel sans minage, basé uniquement sur les achats
 */
class NewEconomyService {
  /**
   * Portefeuille utilisateur + devise : findOrCreate (évite doublons et courses).
   */
  static async _findOrCreateWallet(userId, currencyId, transaction = null) {
    const [wallet] = await UserWallet.findOrCreate({
      where: { userId, currencyId },
      defaults: {
        balance: 0,
        totalEarned: 0,
        totalSpent: 0,
        totalPurchased: 0,
        loyaltyPoints: 0
      },
      transaction
    });
    return wallet;
  }

  /**
   * Crée un portefeuille pour chaque monnaie virtuelle active (appel à l'inscription ou backfill).
   */
  static async ensureWalletsForUser(userId, externalTransaction = null) {
    if (!userId) return { ensured: 0 };
    const currencies = await VirtualCurrency.findAll({
      where: { isActive: true },
      attributes: ['id'],
      transaction: externalTransaction
    });
    for (const c of currencies) {
      await this._findOrCreateWallet(userId, c.id, externalTransaction);
    }
    logger.info(`[economy] Portefeuilles assurés pour user ${userId} (${currencies.length} devise(s))`);
    return { ensured: currencies.length };
  }

  /**
   * Obtenir les packages d'achat disponibles
   */
  static async getPurchasePackages(currencyId) {
    try {
      const currency = await VirtualCurrency.findByPk(currencyId);
      if (!currency || !currency.isActive) {
        throw new Error('Cryptomonnaie non disponible');
      }

      // Packages de base avec variations économiques
      const basePackages = [
        { id: 'small', name: 'Pack Starter', coins: 100, price: 0.99, popular: false },
        { id: 'medium', name: 'Pack Popular', coins: 500, price: 4.99, popular: true },
        { id: 'large', name: 'Pack Premium', coins: 1200, price: 9.99, popular: false },
        { id: 'mega', name: 'Pack Elite', coins: 2500, price: 19.99, popular: false },
        { id: 'ultimate', name: 'Pack Ultimate', coins: 6000, price: 49.99, popular: false },
        // Nouveaux packages haute valeur
        { id: 'vip_100', name: 'Pack VIP 100€', coins: 10000, price: 100.00, popular: false },
        { id: 'vip_500', name: 'Pack VIP 500€', coins: 50000, price: 500.00, popular: false },
        { id: 'vip_1000', name: 'Pack VIP 1000€', coins: 100000, price: 1000.00, popular: false },
        { id: 'vip_10000', name: 'Pack VIP 10000€', coins: 1000000, price: 10000.00, popular: false }
      ];

      // Appliquer les bonus et variations économiques
      const packages = basePackages.map(pkg => {
        const finalPrice = pkg.price * parseFloat(currency.currentMultiplier);
        const bonusCoins = Math.floor(pkg.coins * parseFloat(currency.purchaseBonus));
        
        return {
          ...pkg,
          originalPrice: pkg.price,
          currentPrice: finalPrice.toFixed(2),
          bonusCoins: bonusCoins,
          totalCoins: pkg.coins + bonusCoins,
          savings: bonusCoins > 0 ? Math.round((bonusCoins / pkg.coins) * 100) : 0,
          pricePerCoin: (finalPrice / (pkg.coins + bonusCoins)).toFixed(4)
        };
      });

      return {
        packages,
        economicStatus: {
          trend: currency.economicTrend,
          multiplier: parseFloat(currency.currentMultiplier),
          bonus: parseFloat(currency.purchaseBonus) * 100
        }
      };
    } catch (error) {
      logger.error('Erreur lors de la récupération des packages:', error);
      throw error;
    }
  }

  /**
   * Acheter des TwitCoins
   */
  static async purchaseCoins(userId, currencyId, packageId, paymentMethod) {
    const transaction = await sequelize.transaction();
    
    try {
      const currency = await VirtualCurrency.findByPk(currencyId);
      if (!currency || !currency.isActive) {
        throw new Error('Cryptomonnaie non disponible');
      }

      const { packages } = await this.getPurchasePackages(currencyId);
      const selectedPackage = packages.find(pkg => pkg.id === packageId);
      
      if (!selectedPackage) {
        throw new Error('Package non trouvé');
      }

      const wallet = await this._findOrCreateWallet(userId, currencyId, transaction);

      // Créer la transaction d'achat
      const transactionHash = crypto.randomBytes(32).toString('hex');
      
      const purchaseTransaction = await Transaction.create({
        transactionHash,
        fromUserId: null, // Achat système
        toUserId: userId,
        currencyId,
        amount: selectedPackage.totalCoins,
        amountInEur: parseFloat(selectedPackage.currentPrice),
        type: 'PURCHASE',
        status: 'COMPLETED',
        fee: 0,
        description: `Achat ${selectedPackage.name} - ${selectedPackage.totalCoins} TWC`,
        metadata: {
          packageId: selectedPackage.id,
          packageName: selectedPackage.name,
          baseCoins: selectedPackage.coins,
          bonusCoins: selectedPackage.bonusCoins,
          paymentMethod: paymentMethod,
          economicMultiplier: currency.currentMultiplier,
          purchaseBonus: currency.purchaseBonus
        },
        confirmedAt: new Date()
      }, { transaction });

      // Mettre à jour le portefeuille
      const newBalance = parseFloat(wallet.balance) + selectedPackage.totalCoins;
      const newTotalPurchased = parseFloat(wallet.totalPurchased) + selectedPackage.totalCoins;
      const newLoyaltyPoints = wallet.loyaltyPoints + Math.floor(selectedPackage.totalCoins / 100);

      await wallet.update({
        balance: newBalance,
        totalEarned: parseFloat(wallet.totalEarned) + selectedPackage.totalCoins,
        totalPurchased: newTotalPurchased,
        loyaltyPoints: newLoyaltyPoints,
        lastPurchaseDate: new Date()
      }, { transaction });

      // Mettre à jour les statistiques de la cryptomonnaie
      await currency.update({
        circulatingSupply: parseFloat(currency.circulatingSupply) + selectedPackage.totalCoins,
        volume24h: parseFloat(currency.volume24h) + parseFloat(selectedPackage.currentPrice)
      }, { transaction });

      // Mettre à jour les métriques économiques
      await this.updateEconomicMetrics(currencyId, selectedPackage.currentPrice, transaction);

      await transaction.commit();

      logger.info(`Achat effectué: ${selectedPackage.totalCoins} TWC pour ${selectedPackage.currentPrice}€ par l'utilisateur ${userId}`);
      
      return {
        transaction: purchaseTransaction,
        wallet: wallet,
        package: selectedPackage
      };
    } catch (error) {
      await transaction.rollback();
      logger.error('Erreur lors de l\'achat:', error);
      throw error;
    }
  }

  /**
   * Obtenir les données du portefeuille d'un utilisateur
   * @param {string|null} [dbTransaction] — transaction Sequelize optionnelle (cohérence avec achat abonnement)
   */
  static async getUserWallet(currencyId, userId, dbTransaction = null) {
    try {
      // Obtenir les informations de la cryptomonnaie
      const currency = await VirtualCurrency.findByPk(currencyId, { transaction: dbTransaction });
      if (!currency || !currency.isActive) {
        throw new Error('Cryptomonnaie non disponible');
      }

      const wallet = await this._findOrCreateWallet(userId, currencyId, dbTransaction);

      return {
        wallet: {
          id: wallet.id,
          balance: parseFloat(wallet.balance) || 0,
          totalEarned: parseFloat(wallet.totalEarned) || 0,
          totalSpent: parseFloat(wallet.totalSpent) || 0,
          totalPurchased: parseFloat(wallet.totalPurchased) || 0,
          loyaltyPoints: parseFloat(wallet.loyaltyPoints) || 0,
          lastPurchaseDate: wallet.lastPurchaseDate
        },
        currency: {
          id: currency.id,
          name: currency.name,
          symbol: currency.symbol,
          currentPrice: parseFloat(currency.currentPrice) || 0,
          basePrice: parseFloat(currency.basePrice) || 0,
          multiplier: parseFloat(currency.currentMultiplier) || 1,
          trend: currency.economicTrend || 'stable',
          volume24h: parseFloat(currency.volume24h) || 0,
          marketCap: parseFloat(currency.marketCap) || 0,
          priceChange24h: parseFloat(currency.priceChange24h) || 0
        }
      };
    } catch (error) {
      logger.error('Erreur lors de la récupération du portefeuille:', error);
      throw error;
    }
  }

  /**
   * Dépenser des TwitCoins
   */
  static async spendCoins(userId, currencyId, amount, itemType, itemId, description, externalTransaction = null) {
    const transaction = externalTransaction || await sequelize.transaction();
    const shouldCommit = !externalTransaction; // Ne commit que si on a créé notre propre transaction
    
    try {
      const wallet = await this._findOrCreateWallet(userId, currencyId, transaction);

      if (parseFloat(wallet.balance) < amount) {
        throw new Error('Solde insuffisant');
      }

      // Créer UNE SEULE transaction : utilisateur -> TwitNinf
      const transactionHash = crypto.randomBytes(32).toString('hex');
      const officialAccountId = '01837802-c2ae-4de0-9471-7a9b642afde2';
      
      const transferTransaction = await Transaction.create({
        transactionHash: transactionHash,
        fromUserId: userId, // L'utilisateur qui achète
        toUserId: officialAccountId, // TwitNinf qui reçoit le paiement
        currencyId,
        amount: amount, // Montant positif (300 TWC transférés)
        amountInEur: 0,
        type: 'TRANSFER',
        status: 'COMPLETED',
        fee: 0,
        description: `Achat: ${description}`,
        metadata: {
          itemType: itemType,
          itemId: itemId,
          spendingCategory: this.getSpendingCategory(itemType),
          transactionSubType: 'PURCHASE'
        },
        confirmedAt: new Date()
      }, { transaction });

      // Mettre à jour le portefeuille de l'utilisateur (débit)
      await wallet.update({
        balance: parseFloat(wallet.balance) - amount,
        totalSpent: parseFloat(wallet.totalSpent) + amount
      }, { transaction });

      // Créditer le portefeuille du compte officiel TwitNinf
      const officialWallet = await UserWallet.findOne({
        where: {
          userId: officialAccountId,
          currencyId: currencyId
        }
      });

      if (officialWallet) {
        await officialWallet.update({
          balance: parseFloat(officialWallet.balance) + amount,
          totalPurchased: parseFloat(officialWallet.totalPurchased) + amount
        }, { transaction });
      } else {
        // Créer le portefeuille officiel s'il n'existe pas
        await UserWallet.create({
          userId: officialAccountId,
          currencyId: currencyId,
          balance: amount,
          totalPurchased: amount,
          totalSpent: 0,
          loyaltyPoints: 0
        }, { transaction });
      }

      // Mettre à jour l'offre en circulation
      const currency = await VirtualCurrency.findByPk(currencyId, { transaction });
      await currency.update({
        circulatingSupply: parseFloat(currency.circulatingSupply) - amount
      }, { transaction });

      if (shouldCommit) {
        await transaction.commit();
      }

      logger.info(`Transfert effectué: ${amount} TWC par l'utilisateur ${userId} vers TwitNinf pour ${description}`);
      
      return {
        transaction: transferTransaction,
        transactionHash: transactionHash, // Hash de la transaction unique
        wallet: wallet,
        remainingBalance: parseFloat(wallet.balance) - amount
      };
    } catch (error) {
      if (shouldCommit) {
        await transaction.rollback();
      }
      logger.error('Erreur lors de la dépense:', error);
      throw error;
    }
  }

  /**
   * Distribuer une récompense (REWARD) depuis le compte officiel TwitNinf
   */
  static async rewardUser(userId, currencyId, amount, description = 'Récompense tweet', externalTransaction = null) {
    const transaction = externalTransaction || await sequelize.transaction();
    const shouldCommit = !externalTransaction;
    const officialAccountId = '01837802-c2ae-4de0-9471-7a9b642afde2';

    try {
      // 1. Débiter le compte officiel TwitNinf
      const officialWallet = await UserWallet.findOne({
        where: { userId: officialAccountId, currencyId },
        transaction
      });

      if (!officialWallet || parseFloat(officialWallet.balance) < amount) {
        logger.error(`❌ Réserve TwitNinf insuffisante (${officialWallet?.balance || 0} TWC). Paiement refusé.`);
        throw new Error('Réserve système insuffisante pour effectuer le paiement de monétisation.');
      }

      await officialWallet.update({
        balance: parseFloat(officialWallet.balance) - amount,
        totalSpent: parseFloat(officialWallet.totalSpent) + amount
      }, { transaction });

      // 2. Créditer l'utilisateur
      let userWallet = await this._findOrCreateWallet(userId, currencyId, transaction);

      await userWallet.update({
        balance: parseFloat(userWallet.balance) + amount,
        totalEarned: parseFloat(userWallet.totalEarned) + amount,
        loyaltyPoints: userWallet.loyaltyPoints + Math.floor(amount)
      }, { transaction });

      // 3. Créer la transaction REWARD
      const transactionHash = crypto.randomBytes(32).toString('hex');
      const rewardTransaction = await Transaction.create({
        transactionHash,
        fromUserId: officialAccountId, // Provient de TwitNinf
        toUserId: userId,
        currencyId,
        amount,
        amountInEur: 0,
        type: 'REWARD',
        status: 'COMPLETED',
        description,
        confirmedAt: new Date()
      }, { transaction });

      // 4. Mettre à jour l'offre en circulation
      const currency = await VirtualCurrency.findByPk(currencyId, { transaction });
      await currency.update({
        circulatingSupply: parseFloat(currency.circulatingSupply) + amount
      }, { transaction });

      if (shouldCommit) await transaction.commit();

      logger.info(`🎁 Récompense distribuée: ${amount} TWC de TwitNinf vers ${userId}`);
      return { success: true, reward: amount, transaction: rewardTransaction };

    } catch (error) {
      if (shouldCommit) await transaction.rollback();
      logger.error('Erreur lors de la distribution de récompense:', error);
      throw error;
    }
  }

  /**
   * Mettre à jour les métriques économiques
   */
  static async updateEconomicMetrics(currencyId, purchaseAmount, transaction = null) {
    try {
      const currency = await VirtualCurrency.findByPk(currencyId);
      
      // Calculer les tendances basées sur les achats récents
      const recentPurchases = await Transaction.findAll({
        where: {
          currencyId,
          type: 'PURCHASE',
          createdAt: {
            [require('sequelize').Op.gte]: new Date(Date.now() - 24 * 60 * 60 * 1000) // 24h
          }
        },
        order: [['createdAt', 'DESC']],
        limit: 100
      });

      const totalVolume24h = recentPurchases.reduce((sum, tx) => sum + parseFloat(tx.amountInEur), 0);
      const avgPurchaseSize = totalVolume24h / Math.max(recentPurchases.length, 1);

      // Ajuster le multiplicateur économique
      let newMultiplier = parseFloat(currency.currentMultiplier);
      let newTrend = currency.economicTrend;
      let newBonus = parseFloat(currency.purchaseBonus);

      // Système économique réaliste avec offre/demande et volatilité
      const baseVolume = 1000; // Volume de référence
      const currentMultiplier = parseFloat(currency.currentMultiplier);
      const currentPrice = parseFloat(currency.currentPrice);
      
      // Calculer l'impact proportionnel
      let multiplierImpact = 0;
      let bonusImpact = 0;
      
      if (totalVolume24h > 0) {
        // 1. IMPACT DE L'OFFRE ET DE LA DEMANDE
        const supplyDemandRatio = totalVolume24h / Math.max(currency.circulatingSupply, 1);
        const logVolume = Math.log10(Math.max(totalVolume24h, 1));
        const logBase = Math.log10(baseVolume);
        const volumeImpact = (logVolume - logBase) * 0.03; // Impact réduit pour plus de réalisme
        
        // 2. IMPACT IMMÉDIAT DE L'ACHAT (proportionnel avec volatilité)
        let purchaseImpact = 0;
        if (purchaseAmount > 0) {
          const logPurchase = Math.log10(purchaseAmount);
          const logPurchaseBase = Math.log10(100);
          const basePurchaseImpact = (logPurchase - logPurchaseBase) * 0.015;
          
          // Volatilité basée sur la taille de l'achat par rapport au volume total
          const volatilityFactor = Math.min(2.0, Math.max(0.1, purchaseAmount / Math.max(totalVolume24h, 1)));
          purchaseImpact = basePurchaseImpact * volatilityFactor;
        }
        
        // 3. EFFET DE MARCHÉ (bulle/déflation)
        const marketEffect = this.calculateMarketEffect(currentMultiplier, totalVolume24h, recentPurchases.length);
        
        // 4. CYCLES ÉCONOMIQUES (boom/bust)
        const cycleEffect = this.calculateEconomicCycle(currency);
        
        // 5. ÉVÉNEMENTS ALÉATOIRES (news, spéculation)
        const randomEvent = this.calculateRandomEvent();
        
        // 6. STABILISATION NATURELLE (retour à la moyenne)
        const meanReversion = this.calculateMeanReversion(currentMultiplier, totalVolume24h);
        
        // Calculer l'impact total
        const totalImpact = (volumeImpact + purchaseImpact + marketEffect + cycleEffect + randomEvent + meanReversion);
        
        // Appliquer l'impact avec facteur de réalisme
        multiplierImpact = totalImpact * 0.8; // Facteur de réalisme
        bonusImpact = -totalImpact * 0.4; // Bonus inverse proportionnel
        
        // 7. EFFET DE LIQUIDITÉ (plus il y a d'achats, moins l'impact est fort)
        const liquidityFactor = Math.min(1.0, Math.max(0.3, 1.0 - (recentPurchases.length / 50)));
        multiplierImpact *= liquidityFactor;
        bonusImpact *= liquidityFactor;
        
      } else {
        // Pas d'achats = déflation naturelle
        const deflationFactor = 0.02;
        const currentMultiplier = parseFloat(currency.currentMultiplier);
        const targetMultiplier = 0.7; // Cible de déflation
        const deflationImpact = (targetMultiplier - currentMultiplier) * deflationFactor;
        
        multiplierImpact = deflationImpact;
        bonusImpact = 0.1; // Bonus pour encourager les achats
      }
      
      // Appliquer les changements avec limites réalistes
      newMultiplier = Math.max(0.1, newMultiplier + multiplierImpact); // Minimum 0.1x
      newBonus = Math.max(-0.8, Math.min(2.0, newBonus + bonusImpact)); // Entre -80% et +200%
      
      // Déterminer la tendance
      if (multiplierImpact > 0.01) {
        newTrend = 'rising';
      } else if (multiplierImpact < -0.01) {
        newTrend = 'falling';
      } else {
        newTrend = 'stable';
      }

      // Ajuster le prix actuel
      const newPrice = parseFloat(currency.basePrice) * newMultiplier;

      // Mettre à jour l'historique des prix
      const priceHistory = currency.priceHistory || [];
      priceHistory.push({
        date: new Date().toISOString(),
        price: newPrice,
        volume: totalVolume24h,
        multiplier: newMultiplier
      });

      // Garder seulement les 30 derniers jours
      const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
      const filteredHistory = priceHistory.filter(entry => new Date(entry.date) > thirtyDaysAgo);

      await currency.update({
        currentPrice: newPrice,
        currentMultiplier: newMultiplier,
        economicTrend: newTrend,
        purchaseBonus: newBonus,
        volume24h: totalVolume24h,
        priceHistory: filteredHistory,
        marketCap: newPrice * parseFloat(currency.circulatingSupply)
      }, { transaction });

      return {
        newPrice,
        newMultiplier,
        newTrend,
        newBonus,
        volume24h: totalVolume24h
      };
    } catch (error) {
      logger.error('Erreur lors de la mise à jour des métriques économiques:', error);
      throw error;
    }
  }

  /**
   * Obtenir les statistiques économiques
   */
  static async getEconomicStats(currencyId) {
    try {
      const currency = await VirtualCurrency.findByPk(currencyId);
      if (!currency) {
        throw new Error('Cryptomonnaie non trouvée');
      }

      // Calculer les variations sur 24h
      const priceHistory = currency.priceHistory || [];
      const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000);
      const yesterdayPrice = priceHistory.find(entry => 
        new Date(entry.date) <= yesterday
      )?.price || currency.currentPrice;

      const priceChange24h = ((currency.currentPrice - yesterdayPrice) / yesterdayPrice) * 100;

      return {
        currency: {
          symbol: currency.symbol,
          name: currency.name,
          currentPrice: parseFloat(currency.currentPrice),
          basePrice: parseFloat(currency.basePrice),
          multiplier: parseFloat(currency.currentMultiplier),
          trend: currency.economicTrend,
          purchaseBonus: parseFloat(currency.purchaseBonus) * 100,
          priceChange24h: priceChange24h,
          volume24h: parseFloat(currency.volume24h),
          marketCap: parseFloat(currency.marketCap),
          circulatingSupply: parseFloat(currency.circulatingSupply)
        },
        priceHistory: priceHistory.slice(-30) // 30 derniers points
      };
    } catch (error) {
      logger.error('Erreur lors de la récupération des statistiques:', error);
      throw error;
    }
  }

  /**
   * Catégoriser les dépenses
   */
  static getSpendingCategory(itemType) {
    const categories = {
      'boost_visibility': 'Promotion',
      'super_like': 'Interaction',
      'badge': 'Cosmétique',
      'premium_feature': 'Fonctionnalité',
      'subscription_purchase': 'Abonnement',
      'gift': 'Social'
    };
    return categories[itemType] || 'Autre';
  }

  /**
   * Obtenir le classement des acheteurs
   */
  static async getPurchaseLeaderboard(currencyId, limit = 50) {
    try {
      const leaderboard = await UserWallet.findAll({
        where: { currencyId },
        include: [{
          model: User,
          attributes: ['username', 'profilePicture', 'isVerified']
        }],
        order: [['totalPurchased', 'DESC']],
        limit: limit
      });

      return leaderboard.map((wallet, index) => ({
        rank: index + 1,
        user: {
          id: wallet.userId,
          username: wallet.User.username,
          profilePicture: wallet.User.profilePicture,
          isVerified: wallet.User.isVerified
        },
        totalPurchased: parseFloat(wallet.totalPurchased),
        currentBalance: parseFloat(wallet.balance),
        loyaltyPoints: wallet.loyaltyPoints,
        joinDate: wallet.createdAt
      }));
    } catch (error) {
      logger.error('Erreur lors de la récupération du classement:', error);
      throw error;
    }
  }

  /**
   * Calculer l'effet de marché (bulle/déflation)
   */
  static calculateMarketEffect(currentMultiplier, totalVolume24h, recentPurchases) {
    // Détecter les bulles (multiplicateur trop élevé)
    if (currentMultiplier > 3.0) {
      const bubbleFactor = (currentMultiplier - 3.0) * 0.1;
      return -bubbleFactor; // Force de correction
    }
    
    // Détecter la déflation (multiplicateur trop bas)
    if (currentMultiplier < 0.5) {
      const deflationFactor = (0.5 - currentMultiplier) * 0.05;
      return deflationFactor; // Force de remontée
    }
    
    // Marché normal
    return 0;
  }

  /**
   * Calculer les cycles économiques (boom/bust)
   */
  static calculateEconomicCycle(currency) {
    const now = new Date();
    const daysSinceCreation = Math.floor((now - new Date(currency.createdAt)) / (1000 * 60 * 60 * 24));
    
    // Cycle de 30 jours
    const cyclePhase = (daysSinceCreation % 30) / 30;
    
    // Phase de boom (0-0.3)
    if (cyclePhase < 0.3) {
      return 0.02; // Légère hausse
    }
    // Phase de stabilisation (0.3-0.7)
    else if (cyclePhase < 0.7) {
      return 0; // Stable
    }
    // Phase de correction (0.7-1.0)
    else {
      return -0.01; // Légère baisse
    }
  }

  /**
   * Calculer les événements aléatoires (news, spéculation)
   */
  static calculateRandomEvent() {
    // 10% de chance d'événement aléatoire
    if (Math.random() < 0.1) {
      const eventTypes = [
        { impact: 0.05, probability: 0.3, name: 'Bonne nouvelle' },
        { impact: -0.03, probability: 0.3, name: 'Mauvaise nouvelle' },
        { impact: 0.1, probability: 0.2, name: 'Pump spéculatif' },
        { impact: -0.08, probability: 0.2, name: 'Dump de panique' }
      ];
      
      const random = Math.random();
      let cumulativeProbability = 0;
      
      for (const event of eventTypes) {
        cumulativeProbability += event.probability;
        if (random <= cumulativeProbability) {
          console.log(`🎲 Événement aléatoire: ${event.name} (impact: ${event.impact})`);
          return event.impact;
        }
      }
    }
    
    return 0;
  }

  /**
   * Calculer la stabilisation naturelle (retour à la moyenne)
   */
  static calculateMeanReversion(currentMultiplier, totalVolume24h) {
    const targetMultiplier = 1.0;
    const deviation = currentMultiplier - targetMultiplier;
    
    // Force de retour proportionnelle à la déviation
    const reversionForce = -deviation * 0.01;
    
    // Plus le volume est élevé, plus la stabilisation est forte
    const volumeFactor = Math.min(2.0, Math.max(0.5, totalVolume24h / 1000));
    
    return reversionForce * volumeFactor;
  }
}

module.exports = NewEconomyService;
