const express = require('express');
const { param, query, validationResult } = require('express-validator');
const router = express.Router();

// Import des modèles et services
const { User, UserFollow, Tweet, TweetLike, TweetRetweet, sequelize } = require('../models');
const { Op } = require('sequelize');
const multer = require('multer');
const sharp = require('sharp');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const config = require('../config/config');
const { authenticateToken, denySuspended } = require('../middleware/authMiddleware');
const { checkUserBanStrict, checkUserBanReadOnly } = require('../middleware/banMiddleware');
const BanService = require('../services/banService');
const logger = require('../utils/logger');

// Middleware de validation des erreurs
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: 'Données invalides',
      errors: errors.array()
    });
  }
  next();
};

// ========================================
// ROUTES PUBLIQUES (sans authentification)
// ========================================

/**
 * GET /api/users/suggestions
 * Obtenir des suggestions d'utilisateurs à suivre
 */
router.get('/suggestions', [
  authenticateToken,
  denySuspended,
  query('limit').optional().isInt({ min: 1, max: 20 }).withMessage('La limite doit être entre 1 et 20'),
  handleValidationErrors
], async (req, res) => {
  try {
    const { limit = 10 } = req.query;
    const userId = req.user.id;

    const suggestions = await UserFollow.getFollowSuggestions(userId, parseInt(limit));

    res.json({
      success: true,
      message: 'Suggestions d\'utilisateurs récupérées avec succès',
      data: { suggestions }
    });

  } catch (error) {
    logger.error('Erreur lors de la récupération des suggestions:', error);
    res.status(500).json({
      success: false,
      message: 'Erreur interne du serveur'
    });
  }
});

/**
 * GET /api/users/profile/:username
 * Obtenir le profil public d'un utilisateur par son username
 */
router.get('/profile/:username', [
  param('username').isLength({ min: 1, max: 30 }).withMessage('Username doit être entre 1 et 30 caractères'),
  handleValidationErrors
], async (req, res) => {
  try {
    const { username } = req.params;
    
    const user = await User.findOne({
      where: { 
        username: username,
        is_active: true,
        is_suspended: false
      },
      attributes: ['id', 'username', 'full_name', 'avatar', 'verified', 'premium', 'verification_style', 'stats', 'created_at', 'last_activity']
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'Profil introuvable'
      });
    }

    res.json({
      success: true,
      message: 'Profil utilisateur récupéré avec succès',
      data: { user }
    });

  } catch (error) {
    logger.error('Erreur lors de la récupération du profil utilisateur par username:', error);
    res.status(500).json({
      success: false,
      message: 'Erreur interne du serveur'
    });
  }
});

/**
 * GET /api/users/profile/authenticated/:username
 * Obtenir le profil d'un utilisateur par son username (authentifié),
 * en incluant des informations de relation (ex: isFollowing)
 */
router.get('/profile/authenticated/:username', [
  authenticateToken,
  checkUserBanReadOnly,
  param('username').isLength({ min: 1, max: 30 }).withMessage('Username doit être entre 1 et 30 caractères'),
  handleValidationErrors
], async (req, res) => {
  try {
    const { username } = req.params;
    const currentUserId = req.user.id;

    const user = await User.findOne({
      where: {
        username: username,
        is_active: true,
        is_suspended: false
      },
      attributes: ['id', 'username', 'full_name', 'avatar', 'verified', 'premium', 'verification_style', 'stats', 'created_at', 'last_activity']
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'Profil introuvable'
      });
    }

    // Déterminer la relation de suivi si l'utilisateur courant n'est pas le même
    let isFollowing = false;
    if (currentUserId && user.id !== currentUserId) {
      isFollowing = await UserFollow.isFollowing(currentUserId, user.id);
    }

    res.json({
      success: true,
      message: 'Profil utilisateur (auth) récupéré avec succès',
      data: { user, isFollowing }
    });

  } catch (error) {
    logger.error('Erreur lors de la récupération du profil utilisateur (auth):', error);
    res.status(500).json({
      success: false,
      message: 'Erreur interne du serveur'
    });
  }
});

/**
 * GET /api/users/:id
 * Obtenir le profil public d'un utilisateur par son ID
 */
router.get('/:id', [
  param('id').isUUID().withMessage('ID d\'utilisateur invalide'),
  handleValidationErrors
], async (req, res) => {
  try {
    const { id } = req.params;
    
    const user = await User.findOne({
      where: { 
        id: id,
        is_active: true,
        is_suspended: false
      },
      attributes: ['id', 'username', 'full_name', 'avatar', 'verified', 'premium', 'verification_style', 'stats', 'created_at', 'last_activity']
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'Profil introuvable'
      });
    }

    res.json({
      success: true,
      message: 'Profil utilisateur récupéré avec succès',
      data: { user }
    });

  } catch (error) {
    logger.error('Erreur lors de la récupération du profil utilisateur:', error);
    res.status(500).json({
      success: false,
      message: 'Erreur interne du serveur'
    });
  }
});

/**
 * GET /api/users/:id/tweets
 * Obtenir les tweets d'un utilisateur
 */
router.get('/:id/tweets', [
  authenticateToken,
  checkUserBanReadOnly,
  param('id').isUUID().withMessage('ID d\'utilisateur invalide'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('La limite doit être entre 1 et 100'),
  query('offset').optional().isInt({ min: 0 }).withMessage('L\'offset doit être un nombre positif'),
  query('type').optional().isIn(['all', 'tweets', 'replies', 'retweets']).withMessage('Type de tweet invalide'),
  handleValidationErrors
], async (req, res) => {
  try {
    const { id } = req.params;
    const { limit = 20, offset = 0, type = 'all' } = req.query;

    // Vérifier que l'utilisateur existe
    const user = await User.findOne({
      where: { 
        id: id,
        is_active: true,
        is_suspended: false
      },
      attributes: ['id', 'username', 'full_name', 'avatar', 'verified', 'premium', 'verification_style']
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'Profil introuvable'
      });
    }

    // Utilisateur authentifié via middleware
    const currentUserId = req.user.id;

    let tweets = [];
    let totalCount = 0;

    if (type === 'retweets') {
      // Récupérer les retweets via la table TweetRetweet
      const retweets = await TweetRetweet.findAll({
        where: { user_id: id },
        include: [{
          model: Tweet,
          as: 'tweet',
          include: [{
            model: User,
            as: 'author',
            attributes: ['id', 'username', 'full_name', 'avatar', 'verified', 'premium', 'verification_style']
          }]
        }],
        order: [['created_at', 'DESC']],
        limit: parseInt(limit),
        offset: parseInt(offset)
      });

      totalCount = await TweetRetweet.count({ where: { user_id: id } });

      // Mapper vers les tweets enrichis
      tweets = await Promise.all(retweets.map(async (rt) => {
        const tweet = rt.tweet;
        const likeCount = await TweetLike.count({ where: { tweet_id: tweet.id } });
        const retweetCount = await TweetRetweet.count({ where: { tweet_id: tweet.id } });
        const replyCount = await Tweet.count({ where: { parent_tweet_id: tweet.id } });

        let isLiked = false;
        let isRetweeted = false; // statut pour l'utilisateur connecté, pas le propriétaire du profil
        if (currentUserId) {
          isLiked = await TweetLike.hasUserLikedTweet(currentUserId, tweet.id);
          isRetweeted = await TweetRetweet.hasUserRetweetedTweet(currentUserId, tweet.id);
        }

        return {
          ...tweet.toJSON(),
          stats: {
            likes: likeCount,
            retweets: retweetCount,
            replies: replyCount,
            views: tweet.view_count || 0
          },
          user_interaction: {
            is_liked: isLiked,
            is_retweeted: isRetweeted
          }
        };
      }));
    } else {
      // Tweets et réponses (et éventuellement all)
      const whereClause = { user_id: id, is_private: false, moderation_status: 'approved' };
      if (type === 'replies') {
        whereClause.parent_tweet_id = { [Op.ne]: null };
        whereClause.is_retweet = false;
        whereClause.is_quote = false;
      } else if (type === 'tweets') {
        whereClause.parent_tweet_id = null;
        whereClause.is_retweet = false;
        whereClause.is_quote = false;
      }

      const rawTweets = await Tweet.findAll({
        where: whereClause,
        include: [{
          model: User,
          as: 'author',
          attributes: ['id', 'username', 'full_name', 'avatar', 'verified', 'premium', 'verification_style']
        }],
        order: [['created_at', 'DESC']],
        limit: parseInt(limit),
        offset: parseInt(offset)
      });

      totalCount = await Tweet.count({ where: whereClause });

      tweets = await Promise.all(rawTweets.map(async (tweet) => {
        const likeCount = await TweetLike.count({ where: { tweet_id: tweet.id } });
        const retweetCount = await TweetRetweet.count({ where: { tweet_id: tweet.id } });
        const replyCount = await Tweet.count({ where: { parent_tweet_id: tweet.id } });
        let isLiked = false;
        let isRetweeted = false;
        if (currentUserId) {
          isLiked = await TweetLike.hasUserLikedTweet(currentUserId, tweet.id);
          isRetweeted = await TweetRetweet.hasUserRetweetedTweet(currentUserId, tweet.id);
        }
        return {
          ...tweet.toJSON(),
          stats: {
            likes: likeCount,
            retweets: retweetCount,
            replies: replyCount,
            views: tweet.view_count || 0
          },
          user_interaction: {
            is_liked: isLiked,
            is_retweeted: isRetweeted
          }
        };
      }));
    }

    res.json({
      success: true,
      message: 'Tweets de l\'utilisateur récupérés avec succès',
      data: {
        user,
        tweets,
        pagination: {
          total: totalCount,
          limit: parseInt(limit),
          offset: parseInt(offset),
          hasMore: offset + tweets.length < totalCount
        }
      }
    });

  } catch (error) {
    logger.error('Erreur lors de la récupération des tweets de l\'utilisateur:', error);
    res.status(500).json({
      success: false,
      message: 'Erreur interne du serveur'
    });
  }
});

/**
 * GET /api/users/:id/followers
 * Obtenir les followers d'un utilisateur
 */
router.get('/:id/followers', [
  param('id').isUUID().withMessage('ID d\'utilisateur invalide'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('La limite doit être entre 1 et 100'),
  query('offset').optional().isInt({ min: 0 }).withMessage('L\'offset doit être un nombre positif'),
  handleValidationErrors
], async (req, res) => {
  try {
    const { id } = req.params;
    const { limit = 20, offset = 0 } = req.query;

    // Vérifier que l'utilisateur existe
    const user = await User.findByPk(id, {
      where: { is_active: true },
      attributes: ['id', 'username', 'full_name', 'avatar', 'verified', 'premium', 'verification_style']
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'Utilisateur non trouvé'
      });
    }

    const followers = await UserFollow.getFollowers(id, {
      limit: parseInt(limit),
      offset: parseInt(offset),
      includeUser: true
    });

    // Compter le total
    const totalCount = await UserFollow.countFollowers(id);

    res.json({
      success: true,
      message: 'Followers récupérés avec succès',
      data: {
        user,
        followers: followers.map(f => f.follower),
        pagination: {
          total: totalCount,
          limit: parseInt(limit),
          offset: parseInt(offset),
          hasMore: offset + followers.length < totalCount
        }
      }
    });

  } catch (error) {
    logger.error('Erreur lors de la récupération des followers:', error);
    res.status(500).json({
      success: false,
      message: 'Erreur interne du serveur'
    });
  }
});

/**
 * GET /api/users/:id/following
 * Obtenir les utilisateurs suivis par un utilisateur
 */
router.get('/:id/following', [
  param('id').isUUID().withMessage('ID d\'utilisateur invalide'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('La limite doit être entre 1 et 100'),
  query('offset').optional().isInt({ min: 0 }).withMessage('L\'offset doit être un nombre positif'),
  handleValidationErrors
], async (req, res) => {
  try {
    const { id } = req.params;
    const { limit = 20, offset = 0 } = req.query;

    // Vérifier que l'utilisateur existe
    const user = await User.findByPk(id, {
      where: { is_active: true },
      attributes: ['id', 'username', 'full_name', 'avatar', 'verified', 'premium', 'verification_style']
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'Utilisateur non trouvé'
      });
    }

    const following = await UserFollow.getFollowing(id, {
      limit: parseInt(limit),
      offset: parseInt(offset),
      includeUser: true
    });

    // Compter le total
    const totalCount = await UserFollow.countFollowing(id);

    res.json({
      success: true,
      message: 'Utilisateurs suivis récupérés avec succès',
      data: {
        user,
        following: following.map(f => f.following),
        pagination: {
          total: totalCount,
          limit: parseInt(limit),
          offset: parseInt(offset),
          hasMore: offset + following.length < totalCount
        }
      }
    });

  } catch (error) {
    logger.error('Erreur lors de la récupération des utilisateurs suivis:', error);
    res.status(500).json({
      success: false,
      message: 'Erreur interne du serveur'
    });
  }
});

// ========================================
// ROUTES PROTÉGÉES (avec authentification)
// ========================================

/**
 * POST /api/users/:id/follow
 * S'abonner à un utilisateur
 */
router.post('/:id/follow', [
  authenticateToken,
  param('id').isUUID().withMessage('ID d\'utilisateur invalide'),
  handleValidationErrors
], async (req, res) => {
  try {
    const followerId = req.user.id;
    const followingId = req.params.id;

    // Vérifier que l'utilisateur ne suit pas lui-même
    if (followerId === followingId) {
      return res.status(400).json({
        success: false,
        message: 'Vous ne pouvez pas vous suivre vous-même'
      });
    }

    // Vérifier que l'utilisateur à suivre existe
    const userToFollow = await User.findByPk(followingId, {
      where: { is_active: true }
    });

    if (!userToFollow) {
      return res.status(404).json({
        success: false,
        message: 'Utilisateur à suivre non trouvé'
      });
    }

    // Vérifier si l'utilisateur suit déjà
    const existingFollow = await UserFollow.findOne({
      where: {
        follower_id: followerId,
        following_id: followingId
      }
    });

    if (existingFollow) {
      return res.status(400).json({
        success: false,
        message: 'Vous suivez déjà cet utilisateur'
      });
    }

    // Créer le suivi
    const follow = await UserFollow.create({
      follower_id: followerId,
      following_id: followingId,
      status: 'active',
      metadata: {
        source: req.userPlatform || 'unknown',
        device: req.headers['user-agent'] || 'unknown',
        ip_address: req.ip
      }
    });

    // 🔗 Mettre à jour le graphe social du moteur de similarité en temps réel
    try {
      const similarity = require('../services/similarity');
      similarity.onFollow(followerId, followingId);

      // 🎬 [VideoReco] New video engine follow
      const videoRecommendationService = require('../services/videoRecommendationService');
      videoRecommendationService.onFollow(followerId, followingId, true);
    } catch (e) { /* non-critique */ }

    res.status(201).json({
      success: true,
      message: 'Abonnement créé avec succès',
      data: { follow }
    });

  } catch (error) {
    logger.error('Erreur lors de la création de l\'abonnement:', error);
    res.status(500).json({
      success: false,
      message: 'Erreur interne du serveur'
    });
  }
});

/**
 * DELETE /api/users/:id/follow
 * Se désabonner d'un utilisateur
 */
router.delete('/:id/follow', [
  authenticateToken,
  param('id').isUUID().withMessage('ID d\'utilisateur invalide'),
  handleValidationErrors
], async (req, res) => {
  try {
    const followerId = req.user.id;
    const followingId = req.params.id;

    // Vérifier que l'utilisateur ne se désabonne pas de lui-même
    if (followerId === followingId) {
      return res.status(400).json({
        success: false,
        message: 'Opération invalide'
      });
    }

    // Vérifier si l'utilisateur suit déjà
    const existingFollow = await UserFollow.findOne({
      where: {
        follower_id: followerId,
        following_id: followingId
      }
    });

    if (!existingFollow) {
      return res.status(400).json({
        success: false,
        message: 'Vous ne suivez pas cet utilisateur'
      });
    }

    // Supprimer le suivi
    await existingFollow.destroy();

    // 🔗 Mettre à jour le graphe social du moteur de similarité en temps réel
    try {
      const similarity = require('../services/similarity');
      similarity.onUnfollow(followerId, followingId);

      // 🎬 [VideoReco] New video engine unfollow
      const videoRecommendationService = require('../services/videoRecommendationService');
      videoRecommendationService.onFollow(followerId, followingId, false);
    } catch (e) { /* non-critique */ }

    res.json({
      success: true,
      message: 'Désabonnement effectué avec succès'
    });

  } catch (error) {
    logger.error('Erreur lors de la suppression de l\'abonnement:', error);
    res.status(500).json({
      success: false,
      message: 'Erreur interne du serveur'
    });
  }
});

/**
 * POST /api/users/me/avatar
 * Importer une image d'avatar, la stocker et mettre à jour l'URL de profil
 */
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (req, file, cb) => {
    if (!file.mimetype.startsWith('image/')) {
      return cb(new Error('Seules les images sont autorisées'));
    }
    cb(null, true);
  }
});

router.post('/me/avatar', [
  authenticateToken,
  upload.single('avatar')
], async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, message: 'Fichier avatar manquant (champ "avatar")' });
    }

    const userId = req.user.id;
    const avatarsDir = path.join(__dirname, '../public/avatars');
    fs.mkdirSync(avatarsDir, { recursive: true });

    const filename = `${userId}-${Date.now()}-${uuidv4().slice(0,8)}.jpg`;
    const outputPath = path.join(avatarsDir, filename);

    // Traitement image: carré 256x256, couverture, JPEG qualité 85
    await sharp(req.file.buffer)
      .rotate()
      .resize(256, 256, { fit: 'cover', withoutEnlargement: true })
      .jpeg({ quality: 85 })
      .toFile(outputPath);

    // Base URL publique configurable; fallback sur IP si fournie en env, sinon host:port
    const publicHost = process.env.PUBLIC_HOST || '51.255.48.125';
    const publicPort = process.env.PUBLIC_PORT || config.server.port;
    const protocol = process.env.PUBLIC_PROTOCOL || 'http';
    const baseUrl = process.env.PUBLIC_BASE_URL || `${protocol}://${publicHost}:${publicPort}`;
    const publicUrl = `${baseUrl}/static/avatars/${filename}`;

    // Mettre à jour l'utilisateur
    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ success: false, message: 'Utilisateur non trouvé' });
    }
    user.avatar = publicUrl;
    await user.save();

    return res.status(201).json({
      success: true,
      message: 'Avatar mis à jour avec succès',
      data: { url: publicUrl }
    });
  } catch (error) {
    logger.error('Erreur upload avatar:', error);
    return res.status(500).json({ success: false, message: 'Erreur lors de l\'upload de l\'avatar' });
  }
});

/**
 * GET /api/users/:id/follow-status
 * Vérifier le statut de suivi entre deux utilisateurs
 */
router.get('/:id/follow-status', [
  authenticateToken,
  param('id').notEmpty().withMessage('ID d\'utilisateur requis'),
  handleValidationErrors
], async (req, res) => {
  try {
    const followerId = req.user.id;
    const followingId = req.params.id;

    // Vérifier si l'utilisateur suit déjà
    const isFollowing = await UserFollow.isFollowing(followerId, followingId);

    res.json({
      success: true,
      message: 'Statut de suivi récupéré avec succès',
      data: { isFollowing }
    });

  } catch (error) {
    logger.error('Erreur lors de la vérification du statut de suivi:', error);
    res.status(500).json({
      success: false,
      message: 'Erreur interne du serveur'
    });
  }
});

// ========================================
// ROUTES D'ADMINISTRATION DES BANS
// ========================================

/**
 * POST /api/users/:id/suspend
 * Suspendre un utilisateur (admin seulement)
 */
router.post('/:id/suspend', [
  authenticateToken,
  checkUserBanStrict, // Vérifier que l'admin n'est pas banni
  param('id').isUUID().withMessage('ID d\'utilisateur invalide'),
  handleValidationErrors
], async (req, res) => {
  try {
    const { id } = req.params;
    const { reason, duration_days = 7 } = req.body;
    const adminId = req.user.id;

    if (!reason) {
      return res.status(400).json({
        success: false,
        message: 'Raison de suspension requise'
      });
    }

    const result = await BanService.suspendUser(id, reason, duration_days, adminId);

    res.json({
      success: true,
      message: 'Utilisateur suspendu avec succès',
      data: result
    });

  } catch (error) {
    logger.error('Erreur lors de la suspension:', error);
    res.status(500).json({
      success: false,
      message: 'Erreur lors de la suspension'
    });
  }
});

/**
 * POST /api/users/:id/unsuspend
 * Lever la suspension d'un utilisateur (admin seulement)
 */
router.post('/:id/unsuspend', [
  authenticateToken,
  checkUserBanStrict,
  param('id').isUUID().withMessage('ID d\'utilisateur invalide'),
  handleValidationErrors
], async (req, res) => {
  try {
    const { id } = req.params;
    const adminId = req.user.id;

    const result = await BanService.unsuspendUser(id, adminId);

    res.json({
      success: true,
      message: 'Suspension levée avec succès',
      data: result
    });

  } catch (error) {
    logger.error('Erreur lors de la levée de suspension:', error);
    res.status(500).json({
      success: false,
      message: 'Erreur lors de la levée de suspension'
    });
  }
});

/**
 * POST /api/users/:id/ban
 * Ajouter un ban à un utilisateur (admin seulement)
 */
router.post('/:id/ban', [
  authenticateToken,
  checkUserBanStrict,
  param('id').isUUID().withMessage('ID d\'utilisateur invalide'),
  handleValidationErrors
], async (req, res) => {
  try {
    const { id } = req.params;
    const { reason } = req.body;
    const adminId = req.user.id;

    if (!reason) {
      return res.status(400).json({
        success: false,
        message: 'Raison du ban requise'
      });
    }

    const result = await BanService.addBan(id, reason, adminId);

    res.json({
      success: true,
      message: 'Ban ajouté avec succès',
      data: result
    });

  } catch (error) {
    logger.error('Erreur lors de l\'ajout du ban:', error);
    res.status(500).json({
      success: false,
      message: 'Erreur lors de l\'ajout du ban'
    });
  }
});

/**
 * POST /api/users/:id/unban
 * Réduire le nombre de bans d'un utilisateur (admin seulement)
 */
router.post('/:id/unban', [
  authenticateToken,
  checkUserBanStrict,
  param('id').isUUID().withMessage('ID d\'utilisateur invalide'),
  handleValidationErrors
], async (req, res) => {
  try {
    const { id } = req.params;
    const adminId = req.user.id;

    const result = await BanService.reduceBan(id, adminId);

    res.json({
      success: true,
      message: 'Ban réduit avec succès',
      data: result
    });

  } catch (error) {
    logger.error('Erreur lors de la réduction du ban:', error);
    res.status(500).json({
      success: false,
      message: 'Erreur lors de la réduction du ban'
    });
  }
});

/**
 * GET /api/users/:id/ban-history
 * Obtenir l'historique des bans d'un utilisateur
 */
router.get('/:id/ban-history', [
  authenticateToken,
  checkUserBanReadOnly,
  param('id').isUUID().withMessage('ID d\'utilisateur invalide'),
  handleValidationErrors
], async (req, res) => {
  try {
    const { id } = req.params;
    const history = await BanService.getBanHistory(id);

    res.json({
      success: true,
      message: 'Historique des bans récupéré avec succès',
      data: history
    });

  } catch (error) {
    logger.error('Erreur lors de la récupération de l\'historique des bans:', error);
    res.status(500).json({
      success: false,
      message: 'Erreur lors de la récupération de l\'historique des bans'
    });
  }
});

/**
 * POST /api/users/purchase-premium
 * Acheter le statut premium de manière sécurisée (transaction + upgrade atomique)
 */
router.post('/purchase-premium', [
  authenticateToken,
  denySuspended
], async (req, res) => {
  const transaction = await sequelize.transaction();
  
  try {
    const { duration = 30 } = req.body;
    const userId = req.user.id;
    const premiumPrice = 10; // Prix fixe en TWC
    const currencyId = '077ae58c-7ba5-4da0-bb67-5829a83a2ea1'; // ID TwitCoins

    console.log('💎 [PREMIUM] Achat premium sécurisé demandé:', { userId, duration, price: premiumPrice });

    // Vérifier que l'utilisateur existe et n'est pas déjà premium
    const user = await User.findByPk(userId, { transaction });
    if (!user) {
      await transaction.rollback();
      return res.status(404).json({
        success: false,
        message: 'Utilisateur non trouvé'
      });
    }

    if (user.premium) {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: 'Vous êtes déjà Premium'
      });
    }

    // Vérifier le solde de l'utilisateur via l'API économique
    const NewEconomyService = require('../services/newEconomyService');
    
    let userWallet;
    try {
      userWallet = await NewEconomyService.getUserWallet(currencyId, userId);
    } catch (walletError) {
      console.error('❌ [PREMIUM] Erreur récupération wallet:', walletError);
      await transaction.rollback();
      return res.status(500).json({
        success: false,
        message: 'Impossible de vérifier votre solde'
      });
    }

    // Vérifier que l'utilisateur a assez de TWC
    if (userWallet.wallet.balance < premiumPrice) {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: `Solde insuffisant. Vous avez ${userWallet.wallet.balance} TWC, mais il faut ${premiumPrice} TWC.`,
        data: {
          current_balance: userWallet.wallet.balance,
          required_amount: premiumPrice,
          missing_amount: premiumPrice - userWallet.wallet.balance
        }
      });
    }

    // Effectuer la transaction de débit des TWC dans la même transaction
    let spendResult;
    try {
      spendResult = await NewEconomyService.spendCoins(
        userId,
        currencyId,
        premiumPrice,
        'premium_upgrade',
        'premium_1_month',
        `Upgrade Premium ${duration} jours`,
        transaction // Passer la transaction externe
      );
      console.log('✅ [PREMIUM] Transaction TWC réussie:', spendResult);
    } catch (spendError) {
      console.error('❌ [PREMIUM] Erreur transaction TWC:', spendError);
      await transaction.rollback();
      return res.status(500).json({
        success: false,
        message: 'Erreur lors de la transaction. Vos TWC n\'ont pas été débités.'
      });
    }

    // Si la transaction TWC a réussi, mettre à jour le statut premium
    try {
      await user.update({
        premium: true,
        updated_at: new Date()
      }, { transaction });

      // Confirmer toutes les opérations
      await transaction.commit();

      console.log('🎉 [PREMIUM] Achat premium complet réussi:', { 
        userId, 
        premium: true, 
        duration,
        transactionId: spendResult.transaction.transactionHash,
        amountSpent: premiumPrice
      });

      res.json({
        success: true,
        message: 'Premium activé avec succès !',
        data: {
          premium: true,
          duration_days: duration,
          transaction_id: spendResult.transaction.transactionHash,
          amount_spent: premiumPrice,
          remaining_balance: spendResult.remainingBalance
        }
      });

    } catch (updateError) {
      console.error('❌ [PREMIUM] Erreur mise à jour premium:', updateError);
      await transaction.rollback();
      
      return res.status(500).json({
        success: false,
        message: 'Erreur lors de l\'activation Premium.'
      });
    }

  } catch (error) {
    await transaction.rollback();
    logger.error('Erreur lors de l\'achat premium:', error);
    res.status(500).json({
      success: false,
      message: 'Erreur lors de l\'achat Premium'
    });
  }
});

module.exports = router;
