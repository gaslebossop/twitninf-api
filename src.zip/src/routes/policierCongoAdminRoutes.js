const express = require('express');
const router = express.Router();
const logger = require('../utils/logger');
const instructionManager = require('../services/policiercongo/InstructionManager');
const policiercongoAutomatisation = require('../services/policiercongoAutomatisation');
const { authenticateToken } = require('../middleware/authMiddleware');

/**
 * 🛡️ Middleware de protection Admin/SuperAdmin
 */
const adminOnly = (req, res, next) => {
  if (req.user && (req.user.role === 'admin' || req.user.role === 'superadmin')) {
    return next();
  }
  return res.status(403).json({ success: false, message: 'Accès réservé aux administrateurs' });
};

/**
 * 📋 Récupère toutes les instructions actuelles
 * GET /api/admin/policiercongo/instructions
 */
router.get('/instructions', authenticateToken, adminOnly, (req, res) => {
  try {
    const instructions = instructionManager.getAll();
    res.json({
      success: true,
      instructions: instructions
    });
  } catch (error) {
    logger.error('❌ Erreur lors de la récupération des instructions PolicierCongo:', error);
    res.status(500).json({ success: false, message: 'Erreur serveur' });
  }
});

/**
 * ⚡ Envoie une nouvelle instruction ou un ordre
 * POST /api/admin/policiercongo/instruct
 */
router.post('/instruct', authenticateToken, adminOnly, async (req, res) => {
  try {
    const { text, type } = req.body; // type: 'immediate' | 'personality'
    const adminId = req.user.id;

    if (!text || text.trim().length === 0) {
      return res.status(400).json({ success: false, message: 'L\'instruction ne peut pas être vide' });
    }

    if (type === 'personality') {
      instructionManager.addPersonalityInstruction(text, adminId);
      logger.info(`🎭 Nouvelle directive de personnalité ajoutée par l'admin ${adminId}: ${text}`);
      
      return res.json({
        success: true,
        message: 'Directive de personnalité enregistrée avec succès'
      });
    } else {
      // Ordre immédiat
      instructionManager.addImmediateOrder(text, adminId);
      logger.info(`👑 Nouvel ordre immédiat reçu de l'admin ${adminId}: ${text}`);
      
      // 🚀 Déclencher l'exécution instantanée
      logger.info('⚡ Déclencheur: Exécution instantanée de PolicierCongo suite à un ordre Admin...');
      
      // Utiliser runOptimizedAutomation pour un cycle complet
      // On le lance de manière asynchrone pour ne pas bloquer la réponse HTTP
      policiercongoAutomatisation.runOptimizedAutomation().then(result => {
        if (result && result.success) {
          logger.info(`✅ Ordre Admin exécuté avec succès: ${result.summary}`);
          // L'engine marque désormais les ordres comme exécutés automatiquement
        } else {
          logger.warn('⚠️ Échec ou exécution partielle de l\'ordre Admin');
        }
      }).catch(err => {
        logger.error('❌ Erreur lors de l\'exécution de l\'ordre Admin:', err);
      });

      return res.json({
        success: true,
        message: 'Ordre reçu et exécution instantanée lancée'
      });
    }
  } catch (error) {
    logger.error('❌ Erreur lors de l\'envoi de l\'ordre PolicierCongo:', error);
    res.status(500).json({ success: false, message: 'Erreur serveur' });
  }
});

/**
 * 🗑️ Supprime une directive de personnalité
 * DELETE /api/admin/policiercongo/personality/:id
 */
router.delete('/personality/:id', authenticateToken, adminOnly, (req, res) => {
  try {
    const id = parseInt(req.params.id);
    instructionManager.removePersonalityInstruction(id);
    res.json({ success: true, message: 'Directive supprimée avec succès' });
  } catch (error) {
    logger.error('❌ Erreur lors de la suppression de la directive:', error);
    res.status(500).json({ success: false, message: 'Erreur serveur' });
  }
});

module.exports = router;
