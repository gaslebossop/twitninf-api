const config = {
  // Configuration du serveur
  server: {
    port: 3000,
    host: '0.0.0.0',
    env: 'development',
    cors: {
      origin: '*',
      credentials: true
    }
  },

  // Configuration PostgreSQL optimisée
  database: {
    host: '51.255.48.125',
    port: 5432,
    database: 'twitninf',
    username: 'admin',
    password: 'myytree88',
    dialect: 'postgres',
    pool: {
      max: 10,
      min: 2,
      acquire: 60000,
      idle: 10000
    },
    logging: false,
    benchmark: false,
    define: {
      timestamps: true,
      underscored: true,
      freezeTableName: true
    },
    dialectOptions: {
      statement_timeout: 60000,
      idle_in_transaction_session_timeout: 60000,
      ssl: false,
      connectTimeout: 60000,
      keepAlive: true,
      keepAliveInitialDelayMillis: 10000
    },
    retry: {
      max: 5,
      timeout: 3000
    }
  },

  // Configuration JWT
  jwt: {
    secret: 'twitninf-super-secret-key-2024',
    expiresIn: '7d',
    refreshExpiresIn: '30d'
  },

  // Configuration de sécurité
  security: {
    bcryptRounds: 12,
    rateLimit: {
      windowMs: 15 * 60 * 1000, // 15 minutes
      max: 1000 // limite chaque IP à 1000 requêtes par fenêtre
    }
  },

  // Configuration des logs
  logging: {
    level: 'info',
    filename: 'logs/app.log'
  },

  // Configuration des emails
  email: {
    host: 'smtp.gmail.com',
    port: 587,
    secure: false,
    auth: {
      user: '',
      pass: ''
    }
  },

  // Configuration Redis optimisée
  redis: {
    host: 'localhost',
    port: 6379,
    password: null,
    db: 0,
    retryDelayOnFailover: 100,
    enableReadyCheck: false,
    maxRetriesPerRequest: 3,
    lazyConnect: true,
    keepAlive: 30000,
    family: 4,
    maxMemoryPolicy: 'allkeys-lru'
  },

  // Configuration des uploads
  upload: {
    maxFileSize: 5 * 1024 * 1024, // 5MB
    allowedTypes: ['image/jpeg', 'image/png', 'image/gif'],
    uploadPath: 'uploads/',
    defaultAvatar: 'https://via.placeholder.com/150x150/4A90E2/FFFFFF?text=U'
  },

  // Configuration des notifications
  notifications: {
    push: {
      vapidPublicKey: '',
      vapidPrivateKey: ''
    }
  },

  // Configuration du cache
  cache: {
    ttl: 300, // 5 minutes
    checkPeriod: 600, // 10 minutes
    maxKeys: 1000
  },

  // Configuration des performances
  performance: {
    compression: {
      level: 6,
      threshold: 1024
    },
    queryTimeout: 30000,
    connectionTimeout: 10000
  }
};

module.exports = config;
