const { sequelize } = require('../database');
const User = require('../models/User');
const logger = require('../utils/logger');

async function runAutoMigration() {
  try {
    logger.info('🔄 Démarrage de la migration automatique...');
    
    // Vérifier la connexion à la base de données
    await sequelize.authenticate();
    logger.info('✅ Connexion à la base de données établie');

    // Vérifier si les colonnes de modération existent
    const tableInfo = await sequelize.getQueryInterface().describeTable('users');
    const needsMigration = !tableInfo.role || !tableInfo.moderation_permissions || !tableInfo.moderation_history;

    if (needsMigration) {
      logger.info('📝 Colonnes de modération manquantes, ajout en cours...');
      
      // Ajouter les colonnes manquantes
      const alterQueries = [];
      
      if (!tableInfo.role) {
        alterQueries.push(`
          ALTER TABLE users 
          ADD COLUMN role VARCHAR(20) DEFAULT 'user' NOT NULL,
          ADD CONSTRAINT check_role CHECK (role IN ('user', 'moderator', 'admin', 'superadmin', 'classeurdetweets'))
        `);
      }
      
      if (!tableInfo.moderation_permissions) {
        alterQueries.push(`
          ALTER TABLE users 
          ADD COLUMN moderation_permissions JSONB DEFAULT '{"can_ban_users": false, "can_suspend_users": false, "can_delete_tweets": false, "can_verify_users": false, "can_view_reports": false, "can_view_analytics": false, "can_manage_moderators": false}'::jsonb
        `);
      }
      
      if (!tableInfo.moderation_history) {
        alterQueries.push(`
          ALTER TABLE users 
          ADD COLUMN moderation_history JSONB DEFAULT '[]'::jsonb
        `);
      }

      // Exécuter les requêtes d'alteration
      for (const query of alterQueries) {
        try {
          await sequelize.query(query);
          logger.info('✅ Colonne ajoutée avec succès');
        } catch (error) {
          logger.warn('⚠️ Erreur lors de l\'ajout de colonne (peut-être déjà existante):', error.message);
        }
      }
      
      logger.info('✅ Migration des colonnes terminée');
    } else {
      logger.info('✅ Toutes les colonnes de modération existent déjà');
    }

    // Définir l'utilisateur "g" comme admin
    try {
      const userG = await User.findOne({
        where: { username: 'g' }
      });

      if (userG) {
        // Mettre à jour l'utilisateur "g" pour le rendre admin
        await userG.update({
          role: 'superadmin',
          moderation_permissions: {
            can_ban_users: true,
            can_suspend_users: true,
            can_delete_tweets: true,
            can_verify_users: true,
            can_view_reports: true,
            can_view_analytics: true,
            can_manage_moderators: true
          }
        });

        logger.info('👑 Utilisateur "g" promu au rang de superadmin');
        console.log('🎉 Utilisateur "g" est maintenant superadmin avec toutes les permissions!');
      } else {
        logger.warn('⚠️ Utilisateur "g" non trouvé - impossible de le promouvoir admin');
      }
    } catch (error) {
      logger.error('❌ Erreur lors de la promotion de l\'utilisateur "g":', error.message);
    }

    logger.info('✅ Migration automatique terminée avec succès');

  } catch (error) {
    logger.error('❌ Erreur lors de la migration automatique:', error);
    console.error('❌ Erreur de migration:', error.message);
  }
}

module.exports = runAutoMigration;
