const { Transaction, UserWallet, User, VirtualCurrency } = require('../models');
const { Op } = require('sequelize');
const { sequelize } = require('../database/index');
const crypto = require('crypto');
const logger = require('../utils/logger');

class EconomyAdminController {
  
  /**
   * Statistiques globales (Masse monétaire et Réserves)
   */
  async getGlobalStats(req, res) {
    try {
      // 1. Récupérer la monnaie principale (TWC)
      const currency = await VirtualCurrency.findOne({ where: { symbol: 'TWC' } });
      if (!currency) return res.status(404).json({ success: false, message: 'Monnaie TWC non trouvée' });

      // 2. Récupérer le solde du compte officiel TwitNinf
      const officialAccountId = '01837802-c2ae-4de0-9471-7a9b642afde2';
      const officialWallet = await UserWallet.findOne({ 
        where: { userId: officialAccountId, currencyId: currency.id } 
      });

      // 3. Calculer la somme totale des soldes (hors système ?)
      const totalBalanceReal = await UserWallet.sum('balance', { 
        where: { currencyId: currency.id } 
      });

      res.json({
        success: true,
        stats: {
          circulatingSupply: parseFloat(currency.circulatingSupply),
          realTimeTotalBalance: parseFloat(totalBalanceReal || 0),
          systemReserve: parseFloat(officialWallet?.balance || 0),
          currencyPrice: parseFloat(currency.currentPrice),
          multiplier: parseFloat(currency.currentMultiplier)
        }
      });
    } catch (error) {
      logger.error('Erreur getGlobalStats Admin:', error);
      res.status(500).json({ success: false, message: error.message });
    }
  }

  /**
   * Liste des transactions récentes
   */
  async getTransactions(req, res) {
    try {
      const { page = 1, limit = 50, type, status } = req.query;
      const offset = (page - 1) * limit;

      const where = {};
      if (type && type !== 'ALL') where.type = type;
      if (status) where.status = status;

      // 1. Trouver les transactions paginées
      const transactions = await Transaction.findAndCountAll({
        where,
        limit: parseInt(limit),
        offset,
        order: [['createdAt', 'DESC']],
        include: [
          { model: User, as: 'fromUser', attributes: ['id', 'username', 'avatar'] },
          { model: User, as: 'toUser', attributes: ['id', 'username', 'avatar'] }
        ]
      });

      // 2. Calculer le volume des dernières 24h (TWC uniquement)
      const currency = await VirtualCurrency.findOne({ where: { symbol: 'TWC' } });
      const last24h = new Date(Date.now() - 24 * 60 * 60 * 1000);
      
      const volume24h = await Transaction.sum('amount', {
        where: {
          currencyId: currency?.id,
          createdAt: { [Op.gte]: last24h },
          status: 'COMPLETED'
        }
      });

      const count24h = await Transaction.count({
        where: {
          currencyId: currency?.id,
          createdAt: { [Op.gte]: last24h }
        }
      });

      res.json({
        success: true,
        data: transactions.rows,
        stats24h: {
          volume: parseFloat(volume24h || 0),
          count: count24h
        },
        pagination: {
          total: transactions.count,
          page: parseInt(page),
          pages: Math.ceil(transactions.count / limit)
        }
      });
    } catch (error) {
      logger.error('Erreur getTransactions Admin:', error);
      res.status(500).json({ success: false, message: error.message });
    }
  }

  /**
   * Classement des plus gros détenteurs (Rich List)
   */
  async getRichList(req, res) {
    try {
      const { limit = 20 } = req.query;
      
      const currency = await VirtualCurrency.findOne({ where: { symbol: 'TWC' } });
      if (!currency) return res.status(404).json({ success: false, message: 'Monnaie TWC non trouvée' });

      const wallets = await UserWallet.findAll({
        where: { 
          currencyId: currency.id,
          balance: { [Op.gt]: 0 } 
        },
        limit: parseInt(limit),
        order: [['balance', 'DESC']],
        include: [{ model: User, as: 'user', attributes: ['id', 'username', 'avatar', 'verified'] }]
      });

      res.json({
        success: true,
        data: wallets.map(w => ({
          userId: w.userId,
          username: w.user?.username,
          avatar: w.user?.avatar,
          balance: parseFloat(w.balance),
          isVerified: w.user?.verified
        }))
      });
    } catch (error) {
      logger.error('Erreur getRichList Admin:', error);
      res.status(500).json({ success: false, message: error.message });
    }
  }

  /**
   * Rechercher des portefeuilles
   */
  async searchWallets(req, res) {
    try {
      const { query } = req.query;
      if (!query) return res.status(400).json({ success: false, message: 'Requête vide' });

      // 1. Trouver d'abord la monnaie TWC
      const currency = await VirtualCurrency.findOne({ where: { symbol: 'TWC' } });
      if (!currency) return res.status(404).json({ success: false, message: 'Monnaie TWC non trouvée' });

      // 2. Chercher les utilisateurs et inclure DIRECTEMENT leur portefeuille TWC
      const users = await User.findAll({
        where: {
          [Op.or]: [
            { username: { [Op.iLike]: `%${query}%` } },
            { full_name: { [Op.iLike]: `%${query}%` } }
          ]
        },
        limit: 10,
        attributes: ['id', 'username', 'avatar', 'full_name'],
        include: [{
          model: UserWallet,
          as: 'wallets',
          where: { currencyId: currency.id },
          required: false // On veut quand même l'utilisateur même s'il n'a pas encore de portefeuille
        }]
      });

      const results = users.map(u => {
        // En Sequelize, avec l'alias 'wallets', c'est un tableau
        const twcWallet = u.wallets && u.wallets.length > 0 ? u.wallets[0] : null;
        return {
          id: u.id,
          username: u.username,
          avatar: u.avatar,
          full_name: u.full_name,
          balance: twcWallet ? parseFloat(twcWallet.balance) : 0,
          walletId: twcWallet?.id,
          isLocked: twcWallet?.isLocked || false
        };
      });

      logger.info(`🔍 Recherche admin éco : ${query} -> ${results.length} résultats`);
      res.json({ success: true, data: results });
    } catch (error) {
      logger.error('Erreur searchWallets Admin:', error);
      res.status(500).json({ success: false, message: error.message });
    }
  }

  /**
   * Ajustement manuel de solde
   */
  async updateWalletBalance(req, res) {
    const { userId, amount, reason } = req.body;
    const transaction = await sequelize.transaction();

    try {
      // 1. Trouver la monnaie TWC
      const currency = await VirtualCurrency.findOne({ where: { symbol: 'TWC' }, transaction });
      if (!currency) throw new Error('Monnaie TWC non trouvée');

      // 2. Trouver le portefeuille TWC spécifique de l'utilisateur
      const wallet = await UserWallet.findOne({ 
        where: { userId, currencyId: currency.id }, 
        transaction 
      });
      if (!wallet) throw new Error('Portefeuille TWC non trouvé pour cet utilisateur');

      const oldBalance = parseFloat(wallet.balance);
      const newBalance = parseFloat(amount);
      const diff = newBalance - oldBalance;

      // 3. Mettre à jour le solde
      await wallet.update({ balance: newBalance }, { transaction });

      // 4. Ajuster la masse monétaire en circulation pour refléter le changement admin
      await currency.update({
        circulatingSupply: parseFloat(currency.circulatingSupply) + diff
      }, { transaction });

      // Logger l'action d'admin
      logger.warn(`ADMIN ACTION: Balance update for ${userId} from ${oldBalance} to ${newBalance}. Reason: ${reason}`);

      await transaction.commit();
      res.json({ success: true, newBalance });
    } catch (error) {
      if (transaction) await transaction.rollback();
      res.status(500).json({ success: false, message: error.message });
    }
  }

  /**
   * Transfert manuel pour l'admin (système vers utilisateur ou utilisateur vers utilisateur)
   */
  async manualTransfer(req, res) {
    const { fromUserId, toUserId, amount, description } = req.body;
    const transferAmount = parseFloat(amount || 0);

    if (transferAmount <= 0) {
      return res.status(400).json({ success: false, message: 'Le montant doit être supérieur à 0' });
    }

    const transaction = await sequelize.transaction();

    try {
      // 1. Récupérer la monnaie TWC
      const currency = await VirtualCurrency.findOne({ where: { symbol: 'TWC' }, transaction });
      if (!currency) throw new Error('Monnaie TWC non trouvée');

      // 2. Débiter l'expéditeur (ou augmenter circulatingSupply si depuis Système)
      if (fromUserId) {
        const fromWallet = await UserWallet.findOne({ where: { userId: fromUserId }, transaction });
        if (!fromWallet) throw new Error('Expéditeur non trouvé');
        if (parseFloat(fromWallet.balance) < transferAmount) throw new Error('Solde expéditeur insuffisant');
        await fromWallet.update({ balance: parseFloat(fromWallet.balance) - transferAmount }, { transaction });
      } else {
        // Source = Système/NULL : Augmenter la masse monétaire totale
        await currency.update({ 
          circulatingSupply: parseFloat(currency.circulatingSupply) + transferAmount 
        }, { transaction });
      }

      // 3. Créditer le destinataire
      let toWallet = await UserWallet.findOne({ where: { userId: toUserId }, transaction });
      if (!toWallet) throw new Error('Destinataire non trouvé');
      await toWallet.update({ balance: parseFloat(toWallet.balance) + transferAmount }, { transaction });

      // 4. Créer la transaction
      const tx = await Transaction.create({
        transactionHash: crypto.randomBytes(32).toString('hex'),
        fromUserId: fromUserId || null,
        toUserId,
        amount: transferAmount,
        type: 'TRANSFER',
        status: 'COMPLETED',
        description: `[FORCE ADMIN] ${description}`,
        confirmedAt: new Date()
      }, { transaction });

      await transaction.commit();
      res.json({ success: true, transaction: tx });
    } catch (error) {
      if (transaction) await transaction.rollback();
      logger.error('Erreur manualTransfer:', error);
      res.status(500).json({ success: false, message: error.message });
    }
  }

  /**
   * Verrouiller/Déverrouiller un portefeuille
   */
  async toggleWalletLock(req, res) {
    const { userId, isLocked, reason } = req.body;
    
    try {
      const currency = await VirtualCurrency.findOne({ where: { symbol: 'TWC' } });
      if (!currency) throw new Error('Monnaie TWC non trouvée');

      const wallet = await UserWallet.findOne({ 
        where: { userId, currencyId: currency.id } 
      });
      if (!wallet) return res.status(404).json({ success: false, message: 'Portefeuille TWC non trouvé' });

      await wallet.update({ 
        isLocked: !!isLocked,
        lockReason: isLocked ? (reason || 'Verrouillé par le Gardien') : null
      });

      res.json({ 
        success: true, 
        isLocked: wallet.isLocked,
        message: wallet.isLocked ? 'Portefeuille gelé' : 'Portefeuille dégelé' 
      });
    } catch (error) {
      res.status(500).json({ success: false, message: error.message });
    }
  }

  /**
   * Supprimer/Annuler une transaction suspecte
   */
  async deleteTransaction(req, res) {
    const { id } = req.params;
    const { refund = false } = req.body;
    const transaction = await sequelize.transaction();

    try {
      const tx = await Transaction.findByPk(id, { transaction });
      if (!tx) throw new Error('Transaction non trouvée');

      if (refund && tx.status === 'COMPLETED') {
        // Optionnel : recréditer fromUser si c'est possible
        if (tx.fromUserId) {
          const w = await UserWallet.findOne({ where: { userId: tx.fromUserId }, transaction });
          if (w) await w.update({ balance: parseFloat(w.balance) + parseFloat(tx.amount) }, { transaction });
        }
        // Débiter toUser
        if (tx.toUserId) {
          const w = await UserWallet.findOne({ where: { userId: tx.toUserId }, transaction });
          if (w) await w.update({ balance: parseFloat(w.balance) - parseFloat(tx.amount) }, { transaction });
        }
      }

      await tx.destroy({ transaction });
      await transaction.commit();
      res.json({ success: true, message: 'Transaction supprimée et soldes ajustés' });
    } catch (error) {
      await transaction.rollback();
      res.status(500).json({ success: false, message: error.message });
    }
  }
}

module.exports = new EconomyAdminController();
