/**
 * ═══════════════════════════════════════════════════════════════════════════════
 *  SIMILARITY RECOMMENDATION ENGINE V2 — Moteur de recommandation multi-signal
 *
 *  Architecture combinée (7 signaux) :
 *    ① Content-Based Filtering  → cosine(userVec, tweetVec)
 *    ② Collaborative Filtering  → tweets aimés par des users similaires
 *    ③ Follow Graph Boost       → tweets d'auteurs suivis / amis d'amis
 *    ④ Trending / Engagement    → tweets avec forte vélocité d'engagement
 *    ⑤ Freshness               → décroissance temporelle exponentielle
 *    ⑥ Discovery Pool          → nouveaux tweets à faible exposition
 *    ⑦ Language Match           → bonus si langue tweet = langue user
 *
 *  Score final (user existant) :
 *    score = α·content + β·collab + γ·follow + δ·trending
 *          + ε·freshness + ζ·discovery + η·language
 *
 *  Cold Start (nouveau user sans historique) :
 *    score = trending × 0.35 + authorPopularity × 0.25 + freshness × 0.20
 *          + diversity × 0.10 + language × 0.10
 *
 *  Post-processing :
 *    - Author diversity (max 3 tweets consécutifs du même auteur)
 *    - Hashtag diversity injection
 *    - Quality bonus (medias, longueur contenu)
 *
 *  Perf cible : < 15ms pour 50K tweets sur un VPS 2-core
 * ═══════════════════════════════════════════════════════════════════════════════
 */

const path = require('path');
const {
  DIMS, createVec, vectorize, cosineSim, vecEWMA,
  vecAddWeighted, vecNormalize, topK, VectorStore
} = require('./vectorEngine');
const botDetectionService = require('../BotDetectionService');

// ─────────────────────────────────────────────────────────────────────────────
//  SCORING WEIGHTS — User existant (7 signaux)
// ─────────────────────────────────────────────────────────────────────────────
const WEIGHTS = {
  CONTENT: 0.25,   // Similarité contenu user↔tweet
  COLLAB: 0.20,   // Score collaboratif (users similaires)
  FOLLOW: 0.15,   // Graphe social (auteurs suivis)
  TRENDING: 0.12,   // Engagement velocity (trending now)
  FRESHNESS: 0.13,   // Bonus fraîcheur (décroissance temporelle)
  DISCOVERY: 0.10,   // Boost tweets peu vus (exploration)
  LANGUAGE: 0.05,   // Bonus langue matching
};

// Cold Start Weights — Nouveau user sans historique
const COLD_START_WEIGHTS = {
  LIKES: 0.40,   // Très fort bonus pour les tweets les plus likés
  TRENDING: 0.15,   // Les meilleurs tweets trending
  POPULARITY: 0.15,   // Auteurs populaires / vérifiés
  FRESHNESS: 0.10,   // Contenu récent
  DIVERSITY: 0.10,   // Diversité de sujets
  LANGUAGE: 0.10,   // Même langue
};

// Poids des types d'interaction pour construire le user vector
const INTERACTION_WEIGHTS = {
  post: 3.0,
  comment: 2.5,
  quote: 2.0,
  retweet: 1.5,
  like: 1.0,
};

// ─────────────────────────────────────────────────────────────────────────────
//  TUNING CONSTANTS
// ─────────────────────────────────────────────────────────────────────────────
const SIMILAR_USERS_K = 50;     // ↑ de 30 → plus de collab data
const DISCOVERY_WINDOW_H = 72;     // ↑ de 48h → fenêtre discovery étendue
const DISCOVERY_MIN_RATIO = 0.12;   // Minimum 12% du feed = discovery
const COLLAB_TWEET_LIMIT = 300;    // ↑ de 200 → plus de tweets collab
const SAVE_INTERVAL_MS = 5 * 60 * 1000;
const MAX_CACHE_AGE_MS = 20 * 60 * 1000; // ↑ à 20 min pour scroll stable
const CACHED_POOL_SIZE = 1500;   // ↑ de 1000 → plus de contenu pour scroll infini
const TRENDING_CACHE_TTL_MS = 3 * 60 * 1000;  // Trending recalculé toutes les 3 min
const MAX_SAME_AUTHOR_WINDOW = 3;      // Max 3 tweets du même auteur dans 15 tweets consécutifs
const AUTHOR_DIVERSITY_WINDOW = 15;     // Fenêtre glissante pour diversité auteur
const FRESHNESS_HALF_LIFE_H = 18;     // ↑ de 12h → tweets restent pertinents plus longtemps

// Engagement velocity thresholds
const VELOCITY_HIGH_THRESHOLD = 2.0;    // > 2 engagements/heure = trending
const VELOCITY_MID_THRESHOLD = 0.5;    // > 0.5 = good engagement

// Helper pour filtrer les tweets de test ou spam
function isSpamOrTest(content) {
  if (!content) return false;
  const words = content.trim().split(/\s+/).filter(w => w.length > 0);
  if (words.length < 4) {
    const lowerContent = content.toLowerCase();
    if (/\b(tg|test)\b/.test(lowerContent)) {
      return true;
    }
  }
  return false;
}

// Helper : extraire les hashtags d'un contenu
function extractHashtags(content) {
  if (!content) return [];
  const matches = content.match(/#[\w\u0590-\u05ff]+/g);
  return matches ? matches.map(h => h.toLowerCase()) : [];
}

// ═════════════════════════════════════════════════════════════════════════════

class SimilarityRecommendationEngine {

  constructor(dataDir = null) {
    this.dataDir = dataDir || path.join(__dirname, '..', '..', '..', 'data', 'similarity');

    // Stores vectoriels
    this.tweetStore = new VectorStore('tweets', this.dataDir);
    this.userStore = new VectorStore('users', this.dataDir);

    // ── Méta-données tweets enrichies ──
    /** @type {Map<string, {authorId:string, createdAt:Date, viewCount:number, language:string, hashtags:string[], hasMedia:boolean, contentLen:number, engagement:{likes:number, retweets:number, replies:number, velocity:number}}>} */
    this.tweetMeta = new Map();

    // ── Données auteurs ──
    /** @type {Map<string, {followersCount:number, verified:boolean, premium:boolean, language:string}>} */
    this.authorMeta = new Map();

    // ── Graphe social ──
    /** @type {Map<string, Set<string>>} userId → Set<authorId> que l'user suit */
    this.followGraph = new Map();
    /** @type {Map<string, number>} authorId → nombre de followers */
    this.followerCounts = new Map();
    /** @type {Map<string, Set<string>>} authorId → Set<tweetId> tweets récents */
    this.authorTweets = new Map();

    // ── Hashtag Affinity ──
    /** @type {Map<string, Map<string, number>>} userId → Map<hashtag, affinityScore> */
    this.userHashtagAffinity = new Map();

    // ── Interactions utilisateur ──
    /** @type {Map<string, Set<string>>} userId → Set<tweetId> interagi */
    this.userInteractions = new Map();

    // ── Discovery Pool (tweets récents avec peu de vues) ──
    /** @type {Map<string, {tweetId:string, vec:Float32Array, createdAt:Date}>} */
    this.discoveryPool = new Map();

    // ── Trending Cache ──
    /** @type {{ts:number, list:Array<{tweetId:string, velocity:number}>}} */
    this._trendingCache = { ts: 0, list: [] };

    // ── Cache des recommandations ──
    /** @type {Map<string, {ts:number, results:any[], poolSize:number}>} */
    this.recoCache = new Map();

    // ── User language cache ──
    /** @type {Map<string, string>} userId → language */
    this.userLanguage = new Map();

    // ── Stats ──
    this.stats = {
      totalRecommendations: 0,
      avgRecoMs: 0,
      cacheHits: 0,
      coldStartServed: 0,
      indexBuilds: 0,
      interactionsRecorded: 0,
      lastBuildMs: 0,
    };

    // Timer de sauvegarde périodique
    this._saveTimer = null;
    this._initialized = false;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  INITIALISATION
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * Initialise le moteur :
   * 1. Charge les index depuis le disque (binaire)
   * 2. Rebuild depuis PostgreSQL si les index sont vides
   * 3. Lance le timer de sauvegarde
   */
  async initialize(sequelizeModels = null) {
    console.log('\n🚀 ══════════════════════════════════════════════════');
    console.log('   SIMILARITY ENGINE V2 — Initialisation Multi-Signal');
    console.log('   ══════════════════════════════════════════════════');

    const t0 = Date.now();

    // 1. Charger depuis disque
    const tweetCount = this.tweetStore.load();
    const userCount = this.userStore.load();
    console.log(`   📂 Index chargés: ${tweetCount} tweets, ${userCount} users`);

    // 2. Rebuild si nécessaire
    if (tweetCount === 0 && sequelizeModels) {
      console.log('   🔨 Index vide → rebuild complet depuis PostgreSQL...');
      await this.rebuildFromDB(sequelizeModels);
    } else if (sequelizeModels) {
      // Même si les index existent, on charge les métadonnées enrichies
      console.log('   📊 Chargement des métadonnées enrichies...');
      await this._loadEnrichedMeta(sequelizeModels);
    }

    // 3. Timer de sauvegarde
    this._saveTimer = setInterval(() => this._periodicSave(), SAVE_INTERVAL_MS);

    this._initialized = true;
    const elapsed = Date.now() - t0;
    this.stats.lastBuildMs = elapsed;

    console.log(`   ✅ Moteur V2 initialisé en ${elapsed}ms`);
    console.log(`   📊 ${this.tweetStore.size} tweet vecs | ${this.userStore.size} user vecs`);
    console.log(`   🔗 ${this.followGraph.size} follow graphs | ${this.discoveryPool.size} discovery`);
    console.log(`   👤 ${this.authorMeta.size} author profiles | ${this.userHashtagAffinity.size} hashtag affinities`);
    console.log('   ══════════════════════════════════════════════════\n');

    return true;
  }

  /**
   * Charge les métadonnées enrichies sans re-vectoriser (fast path).
   * Utilisé quand les index vectoriels existent déjà sur disque.
   */
  async _loadEnrichedMeta(models) {
    try {
      const { Tweet, TweetLike, TweetRetweet, User, UserFollow } = models;
      const { Op, fn, col, literal } = require('sequelize');

      // ── Tweets meta (sans re-vectoriser) ──
      const tweets = await Tweet.findAll({
        where: { deleted_at: null, content: { [Op.ne]: null } },
        attributes: ['id', 'content', 'user_id', 'created_at', 'view_count', 'media_urls', 'language', 'hashtags', 'parent_tweet_id', 'original_tweet_id', 'tweet_type'],
        raw: true,
        limit: 50000,
      });

      for (const tweet of tweets) {
        if (isSpamOrTest(tweet.content)) continue;
        const hashtags = Array.isArray(tweet.hashtags)
          ? tweet.hashtags.map(h => h.toLowerCase())
          : extractHashtags(tweet.content);

        this.tweetMeta.set(tweet.id, {
          authorId: tweet.user_id,
          createdAt: new Date(tweet.created_at),
          viewCount: tweet.view_count || 0,
          language: tweet.language || 'fr',
          hashtags,
          hasMedia: Array.isArray(tweet.media_urls) && tweet.media_urls.length > 0,
          contentLen: (tweet.content || '').length,
          parentTweetId: tweet.parent_tweet_id,
          originalTweetId: tweet.original_tweet_id,
          type: tweet.tweet_type || 'tweet',
          engagement: { likes: 0, retweets: 0, replies: 0, velocity: 0 },
        });

        // Author tweets index
        if (!this.authorTweets.has(tweet.user_id)) this.authorTweets.set(tweet.user_id, new Set());
        this.authorTweets.get(tweet.user_id).add(tweet.id);

        // Discovery pool
        const age = Date.now() - new Date(tweet.created_at).getTime();
        if (age < DISCOVERY_WINDOW_H * 3600000 && (tweet.view_count || 0) < 30) {
          const vec = this.tweetStore.get(tweet.id);
          if (vec) {
            this.discoveryPool.set(tweet.id, { tweetId: tweet.id, vec, createdAt: new Date(tweet.created_at) });
          }
        }
      }

      // ── Engagement counts (batch) ──
      await this._loadEngagementCounts(models);

      // ── Author metadata ──
      await this._loadAuthorMeta(models);

      // ── Follow graph ──
      await this._loadFollowGraph(models);

      // ── User language ──
      await this._loadUserLanguages(models);

      // ── Hashtag affinities ──
      this._buildHashtagAffinities(tweets);

      console.log(`   📊 Meta enrichies chargées: ${this.tweetMeta.size} tweets, ${this.followGraph.size} follow graphs`);
    } catch (err) {
      console.error('   ⚠️ Erreur chargement meta enrichies:', err.message);
    }
  }

  /**
   * Charge les compteurs d'engagement par batch (élimine les N+1 queries).
   */
  async _loadEngagementCounts(models) {
    try {
      const { TweetLike, TweetRetweet, Tweet } = models;
      const { fn, col } = require('sequelize');

      // Likes par tweet (batch)
      const likeCounts = await TweetLike.findAll({
        attributes: ['tweet_id', [fn('COUNT', col('id')), 'cnt']],
        group: ['tweet_id'],
        raw: true,
      });
      for (const row of likeCounts) {
        const meta = this.tweetMeta.get(row.tweet_id);
        if (meta) meta.engagement.likes = parseInt(row.cnt) || 0;
      }

      // Retweets par tweet (batch)
      const rtCounts = await TweetRetweet.findAll({
        attributes: ['tweet_id', [fn('COUNT', col('id')), 'cnt']],
        group: ['tweet_id'],
        raw: true,
      });
      for (const row of rtCounts) {
        const meta = this.tweetMeta.get(row.tweet_id);
        if (meta) meta.engagement.retweets = parseInt(row.cnt) || 0;
      }

      // Replies par tweet parent (batch)
      const replyCounts = await Tweet.findAll({
        attributes: ['parent_tweet_id', [fn('COUNT', col('id')), 'cnt']],
        where: { parent_tweet_id: { [require('sequelize').Op.ne]: null } },
        group: ['parent_tweet_id'],
        raw: true,
      });
      for (const row of replyCounts) {
        const meta = this.tweetMeta.get(row.parent_tweet_id);
        if (meta) meta.engagement.replies = parseInt(row.cnt) || 0;
      }

      // Calculer la vélocité d'engagement pour chaque tweet
      const now = Date.now();
      for (const [tweetId, meta] of this.tweetMeta) {
        const totalEngagement = meta.engagement.likes + meta.engagement.retweets * 1.5 + meta.engagement.replies * 2;
        const ageHours = Math.max(1, (now - meta.createdAt.getTime()) / 3600000);
        meta.engagement.velocity = totalEngagement / ageHours;
      }

      console.log(`   📈 Engagement chargé: ${likeCounts.length} like groups, ${rtCounts.length} RT groups, ${replyCounts.length} reply groups`);
    } catch (err) {
      console.error('   ⚠️ Erreur chargement engagement:', err.message);
    }
  }

  /**
   * Charge les métadonnées des auteurs (followers, verified, etc).
   */
  async _loadAuthorMeta(models) {
    try {
      const { User } = models;
      const users = await User.findAll({
        where: { is_active: true },
        attributes: ['id', 'stats', 'verified', 'premium', 'is_suspended', 'suspended_until'],
        raw: true,
      });

      for (const user of users) {
        const stats = user.stats || {};
        this.authorMeta.set(user.id, {
          followersCount: parseInt(stats.followers) || 0,
          verified: !!user.verified,
          premium: !!user.premium,
          language: 'fr', // Default, User model n'a pas de champ language
          isSuspended: !!user.is_suspended,
          suspendedUntil: user.suspended_until ? new Date(user.suspended_until) : null
        });
        this.followerCounts.set(user.id, parseInt(stats.followers) || 0);
      }
      console.log(`   👤 ${users.length} profils auteurs chargés`);
    } catch (err) {
      console.error('   ⚠️ Erreur chargement author meta:', err.message);
    }
  }

  /**
   * Charge le graphe social (follows).
   */
  async _loadFollowGraph(models) {
    try {
      const { UserFollow } = models;
      if (!UserFollow) {
        console.log('   ⚠️ UserFollow model non disponible, skip follow graph');
        return;
      }

      const follows = await UserFollow.findAll({
        where: { status: 'active' },
        attributes: ['follower_id', 'following_id'],
        raw: true,
      });

      for (const f of follows) {
        if (!this.followGraph.has(f.follower_id)) {
          this.followGraph.set(f.follower_id, new Set());
        }
        this.followGraph.get(f.follower_id).add(f.following_id);
      }
      console.log(`   🔗 ${follows.length} relations de follow chargées`);
    } catch (err) {
      console.error('   ⚠️ Erreur chargement follow graph:', err.message);
    }
  }

  /**
   * Charge les langues préférées des utilisateurs.
   */
  async _loadUserLanguages(models) {
    try {
      // Le modèle User n'a pas de champ 'language' — on utilise la langue par défaut
      // et on peut la détecter via les tweets de l'utilisateur
      const { Tweet } = models;
      const { fn, col, Op } = require('sequelize');

      // Détecter la langue la plus fréquente des tweets de chaque user
      const langData = await Tweet.findAll({
        attributes: ['user_id', 'language', [fn('COUNT', col('id')), 'cnt']],
        where: { deleted_at: null, language: { [Op.ne]: null } },
        group: ['user_id', 'language'],
        order: [[fn('COUNT', col('id')), 'DESC']],
        raw: true,
      });

      // Garder la langue dominante par user
      const seen = new Set();
      for (const row of langData) {
        if (!seen.has(row.user_id)) {
          this.userLanguage.set(row.user_id, row.language || 'fr');
          seen.add(row.user_id);
        }
      }
      console.log(`   🌐 ${seen.size} langues utilisateur détectées`);
    } catch (err) {
      // Non-critique, tout le monde default à 'fr'
      console.log('   ⚠️ Langues non chargées (default fr)');
    }
  }

  /**
   * Construit les affinités hashtag des utilisateurs.
   */
  _buildHashtagAffinities(tweets) {
    // D'abord, construire un index tweet → hashtags
    const tweetHashtags = new Map();
    for (const tweet of tweets) {
      const hashtags = Array.isArray(tweet.hashtags)
        ? tweet.hashtags.map(h => h.toLowerCase())
        : extractHashtags(tweet.content);
      if (hashtags.length > 0) {
        tweetHashtags.set(tweet.id, hashtags);
      }
    }

    // Puis, pour chaque interaction utilisateur, accumuler les affinités
    for (const [userId, interactedTweets] of this.userInteractions) {
      const affinity = new Map();
      for (const tweetId of interactedTweets) {
        const hashtags = tweetHashtags.get(tweetId);
        if (!hashtags) continue;
        for (const h of hashtags) {
          affinity.set(h, (affinity.get(h) || 0) + 1);
        }
      }
      // Normaliser les affinités (0-1)
      if (affinity.size > 0) {
        const maxVal = Math.max(...affinity.values());
        for (const [h, v] of affinity) {
          affinity.set(h, v / maxVal);
        }
        this.userHashtagAffinity.set(userId, affinity);
      }
    }
  }

  /**
   * Reconstruit l'index complet depuis PostgreSQL.
   */
  async rebuildFromDB(models) {
    const t0 = Date.now();
    this.stats.indexBuilds++;

    try {
      const { Tweet, TweetLike, TweetRetweet, User, UserFollow } = models;
      const { Op, fn, col } = require('sequelize');

      // ── Tweets : vectoriser tous les tweets approuvés ──
      console.log('   📝 Chargement des tweets...');
      const tweets = await Tweet.findAll({
        where: {
          deleted_at: null,
          moderation_status: { [Op.in]: ['approved', 'pending'] },
          content: { [Op.ne]: null },
        },
        attributes: ['id', 'content', 'user_id', 'created_at', 'view_count', 'media_urls', 'language', 'hashtags', 'parent_tweet_id', 'tweet_type'],
        raw: true,
        order: [['created_at', 'DESC']],
        limit: 50000,
      });

      console.log(`   📝 ${tweets.length} tweets à vectoriser...`);
      let vectorized = 0;

      for (const tweet of tweets) {
        if (isSpamOrTest(tweet.content)) continue;

        let vec = vectorize(tweet.content);
        const hasMedia = Array.isArray(tweet.media_urls) && tweet.media_urls.length > 0;
        
        // Si la vectorisation échoue (ex: vidéo sans texte), on utilise un vecteur nul 
        // pour qu'elle puisse tout de même être recommandée par l'engagement (trending/collab/freshness)
        if (!vec) {
          if (hasMedia || tweet.tweet_type === 'video') {
             vec = new Float32Array(256); // ZERO vector (DIMS = 256)
          } else {
             continue;
          }
        }

        if (vec) {
          this.tweetStore.upsert(tweet.id, vec);

          const hashtags = Array.isArray(tweet.hashtags)
            ? tweet.hashtags.map(h => h.toLowerCase())
            : extractHashtags(tweet.content);

          this.tweetMeta.set(tweet.id, {
            authorId: tweet.user_id,
            createdAt: new Date(tweet.created_at),
            viewCount: tweet.view_count || 0,
            language: tweet.language || 'fr',
            hashtags,
            hasMedia: Array.isArray(tweet.media_urls) && tweet.media_urls.length > 0,
            contentLen: (tweet.content || '').length,
            parentTweetId: tweet.parent_tweet_id,
            type: tweet.tweet_type || 'tweet',
            engagement: { likes: 0, retweets: 0, replies: 0, velocity: 0 },
          });
          vectorized++;

          // Author tweets index
          if (!this.authorTweets.has(tweet.user_id)) this.authorTweets.set(tweet.user_id, new Set());
          this.authorTweets.get(tweet.user_id).add(tweet.id);

          // Discovery pool
          const age = Date.now() - new Date(tweet.created_at).getTime();
          if (age < DISCOVERY_WINDOW_H * 3600000 && (tweet.view_count || 0) < 30) {
            this.discoveryPool.set(tweet.id, {
              tweetId: tweet.id,
              vec,
              createdAt: new Date(tweet.created_at),
            });
          }
        }
      }
      console.log(`   ✅ ${vectorized} tweets vectorisés (${tweets.length - vectorized} skipped)`);

      // ── Likes : construire les interactions + user vectors ──
      console.log('   ❤️ Chargement des likes...');
      const likes = await TweetLike.findAll({
        attributes: ['user_id', 'tweet_id'],
        raw: true,
        limit: 200000,  // ↑ de 100K
      });

      for (const like of likes) {
        this._recordInteractionInternal(like.user_id, like.tweet_id, 'like');
      }
      console.log(`   ❤️ ${likes.length} likes intégrés`);

      // ── Retweets ──
      console.log('   🔄 Chargement des retweets...');
      const retweets = await TweetRetweet.findAll({
        attributes: ['user_id', 'tweet_id', 'retweet_type'],
        raw: true,
        limit: 200000,  // ↑ de 100K
      });

      for (const rt of retweets) {
        const type = rt.retweet_type === 'quote' ? 'quote' : 'retweet';
        this._recordInteractionInternal(rt.user_id, rt.tweet_id, type);
      }
      console.log(`   🔄 ${retweets.length} retweets intégrés`);

      // ── Réponses (comments) ──
      console.log('   💬 Chargement des réponses...');
      const replies = await Tweet.findAll({
        where: { parent_tweet_id: { [Op.ne]: null }, deleted_at: null },
        attributes: ['user_id', 'parent_tweet_id'],
        raw: true,
        limit: 200000,
      });
      for (const reply of replies) {
        this._recordInteractionInternal(reply.user_id, reply.parent_tweet_id, 'comment');
      }
      console.log(`   💬 ${replies.length} réponses intégrées`);

      // ── Posts : associer les tweets aux auteurs ──
      for (const tweet of tweets) {
        if (tweet.content) {
          this._recordInteractionInternal(tweet.user_id, tweet.id, 'post');
        }
      }

      // ── Engagement counts (batch) ──
      await this._loadEngagementCounts(models);

      // ── Author metadata ──
      await this._loadAuthorMeta(models);

      // ── Follow graph ──
      await this._loadFollowGraph(models);

      // ── User languages ──
      await this._loadUserLanguages(models);

      // ── Hashtag affinities ──
      this._buildHashtagAffinities(tweets);

      // Sauvegarder
      this.tweetStore.save();
      this.userStore.save();

      const elapsed = Date.now() - t0;
      console.log(`   🏁 Rebuild V2 terminé en ${elapsed}ms`);

    } catch (err) {
      console.error('   ❌ Erreur rebuild:', err.message);
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  INTERACTIONS EN TEMPS RÉEL
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * Enregistre une interaction et met à jour le user vector en temps réel.
   */
  onInteraction(userId, tweetId, type, content = '') {
    // Vectoriser le tweet s'il n'est pas encore dans l'index
    if (!this.tweetStore.has(tweetId) && content) {
      const vec = vectorize(content);
      if (vec) {
        this.tweetStore.upsert(tweetId, vec);
      }
    }

    this._recordInteractionInternal(userId, tweetId, type);

    // Mettre à jour l'engagement en temps réel
    const meta = this.tweetMeta.get(tweetId);
    if (meta) {
      if (type === 'like') meta.engagement.likes++;
      else if (type === 'retweet' || type === 'quote') meta.engagement.retweets++;
      else if (type === 'comment') meta.engagement.replies++;
      // Recalculer la vélocité
      const ageHours = Math.max(1, (Date.now() - meta.createdAt.getTime()) / 3600000);
      const total = meta.engagement.likes + meta.engagement.retweets * 1.5 + meta.engagement.replies * 2;
      meta.engagement.velocity = total / ageHours;
    }

    // Mettre à jour l'affinité hashtag de l'user en temps réel
    if (meta && meta.hashtags && meta.hashtags.length > 0) {
      if (!this.userHashtagAffinity.has(userId)) {
        this.userHashtagAffinity.set(userId, new Map());
      }
      const affinity = this.userHashtagAffinity.get(userId);
      for (const h of meta.hashtags) {
        affinity.set(h, (affinity.get(h) || 0) + 0.1);
      }
    }

    this.stats.interactionsRecorded++;
  }

  /**
   * Enregistre un nouveau tweet et l'ajoute au discovery pool.
   */
  onNewTweet(tweetId, userId, content, mediaUrls = [], parentTweetId = null, originalTweetId = null, tweetType = 'tweet') {
    if (isSpamOrTest(content)) return;

    let vec = vectorize(content);
    const hasMedia = Array.isArray(mediaUrls) && mediaUrls.length > 0;

    if (!vec) {
      if (hasMedia || tweetType === 'video') {
         vec = new Float32Array(256);
      } else {
        console.log(`⚠️ [onNewTweet] Vectorisation échouée pour tweet ${tweetId} (contenu: "${(content || '').substring(0, 50)}...")`);
        return;
      }
    }

    // Ajouter à l'index vectoriel
    this.tweetStore.upsert(tweetId, vec);

    const hashtags = extractHashtags(content);

    // Meta enrichie
    this.tweetMeta.set(tweetId, {
      authorId: userId,
      createdAt: new Date(),
      viewCount: 0,
      language: this.userLanguage.get(userId) || 'fr',
      hashtags,
      hasMedia: Array.isArray(mediaUrls) && mediaUrls.length > 0,
      contentLen: (content || '').length,
      parentTweetId: parentTweetId,
      originalTweetId: originalTweetId,
      type: tweetType,
      engagement: { likes: 0, retweets: 0, replies: 0, velocity: 0 },
    });

    // Author tweets index
    if (!this.authorTweets.has(userId)) this.authorTweets.set(userId, new Set());
    this.authorTweets.get(userId).add(tweetId);

    // Discovery pool pour exposition
    this.discoveryPool.set(tweetId, { tweetId, vec, createdAt: new Date() });

    // Interaction "post"
    this._recordInteractionInternal(userId, tweetId, 'post');

    // 🚨 INVALIDER TOUS LES CACHES DE RECOMMANDATIONS
    // Pour que le prochain appel de chaque user regénère un feed incluant ce nouveau tweet
    this.recoCache.clear();
    console.log(`🧠 [onNewTweet] Tweet ${tweetId} ajouté au moteur + caches de recommandation invalidés`);
  }

  /**
   * Met à jour le graphe social en temps réel.
   */
  onFollow(followerId, followingId) {
    if (!this.followGraph.has(followerId)) {
      this.followGraph.set(followerId, new Set());
    }
    this.followGraph.get(followerId).add(followingId);
    // Incrémenter le follower count
    this.followerCounts.set(followingId, (this.followerCounts.get(followingId) || 0) + 1);
  }

  onUnfollow(followerId, followingId) {
    const following = this.followGraph.get(followerId);
    if (following) following.delete(followingId);
    const count = this.followerCounts.get(followingId) || 0;
    if (count > 0) this.followerCounts.set(followingId, count - 1);
  }

  /**
   * Interne : met à jour le user vector via EWMA.
   */
  _recordInteractionInternal(userId, tweetId, type) {
    // Enregistrer l'interaction
    if (!this.userInteractions.has(userId)) {
      this.userInteractions.set(userId, new Set());
    }
    this.userInteractions.get(userId).add(tweetId);

    // Mettre à jour le user vector
    const tweetVec = this.tweetStore.get(tweetId);
    if (!tweetVec) return;

    const weight = INTERACTION_WEIGHTS[type] || 1.0;
    let userVec = this.userStore.get(userId);

    if (!userVec) {
      // Première interaction : copier le tweet vec pondéré
      userVec = new Float32Array(DIMS);
      for (let i = 0; i < DIMS; i++) userVec[i] = tweetVec[i];
      vecNormalize(userVec);
      this.userStore.upsert(userId, userVec);
    } else {
      // EWMA update
      vecEWMA(userVec, tweetVec, weight);
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  TRENDING ENGINE
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * Retourne les tweets trending, avec un cache de 3 minutes.
   * @returns {Array<{tweetId:string, velocity:number}>}
   */
  _getTrendingTweets(topN = 500) {
    const now = Date.now();
    if (now - this._trendingCache.ts < TRENDING_CACHE_TTL_MS && this._trendingCache.list.length > 0) {
      return this._trendingCache.list;
    }

    const candidates = [];
    for (const [tweetId, meta] of this.tweetMeta) {
      // Seulement les tweets des dernières 72h
      const ageMs = now - meta.createdAt.getTime();
      if (ageMs > DISCOVERY_WINDOW_H * 3600000) continue;

      if (meta.engagement.velocity > 0.1) {
        candidates.push({ tweetId, velocity: meta.engagement.velocity });
      }
    }

    // Trier par vélocité desc
    candidates.sort((a, b) => b.velocity - a.velocity);
    const result = candidates.slice(0, topN);

    this._trendingCache = { ts: now, list: result };
    return result;
  }

  /**
   * Helper récursif pour trouver si le root d'un thread est une vidéo.
   */
  _isRootVideo(tweetId, depth = 0) {
    if (depth > 12) return false; // Protection récursion infinie
    const meta = this.tweetMeta.get(tweetId);
    if (!meta) return false;
    
    if (meta.type === 'video') return true;
    if (meta.parentTweetId) {
      return this._isRootVideo(meta.parentTweetId, depth + 1);
    }
    return false;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  RECOMMANDATIONS — COEUR DE L'ALGORITHME V2
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * Génère les recommandations pour un utilisateur.
   *
   * @param {string} userId
   * @param {number} limit
   * @param {Object} [options]
   * @returns {Array<{tweetId:string, score:number, components:Object}>}
   */
  getRecommendations(userId, limit = 50, options = {}) {
    const t0 = Date.now();

    // 🚨 DÉTECTION DE BOT INSTANTANÉE (Asynchrone)
    botDetectionService.analyzeAndSanction(userId).catch(err => {
      // On ne loggue pas l'erreur de manière bruyante ici pour la performance
    });

    // ── Cache check ──
    const offset = options.offset || 0;
    const forceRefresh = (offset === 0);

    const cacheKey = `${userId}_${options.onlyFollowing ? 'following' : 'all'}_${options.tweetType || 'default'}`;

    const cached = this.recoCache.get(cacheKey);
    if (!forceRefresh && cached && (Date.now() - cached.ts) < MAX_CACHE_AGE_MS) {
      this.stats.cacheHits++;
      return cached.results.slice(offset, offset + limit);
    }

    const userVec = this.userStore.get(userId);
    const seenTweets = this.userInteractions.get(userId) || new Set();
    const exclude = options.exclude || new Set();

    // ── Décider du mode : Cold Start vs Normal ──
    const isColdStart = !userVec && seenTweets.size < 3;

    let feed;
    if (isColdStart) {
      feed = this._generateColdStartFeed(userId, seenTweets, exclude, options);
      this.stats.coldStartServed++;
    } else {
      feed = this._generateNormalFeed(userId, userVec, seenTweets, exclude, options);
    }

    // ── Post-processing : Author Diversity ──
    feed = this._applyAuthorDiversity(feed);

    // ── Statistiques ──
    const elapsed = Date.now() - t0;
    this.stats.totalRecommendations++;
    this.stats.avgRecoMs =
      (this.stats.avgRecoMs * (this.stats.totalRecommendations - 1) + elapsed)
      / this.stats.totalRecommendations;

    // Cache
    this.recoCache.set(cacheKey, { ts: Date.now(), results: feed, poolSize: feed.length });

    return feed.slice(offset, offset + limit);
  }

  /**
   * Feed pour un utilisateur existant avec historique.
   */
  _generateNormalFeed(userId, userVec, seenTweets, exclude, options = {}) {
    const now = Date.now();
    const userLang = this.userLanguage.get(userId) || 'fr';
    const followedAuthors = this.followGraph.get(userId) || new Set();
    const hashtagAffinity = this.userHashtagAffinity.get(userId) || new Map();

    // ── Phase 1 : Candidats (multi-source) ──
    const scored = new Map();

    // 1a. Content-based candidates (top similaires au user vector)
    if (userVec) {
      for (const [tweetId, tweetVec] of this.tweetStore.index) {
        if (seenTweets.has(tweetId) || exclude.has(tweetId)) continue;
        const meta = this.tweetMeta.get(tweetId);
        if (!meta) continue;
        // Pour les vidéos, on garde ses propres contenus (TikTok-like)
        if (meta.authorId === userId && options.tweetType !== 'video') continue;

        // Filtrage strict par type (tweet classique vs vidéo)
        if (options.tweetType) {
          if (meta.type !== options.tweetType) continue;
        } else {
          if (meta.type === 'video') continue;
          // 🚓 NOUVEAU : Exclure TOUTES les réponses du fil de recommandation principal
          // (Comme dans le fil classique, on ne veut que des tweets originaux, retweets ou quotes)
          if (meta.type === 'reply' || meta.parentTweetId) continue;
        }

        // 🚓 FILTRAGE BANS : Exclure les auteurs suspendus
        const authorInfo = this.authorMeta.get(meta.authorId);
        if (authorInfo && authorInfo.isSuspended) continue;
        
        // Exclure les réponses ou retweets/quotes liés à des auteurs suspendus
        const referenceId = meta.parentTweetId || meta.originalTweetId;
        if (referenceId) {
          const refMeta = this.tweetMeta.get(referenceId);
          if (refMeta) {
            const refAuthorInfo = this.authorMeta.get(refMeta.authorId);
            if (refAuthorInfo && refAuthorInfo.isSuspended) continue;
          }
        }

        if (options.onlyFollowing && !followedAuthors.has(meta.authorId)) continue;

        const contentScore = cosineSim(userVec, tweetVec);
        scored.set(tweetId, {
          content: Math.max(0, contentScore),
          collab: 0, follow: 0, trending: 0,
          freshness: 0, discovery: 0, language: 0,
          quality: 0,
        });
      }
    } else {
      // User a un historique mais pas de vector → tous les tweets sont candidats
      for (const [tweetId] of this.tweetStore.index) {
        if (seenTweets.has(tweetId) || exclude.has(tweetId)) continue;
        const meta = this.tweetMeta.get(tweetId);
        if (!meta) continue;
        if (meta.authorId === userId && options.tweetType !== 'video') continue;

        if (options.tweetType) {
          if (meta.type !== options.tweetType) continue;
        } else {
          if (meta.type === 'video') continue;
          // 🚓 NOUVEAU : Exclure les commentaires de vidéos
          if (meta.type === 'reply' || meta.parentTweetId) {
            if (this._isRootVideo(tweetId)) continue;
          }
        }

        if (options.onlyFollowing && !followedAuthors.has(meta.authorId)) continue;
        scored.set(tweetId, {
          content: 0, collab: 0, follow: 0, trending: 0,
          freshness: 0, discovery: 0, language: 0, quality: 0,
        });
      }
    }

    // ── Phase 2 : Collaborative Filtering ──
    if (userVec) {
      const similarUsers = this.userStore.search(userVec, SIMILAR_USERS_K, new Set([userId]));

      for (const { id: simUserId, score: simScore } of similarUsers) {
        if (simScore < 0.08) continue;

        const simInteractions = this.userInteractions.get(simUserId);
        if (!simInteractions) continue;

        let count = 0;
        for (const tweetId of simInteractions) {
          if (count >= COLLAB_TWEET_LIMIT) break;
          if (seenTweets.has(tweetId) || exclude.has(tweetId)) continue;
          
          const meta = this.tweetMeta.get(tweetId);
          if (options.onlyFollowing && (!meta || !followedAuthors.has(meta.authorId))) continue;

          const entry = scored.get(tweetId);
          if (entry) {
            entry.collab += simScore * 0.12;
            entry.collab = Math.min(entry.collab, 1.0);
          }
          count++;
        }
      }
    }

    // ── Phase 3 : Follow Graph Boost ──
    for (const followedAuthorId of followedAuthors) {
      const authorTweetIds = this.authorTweets.get(followedAuthorId);
      if (!authorTweetIds) continue;

      for (const tweetId of authorTweetIds) {
        if (seenTweets.has(tweetId) || exclude.has(tweetId)) continue;
        const entry = scored.get(tweetId);
        if (entry) {
          entry.follow = 0.85; // Fort bonus pour les auteurs suivis
        }
      }
    }

    // ── Phase 4 : Freshness + Discovery + Trending + Language + Quality ──
    for (const [tweetId, components] of scored) {
      const meta = this.tweetMeta.get(tweetId);
      if (!meta) continue;

      // Freshness : décroissance exponentielle (demi-vie = 18h)
      const ageMs = now - meta.createdAt.getTime();
      const ageHours = ageMs / 3600000;
      components.freshness = Math.exp(-ageHours / FRESHNESS_HALF_LIFE_H);

      // Discovery boost : tweets avec très peu de vues
      if (meta.viewCount < 30 && ageHours < DISCOVERY_WINDOW_H) {
        components.discovery = 1.0 - (meta.viewCount / 30);
      }

      // Trending : engagement velocity normalisé
      if (meta.engagement.velocity > 0) {
        if (meta.engagement.velocity >= VELOCITY_HIGH_THRESHOLD) {
          components.trending = 1.0;
        } else if (meta.engagement.velocity >= VELOCITY_MID_THRESHOLD) {
          components.trending = 0.5 + 0.5 * (meta.engagement.velocity - VELOCITY_MID_THRESHOLD) / (VELOCITY_HIGH_THRESHOLD - VELOCITY_MID_THRESHOLD);
        } else {
          components.trending = meta.engagement.velocity / VELOCITY_MID_THRESHOLD * 0.5;
        }
      }

      // Language match
      if (meta.language && meta.language === userLang) {
        components.language = 1.0;
      } else {
        components.language = 0.2; // Pénalité légère, pas exclusion
      }

      // Hashtag affinity bonus (ajouté au content score)
      if (meta.hashtags && hashtagAffinity.size > 0) {
        let hashScore = 0;
        for (const h of meta.hashtags) {
          const aff = hashtagAffinity.get(h);
          if (aff) hashScore += aff;
        }
        // Ajouter comme bonus au content score (capped at 0.3)
        components.content = Math.min(1.0, components.content + Math.min(0.3, hashScore * 0.15));
      }

      // Quality bonus (contenu riche = plus intéressant)
      if (meta.hasMedia) components.quality += 0.08;
      if (meta.contentLen > 80) components.quality += 0.04;
      if (meta.contentLen > 150) components.quality += 0.04;
      // Author popularity micro-boost
      const authorInfo = this.authorMeta.get(meta.authorId);
      if (authorInfo) {
        if (authorInfo.verified) components.quality += 0.12;  // ↑ boost vérifiés (0.06 → 0.12)
        if (authorInfo.followersCount > 100) components.quality += 0.03;
      }

      // 🚓 BOOST DISCOVERY pour les tweets récents avec peu de vues (pousse les nouveaux contenus)
      if (meta.viewCount < 10 && ageHours < 6) {
        components.discovery = Math.max(components.discovery, 0.8);
      }
    }

    // ── Phase 5 : Score final combiné ──
    const results = [];
    for (const [tweetId, c] of scored) {
      let score =
        WEIGHTS.CONTENT * c.content +
        WEIGHTS.COLLAB * c.collab +
        WEIGHTS.FOLLOW * c.follow +
        WEIGHTS.TRENDING * c.trending +
        WEIGHTS.FRESHNESS * c.freshness +
        WEIGHTS.DISCOVERY * c.discovery +
        WEIGHTS.LANGUAGE * c.language +
        c.quality; // Quality est un bonus additif

      // 🚓 Réduction de visibilité (90% en moins) pour les tweets PolicierCongo de plus de 30 jours (720h)
      const meta = this.tweetMeta.get(tweetId);
      if (meta && meta.authorId === '6b10b4b9-1520-4b44-84ff-17fdaa33548b') {
        const ageHours = (now - meta.createdAt.getTime()) / 3600000;
        if (ageHours > 720) score *= 0.05;
      }

      results.push({ tweetId, score, components: c });
    }

    // ── Phase 6 : Top-K avec garantie discovery ──
    const sorted = topK(results, CACHED_POOL_SIZE * 2);

    // Garantir un minimum de discovery tweets
    const discoveryTweets = sorted.filter(r => r.components.discovery > 0.3);
    const normalTweets = sorted.filter(r => r.components.discovery <= 0.3);

    const discoveryCount = Math.max(
      Math.ceil(CACHED_POOL_SIZE * DISCOVERY_MIN_RATIO),
      Math.min(discoveryTweets.length, Math.ceil(CACHED_POOL_SIZE * 0.25))
    );
    const normalCount = CACHED_POOL_SIZE - Math.min(discoveryCount, discoveryTweets.length);

    // Assembler le feed final
    const feed = [
      ...normalTweets.slice(0, normalCount),
      ...discoveryTweets.slice(0, discoveryCount),
    ].sort((a, b) => b.score - a.score).slice(0, CACHED_POOL_SIZE);

    return feed;
  }

  /**
   * Feed pour un nouveau user sans historique (COLD START).
   * Utilise les signaux globaux (trending, popularité auteur, fraîcheur).
   */
  _generateColdStartFeed(userId, seenTweets, exclude, options = {}) {
    const now = Date.now();
    const userLang = this.userLanguage.get(userId) || 'fr';
    const followedAuthors = this.followGraph.get(userId) || new Set();

    const results = [];
    const seenHashtagGroups = new Map(); // Pour diversité

    for (const [tweetId] of this.tweetStore.index) {
      if (seenTweets.has(tweetId) || exclude.has(tweetId)) continue;

      const meta = this.tweetMeta.get(tweetId);
      if (!meta) continue;
      if (meta.authorId === userId && options.tweetType !== 'video') continue;

      if (options.tweetType) {
        if (meta.type !== options.tweetType) continue;
      } else {
        if (meta.type === 'video') continue;
        // 🚓 NOUVEAU : Exclure les commentaires de vidéos
        if (meta.type === 'reply' || meta.parentTweetId) {
          if (this._isRootVideo(tweetId)) continue;
        }
      }

      // 🚓 FILTRAGE BANS : Exclure les auteurs suspendus
      const authorInfo = this.authorMeta.get(meta.authorId);
      if (authorInfo && authorInfo.isSuspended) continue;

      // Exclure les réponses ou retweets/quotes liés à des auteurs suspendus
      const referenceId = meta.parentTweetId || meta.originalTweetId;
      if (referenceId) {
        const refMeta = this.tweetMeta.get(referenceId);
        if (refMeta) {
          const refAuthorInfo = this.authorMeta.get(refMeta.authorId);
          if (refAuthorInfo && refAuthorInfo.isSuspended) continue;
        }
      }

      if (options.onlyFollowing && !followedAuthors.has(meta.authorId)) continue;

      const ageMs = now - meta.createdAt.getTime();
      const ageHours = ageMs / 3600000;

      // ── Trending Score (vélocité d'engagement) ──
      let trendingScore = 0;
      if (meta.engagement.velocity >= VELOCITY_HIGH_THRESHOLD) {
        trendingScore = 1.0;
      } else if (meta.engagement.velocity >= VELOCITY_MID_THRESHOLD) {
        trendingScore = 0.5 + 0.5 * (meta.engagement.velocity - VELOCITY_MID_THRESHOLD) / (VELOCITY_HIGH_THRESHOLD - VELOCITY_MID_THRESHOLD);
      } else if (meta.engagement.velocity > 0) {
        trendingScore = meta.engagement.velocity / VELOCITY_MID_THRESHOLD * 0.5;
      }

      // ── Likes Score (NOUVEAU) ──
      let likesScore = 0;
      if (meta.engagement.likes > 0) {
        // Échelle logarithmique : 10 likes = 0.4, 100 likes = 0.8, 300+ likes ≈ 1.0
        likesScore = Math.min(1.0, Math.log10(meta.engagement.likes + 1) / 2.5);
      }

      // ── Author Popularity Score ──
      let popularityScore = 0;
      if (authorInfo) {
        if (authorInfo.verified) popularityScore += 0.4;
        if (authorInfo.premium) popularityScore += 0.1;
        // Log scale pour followers (0 = 0, 1000 = 0.5, 10000 = 0.67, 100000 = 0.83...)
        if (authorInfo.followersCount > 0) {
          popularityScore += Math.min(0.5, Math.log10(authorInfo.followersCount) / 10);
        }
        popularityScore = Math.min(1.0, popularityScore);
      }

      // Bonus si l'user suit cet auteur
      if (followedAuthors.has(meta.authorId)) {
        popularityScore = Math.min(1.0, popularityScore + 0.3);
      }

      // ── Freshness Score ──
      const freshnessScore = Math.exp(-ageHours / FRESHNESS_HALF_LIFE_H);

      // ── Language Score ──
      const languageScore = (meta.language === userLang) ? 1.0 : 0.15;

      // ── Diversity Score (pénaliser les hashtags déjà trop vus) ──
      let diversityScore = 0.5;
      if (meta.hashtags && meta.hashtags.length > 0) {
        const mainHash = meta.hashtags[0];
        const count = seenHashtagGroups.get(mainHash) || 0;
        diversityScore = Math.max(0.1, 1.0 - count * 0.15);
        seenHashtagGroups.set(mainHash, count + 1);
      }

      // ── Quality bonus ──
      let quality = 0;
      if (meta.hasMedia) quality += 0.05;
      if (meta.contentLen > 80) quality += 0.03;
      if (meta.engagement.likes > 5) quality += 0.03;
      if (meta.engagement.replies > 2) quality += 0.02;

      // ── Score final cold start ──
      let score =
        COLD_START_WEIGHTS.LIKES * likesScore +
        COLD_START_WEIGHTS.TRENDING * trendingScore +
        COLD_START_WEIGHTS.POPULARITY * popularityScore +
        COLD_START_WEIGHTS.FRESHNESS * freshnessScore +
        COLD_START_WEIGHTS.DIVERSITY * diversityScore +
        COLD_START_WEIGHTS.LANGUAGE * languageScore +
        quality;

      // 🚓 Réduction de visibilité (90% en moins) pour les tweets PolicierCongo de plus de 30 jours (720h)
      if (meta.authorId === '6b10b4b9-1520-4b44-84ff-17fdaa33548b' && ageHours > 720) {
        score *= 0.10;
      }

      results.push({
        tweetId,
        score,
        components: {
          content: 0,
          collab: 0,
          follow: followedAuthors.has(meta.authorId) ? 0.85 : 0,
          likes: likesScore,
          trending: trendingScore,
          freshness: freshnessScore,
          discovery: (meta.viewCount < 30) ? (1.0 - meta.viewCount / 30) : 0,
          language: languageScore,
          quality,
          popularity: popularityScore,
          diversity: diversityScore,
        },
      });
    }

    // Top-K
    const sorted = topK(results, CACHED_POOL_SIZE);
    return sorted;
  }

  /**
   * Post-processing : limiter les tweets consécutifs d'un même auteur.
   */
  _applyAuthorDiversity(feed) {
    if (feed.length <= AUTHOR_DIVERSITY_WINDOW) return feed;

    const result = [];
    const recentAuthors = []; // Fenêtre glissante des derniers auteurs

    for (const item of feed) {
      const meta = this.tweetMeta.get(item.tweetId);
      if (!meta) {
        result.push(item);
        continue;
      }

      const authorId = meta.authorId;

      // Compter combien de fois cet auteur apparaît dans la fenêtre récente
      const authorCountInWindow = recentAuthors.filter(a => a === authorId).length;

      if (authorCountInWindow >= MAX_SAME_AUTHOR_WINDOW) {
        // Pousser vers le bas avec un score réduit mais ne pas supprimer
        result.push({ ...item, score: item.score * 0.5 });
      } else {
        result.push(item);
      }

      // Maintenir la fenêtre glissante
      recentAuthors.push(authorId);
      if (recentAuthors.length > AUTHOR_DIVERSITY_WINDOW) {
        recentAuthors.shift();
      }
    }

    // Re-trier après ajustement de diversité
    result.sort((a, b) => b.score - a.score);
    return result;
  }

  /**
   * Retourne la taille réelle du pool de recommandations pour un user.
   * Utilisé par la pagination réelle.
   */
  getCachedPoolSize(userId, options = {}) {
    const cacheKey = `${userId}_${options.onlyFollowing ? 'following' : 'all'}_${options.tweetType || 'default'}`;
    const cached = this.recoCache.get(cacheKey);
    if (cached) return cached.poolSize;
    return 0;
  }

  /**
   * Retourne les utilisateurs les plus similaires à un user donné.
   */
  getSimilarUsers(userId, k = 10) {
    const userVec = this.userStore.get(userId);
    if (!userVec) return [];
    return this.userStore.search(userVec, k, new Set([userId]));
  }

  /**
   * Retourne les tweets les plus similaires à un tweet donné.
   */
  getSimilarTweets(tweetId, k = 10) {
    const tweetVec = this.tweetStore.get(tweetId);
    if (!tweetVec) return [];
    return this.tweetStore.search(tweetVec, k, new Set([tweetId]));
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  MAINTENANCE
  // ═══════════════════════════════════════════════════════════════════════════

  /** Invalide le cache d'un user */
  _invalidateCache(userId) {
    this.recoCache.delete(userId);
  }

  /** Purge les tweets du discovery pool expirés */
  _purgeDiscoveryPool() {
    const cutoff = Date.now() - DISCOVERY_WINDOW_H * 3600000;
    for (const [id, entry] of this.discoveryPool) {
      if (entry.createdAt.getTime() < cutoff) {
        this.discoveryPool.delete(id);
      }
    }
  }

  /** Sauvegarde périodique des index */
  _periodicSave() {
    try {
      this._purgeDiscoveryPool();
      const t = this.tweetStore.save();
      const u = this.userStore.save();
      if (t || u) {
        console.log(`💾 [Similarity V2] Index sauvegardés: ${t || 0} tweets, ${u || 0} users`);
      }
    } catch (err) {
      console.error('❌ [Similarity V2] Erreur sauvegarde périodique:', err.message);
    }
  }

  /** Met à jour les métadonnées de vue d'un tweet */
  incrementViewCount(tweetId) {
    const meta = this.tweetMeta.get(tweetId);
    if (meta) {
      meta.viewCount++;
      if (meta.viewCount >= 30) {
        this.discoveryPool.delete(tweetId);
      }
    }
  }

  /** Statistiques complètes */
  getStats() {
    return {
      engine: 'SimilarityRecommendationEngine',
      version: '2.0.0',
      initialized: this._initialized,
      tweetVectors: this.tweetStore.getStats(),
      userVectors: this.userStore.getStats(),
      discoveryPoolSize: this.discoveryPool.size,
      cacheSize: this.recoCache.size,
      followGraphSize: this.followGraph.size,
      authorProfilesCount: this.authorMeta.size,
      hashtagAffinityUsers: this.userHashtagAffinity.size,
      totalInteractionsTracked: this.userInteractions.size,
      trendingCacheAge: Date.now() - this._trendingCache.ts,
      ...this.stats,
    };
  }

  /** Arrêt propre */
  shutdown() {
    if (this._saveTimer) {
      clearInterval(this._saveTimer);
      this._saveTimer = null;
    }
    this._periodicSave();
    console.log('🛑 [Similarity V2] Moteur arrêté proprement');
  }
}

module.exports = { SimilarityRecommendationEngine };
