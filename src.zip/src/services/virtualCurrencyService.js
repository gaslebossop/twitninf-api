const crypto = require('crypto');
const { Op } = require('sequelize');
const VirtualCurrency = require('../models/VirtualCurrency');
const UserWallet = require('../models/UserWallet');
const Transaction = require('../models/Transaction');
const User = require('../models/User');
const logger = require('../utils/logger');

class VirtualCurrencyService {
  /**
   * Créer une nouvelle cryptomonnaie
   */
  static async createCurrency(currencyData) {
    try {
      const currency = await VirtualCurrency.create(currencyData);
      logger.info(`Nouvelle cryptomonnaie créée: ${currency.symbol}`);
      return currency;
    } catch (error) {
      logger.error('Erreur lors de la création de la cryptomonnaie:', error);
      throw error;
    }
  }

  /**
   * Obtenir les informations d'une cryptomonnaie
   */
  static async getCurrency(symbol) {
    try {
      const currency = await VirtualCurrency.findOne({
        where: { symbol, isActive: true }
      });
      return currency;
    } catch (error) {
      logger.error('Erreur lors de la récupération de la cryptomonnaie:', error);
      throw error;
    }
  }

  /**
   * Obtenir le portefeuille d'un utilisateur
   */
  static async getUserWallet(userId, currencyId) {
    try {
      let wallet = await UserWallet.findOne({
        where: { userId, currencyId }
      });

      if (!wallet) {
        // Créer un portefeuille si il n'existe pas
        wallet = await UserWallet.create({
          userId,
          currencyId,
          balance: 0,
          totalEarned: 0,
          totalSpent: 0
        });
      }

      return wallet;
    } catch (error) {
      logger.error('Erreur lors de la récupération du portefeuille:', error);
      throw error;
    }
  }

  /**
   * Miner de la cryptomonnaie (récompense pour actions)
   */
  static async mineCurrency(userId, currencyId, action, amount = null) {
    try {
      const currency = await VirtualCurrency.findByPk(currencyId);
      if (!currency || !currency.isActive) {
        throw new Error('Cryptomonnaie non disponible');
      }

      const wallet = await this.getUserWallet(userId, currencyId);
      
      // Vérifier la limite quotidienne
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (wallet.lastMiningDate && wallet.lastMiningDate >= today) {
        if (wallet.dailyMiningCount >= currency.maxMiningPerDay) {
          throw new Error('Limite quotidienne de minage atteinte');
        }
      } else {
        // Reset du compteur quotidien
        wallet.dailyMiningCount = 0;
      }

      // Calculer la récompense
      const reward = amount || currency.miningReward;
      
      // Mettre à jour le portefeuille
      await wallet.update({
        balance: parseFloat(wallet.balance) + parseFloat(reward),
        totalEarned: parseFloat(wallet.totalEarned) + parseFloat(reward),
        lastMiningDate: new Date(),
        dailyMiningCount: wallet.dailyMiningCount + 1
      });

      // Créer la transaction
      const transaction = await this.createTransaction({
        fromUserId: null, // Système
        toUserId: userId,
        currencyId,
        amount: reward,
        amountInEur: parseFloat(reward) * parseFloat(currency.currentPrice),
        type: 'MINING',
        status: 'COMPLETED',
        description: `Minage pour: ${action}`,
        metadata: { action, reward }
      });

      // Mettre à jour l'offre en circulation
      await currency.update({
        circulatingSupply: parseFloat(currency.circulatingSupply) + parseFloat(reward)
      });

      logger.info(`Minage effectué: ${reward} ${currency.symbol} pour l'utilisateur ${userId}`);
      return { wallet, transaction };
    } catch (error) {
      logger.error('Erreur lors du minage:', error);
      throw error;
    }
  }

  /**
   * Transférer de la cryptomonnaie entre utilisateurs
   */
  static async transferCurrency(fromUserId, toUserId, currencyId, amount, description = '') {
    try {
      const currency = await VirtualCurrency.findByPk(currencyId);
      if (!currency || !currency.isActive) {
        throw new Error('Cryptomonnaie non disponible');
      }

      const fromWallet = await this.getUserWallet(fromUserId, currencyId);
      const toWallet = await this.getUserWallet(toUserId, currencyId);

      // Vérifier le solde
      if (parseFloat(fromWallet.balance) < parseFloat(amount)) {
        throw new Error('Solde insuffisant');
      }

      // Calculer les frais (0.5% par défaut)
      const fee = parseFloat(amount) * 0.005;
      const netAmount = parseFloat(amount) - fee;

      // Mettre à jour les portefeuilles
      await fromWallet.update({
        balance: parseFloat(fromWallet.balance) - parseFloat(amount),
        totalSpent: parseFloat(fromWallet.totalSpent) + parseFloat(amount)
      });

      await toWallet.update({
        balance: parseFloat(toWallet.balance) + netAmount,
        totalEarned: parseFloat(toWallet.totalEarned) + netAmount
      });

      // Créer la transaction
      const transaction = await this.createTransaction({
        fromUserId,
        toUserId,
        currencyId,
        amount: netAmount,
        amountInEur: netAmount * parseFloat(currency.currentPrice),
        type: 'TRANSFER',
        status: 'COMPLETED',
        fee,
        description: description || 'Transfert de cryptomonnaie',
        metadata: { originalAmount: amount, fee }
      });

      logger.info(`Transfert effectué: ${netAmount} ${currency.symbol} de ${fromUserId} vers ${toUserId}`);
      return { transaction, fee };
    } catch (error) {
      logger.error('Erreur lors du transfert:', error);
      throw error;
    }
  }

  /**
   * Créer une transaction
   */
  static async createTransaction(transactionData) {
    try {
      const transactionHash = crypto.randomBytes(32).toString('hex');
      
      const transaction = await Transaction.create({
        ...transactionData,
        transactionHash,
        confirmedAt: new Date()
      });

      return transaction;
    } catch (error) {
      logger.error('Erreur lors de la création de la transaction:', error);
      throw error;
    }
  }

  /**
   * Obtenir l'historique des transactions d'un utilisateur
   */
  static async getUserTransactions(userId, currencyId = null, limit = 50, offset = 0) {
    try {
      const where = {
        [Op.or]: [
          { fromUserId: userId },
          { toUserId: userId }
        ]
      };

      if (currencyId) {
        where.currencyId = currencyId;
      }

      const transactions = await Transaction.findAll({
        where,
        order: [['createdAt', 'DESC']],
        limit,
        offset,
        include: [
          {
            model: VirtualCurrency,
            as: 'currency',
            attributes: ['name', 'symbol', 'icon', 'color']
          },
          {
            model: User,
            as: 'fromUser',
            attributes: ['username', 'avatar']
          },
          {
            model: User,
            as: 'toUser',
            attributes: ['username', 'avatar']
          }
        ]
      });

      return transactions;
    } catch (error) {
      logger.error('Erreur lors de la récupération des transactions:', error);
      throw error;
    }
  }

  /**
   * Mettre à jour le prix de la cryptomonnaie
   */
  static async updatePrice(currencyId, newPrice) {
    try {
      const currency = await VirtualCurrency.findByPk(currencyId);
      if (!currency) {
        throw new Error('Cryptomonnaie non trouvée');
      }

      const oldPrice = parseFloat(currency.currentPrice);
      const priceChange = ((newPrice - oldPrice) / oldPrice) * 100;

      // Mettre à jour l'historique des prix
      const priceHistory = currency.priceHistory || [];
      priceHistory.push({
        price: newPrice,
        timestamp: new Date().toISOString(),
        change: priceChange
      });

      // Garder seulement les 1000 derniers prix
      if (priceHistory.length > 1000) {
        priceHistory.splice(0, priceHistory.length - 1000);
      }

      await currency.update({
        currentPrice: newPrice,
        priceChange24h: priceChange,
        priceHistory,
        marketCap: parseFloat(currency.circulatingSupply) * newPrice
      });

      logger.info(`Prix mis à jour pour ${currency.symbol}: ${oldPrice} → ${newPrice}`);
      return currency;
    } catch (error) {
      logger.error('Erreur lors de la mise à jour du prix:', error);
      throw error;
    }
  }

  /**
   * Obtenir les statistiques de la cryptomonnaie
   */
  static async getCurrencyStats(currencyId) {
    try {
      const currency = await VirtualCurrency.findByPk(currencyId);
      if (!currency) {
        throw new Error('Cryptomonnaie non trouvée');
      }

      // Calculer le volume 24h
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);

      const volume24h = await Transaction.sum('amountInEur', {
        where: {
          currencyId,
          createdAt: { [Op.gte]: yesterday },
          status: 'COMPLETED'
        }
      });

      await currency.update({ volume24h: volume24h || 0 });

      return {
        ...currency.toJSON(),
        volume24h: volume24h || 0
      };
    } catch (error) {
      logger.error('Erreur lors du calcul des statistiques:', error);
      throw error;
    }
  }
}

module.exports = VirtualCurrencyService;
