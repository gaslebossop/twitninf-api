const { VirtualCurrency, Transaction, UserWallet } = require('../models');
const { sequelize } = require('../database/index');
const logger = require('../utils/logger');
const cron = require('node-cron');

/**
 * Service pour gérer les variations économiques du système TwitCoins
 * Simule une économie réaliste basée sur l'offre et la demande
 */
class EconomicVariationsService {

  /**
   * Analyser et ajuster l'économie basée sur les données récentes
   */
  static async analyzeAndAdjustEconomy(currencyId) {
    try {
      logger.info(`🔍 Analyse économique en cours pour la cryptomonnaie ${currencyId}...`);

      const currency = await VirtualCurrency.findByPk(currencyId);
      if (!currency || !currency.isActive) {
        throw new Error('Cryptomonnaie non trouvée ou inactive');
      }

      // Obtenir les données des dernières 24h
      const last24h = new Date(Date.now() - 24 * 60 * 60 * 1000);
      const last7days = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

      // Analyser les achats récents
      const recentPurchases = await Transaction.findAll({
        where: {
          currencyId,
          type: 'PURCHASE',
          createdAt: { [require('sequelize').Op.gte]: last24h }
        },
        order: [['createdAt', 'DESC']]
      });

      // Analyser les dépenses récentes
      const recentSpending = await Transaction.findAll({
        where: {
          currencyId,
          type: 'SPEND',
          createdAt: { [require('sequelize').Op.gte]: last24h }
        }
      });

      // Calculer les métriques économiques
      const purchaseVolume24h = recentPurchases.reduce((sum, tx) => sum + parseFloat(tx.amountInEur), 0);
      const spendingVolume24h = recentSpending.reduce((sum, tx) => sum + parseFloat(tx.amount), 0);
      const totalTransactions24h = recentPurchases.length + recentSpending.length;

      // Obtenir les données de la semaine passée pour comparaison
      const weeklyPurchases = await Transaction.findAll({
        where: {
          currencyId,
          type: 'PURCHASE',
          createdAt: { 
            [require('sequelize').Op.gte]: last7days,
            [require('sequelize').Op.lt]: last24h
          }
        }
      });

      const weeklyPurchaseVolume = weeklyPurchases.reduce((sum, tx) => sum + parseFloat(tx.amountInEur), 0) / 7;

      // Calculer les variations
      const economicMetrics = await this.calculateEconomicMetrics({
        currency,
        purchaseVolume24h,
        spendingVolume24h,
        totalTransactions24h,
        avgWeeklyVolume: weeklyPurchaseVolume,
        recentPurchases: recentPurchases.length
      });

      // Appliquer les ajustements
      const adjustments = await this.applyEconomicAdjustments(currency, economicMetrics);

      logger.info(`✅ Analyse économique terminée:`, {
        trend: adjustments.newTrend,
        multiplier: adjustments.newMultiplier,
        bonus: adjustments.newBonus,
        volume24h: purchaseVolume24h
      });

      return adjustments;

    } catch (error) {
      logger.error('❌ Erreur lors de l\'analyse économique:', error);
      throw error;
    }
  }

  /**
   * Calculer les métriques économiques
   */
  static async calculateEconomicMetrics(data) {
    const {
      currency,
      purchaseVolume24h,
      spendingVolume24h,
      totalTransactions24h,
      avgWeeklyVolume,
      recentPurchases
    } = data;

    // Système économique réaliste avec facteurs de marché
    const volumeGrowth = avgWeeklyVolume > 0 ? (purchaseVolume24h / avgWeeklyVolume) - 1 : 0;
    const activityLevel = totalTransactions24h;
    const demandPressure = recentPurchases > 0 ? purchaseVolume24h / recentPurchases : 0;
    
    // 1. IMPACT DE L'OFFRE ET DE LA DEMANDE
    const supplyDemandRatio = purchaseVolume24h / Math.max(currency.circulatingSupply, 1);
    const logVolume = Math.log10(Math.max(purchaseVolume24h, 1));
    const logBase = Math.log10(1000);
    const volumeImpact = (logVolume - logBase) * 0.02; // Impact très réduit
    
    // 2. IMPACT DE LA TAILLE MOYENNE DES ACHATS
    const avgPurchaseSize = demandPressure;
    const sizeImpact = Math.log10(Math.max(avgPurchaseSize, 1)) * 0.015; // Impact réduit
    
    // 3. VOLATILITÉ DU MARCHÉ
    const volatility = this.calculateMarketVolatility(currency, purchaseVolume24h, totalTransactions24h);
    
    // 4. SENTIMENT DU MARCHÉ (basé sur l'activité récente)
    const marketSentiment = this.calculateMarketSentiment(volumeGrowth, activityLevel, recentPurchases);
    
    // 5. EFFET DE LIQUIDITÉ
    const liquidityEffect = this.calculateLiquidityEffect(purchaseVolume24h, currency.circulatingSupply);
    
    // 6. STABILISATION NATURELLE
    const currentMultiplier = parseFloat(currency.currentMultiplier);
    const targetMultiplier = 1.0;
    const stabilizationForce = 0.003; // Force très faible
    const stabilizationImpact = (targetMultiplier - currentMultiplier) * stabilizationForce;

    // Déterminer la tendance économique
    let trend = 'stable';
    let multiplierAdjustment = 0;
    let bonusAdjustment = 0;

    // Calculer l'impact total avec tous les facteurs
    const totalImpact = (
      volumeImpact + 
      sizeImpact + 
      (volumeGrowth * 0.02) + 
      volatility + 
      marketSentiment + 
      liquidityEffect + 
      stabilizationImpact
    ) * 0.6; // Facteur de réalisme global
    
    // Économie en croissance (impact positif)
    if (totalImpact > 0.015) {
      trend = 'rising';
      multiplierAdjustment = totalImpact;
      bonusAdjustment = -totalImpact * 0.25;
    }
    // Économie en déclin (impact négatif)
    else if (totalImpact < -0.015) {
      trend = 'falling';
      multiplierAdjustment = totalImpact;
      bonusAdjustment = -totalImpact * 0.4;
    }
    // Économie stable
    else {
      trend = 'stable';
      multiplierAdjustment = totalImpact * 0.2; // Impact minimal
      bonusAdjustment = 0.002; // Bonus très minimal
    }

    // Facteurs de saisonnalité et événements spéciaux
    const seasonalFactors = this.getSeasonalFactors();
    multiplierAdjustment *= seasonalFactors.multiplierFactor;
    bonusAdjustment *= seasonalFactors.bonusFactor;

    return {
      trend,
      multiplierAdjustment,
      bonusAdjustment,
      volumeGrowth,
      activityLevel,
      demandPressure
    };
  }

  /**
   * Appliquer les ajustements économiques
   */
  static async applyEconomicAdjustments(currency, metrics) {
    const currentMultiplier = parseFloat(currency.currentMultiplier);
    const currentBonus = parseFloat(currency.purchaseBonus);

    // Calculer les nouvelles valeurs sans limites
    const newMultiplier = currentMultiplier + metrics.multiplierAdjustment;
    const newBonus = currentBonus + metrics.bonusAdjustment;

    // Calculer le nouveau prix
    const newPrice = parseFloat(currency.basePrice) * newMultiplier;

    // Mettre à jour l'historique des prix
    const priceHistory = currency.priceHistory || [];
    priceHistory.push({
      date: new Date().toISOString(),
      price: newPrice,
      volume: currency.volume24h || 0,
      multiplier: newMultiplier,
      trend: metrics.trend,
      factors: {
        volumeGrowth: metrics.volumeGrowth,
        activityLevel: metrics.activityLevel,
        demandPressure: metrics.demandPressure
      }
    });

    // Garder seulement les 60 derniers points (2 mois)
    const filteredHistory = priceHistory.slice(-60);

    // Mettre à jour la cryptomonnaie
    await currency.update({
      currentPrice: newPrice,
      currentMultiplier: newMultiplier,
      purchaseBonus: newBonus,
      economicTrend: metrics.trend,
      priceHistory: filteredHistory,
      marketCap: newPrice * parseFloat(currency.circulatingSupply)
    });

    return {
      newPrice,
      newMultiplier,
      newBonus,
      newTrend: metrics.trend,
      adjustment: {
        multiplierChange: metrics.multiplierAdjustment,
        bonusChange: metrics.bonusAdjustment
      }
    };
  }

  /**
   * Obtenir les facteurs saisonniers
   */
  static getSeasonalFactors() {
    const now = new Date();
    const month = now.getMonth() + 1; // 1-12
    const dayOfWeek = now.getDay(); // 0-6
    const hour = now.getHours(); // 0-23

    let multiplierFactor = 1.0;
    let bonusFactor = 1.0;

    // Facteurs mensuels
    switch (month) {
      case 12: // Décembre - période de fêtes
        multiplierFactor *= 1.2;
        bonusFactor *= 1.5;
        break;
      case 1: // Janvier - nouvelle année
        multiplierFactor *= 1.1;
        bonusFactor *= 1.3;
        break;
      case 7:
      case 8: // Été - vacances
        multiplierFactor *= 0.9;
        bonusFactor *= 1.2;
        break;
      default:
        break;
    }

    // Facteurs hebdomadaires
    if (dayOfWeek === 0 || dayOfWeek === 6) { // Weekend
      multiplierFactor *= 1.05;
      bonusFactor *= 1.1;
    }

    // Facteurs horaires
    if (hour >= 18 && hour <= 22) { // Soirée - pic d'activité
      multiplierFactor *= 1.02;
    }

    return { multiplierFactor, bonusFactor };
  }

  /**
   * Déclencher des événements économiques spéciaux
   */
  static async triggerSpecialEvent(currencyId, eventType, duration = 24) {
    try {
      const currency = await VirtualCurrency.findByPk(currencyId);
      if (!currency) {
        throw new Error('Cryptomonnaie non trouvée');
      }

      let eventMultiplier = 1.0;
      let eventBonus = 0.0;
      let eventDescription = '';

      switch (eventType) {
        case 'BLACK_FRIDAY':
          eventMultiplier = 0.8; // Prix réduits
          eventBonus = 0.3; // 30% de bonus
          eventDescription = 'Black Friday - 30% de bonus sur tous les achats!';
          break;
        
        case 'CHRISTMAS_SPECIAL':
          eventMultiplier = 0.9;
          eventBonus = 0.25;
          eventDescription = 'Offre de Noël - 25% de TwitCoins bonus!';
          break;
        
        case 'NEW_USER_PROMO':
          eventMultiplier = 0.7;
          eventBonus = 0.5;
          eventDescription = 'Promotion nouveaux utilisateurs - 50% de bonus!';
          break;
        
        case 'ECONOMIC_BOOM':
          eventMultiplier = 1.5; // Simulation d'une forte demande
          eventBonus = 0.0;
          eventDescription = 'Boom économique - Forte demande!';
          break;
        
        default:
          throw new Error('Type d\'événement non reconnu');
      }

      await currency.update({
        currentMultiplier: eventMultiplier,
        purchaseBonus: eventBonus,
        economicTrend: eventType === 'ECONOMIC_BOOM' ? 'rising' : 'stable',
        currentPrice: parseFloat(currency.basePrice) * eventMultiplier
      });

      logger.info(`🎉 Événement spécial déclenché: ${eventDescription}`);

      // Programmer la fin de l'événement
      setTimeout(async () => {
        await this.analyzeAndAdjustEconomy(currencyId);
        logger.info(`⏰ Événement spécial terminé: ${eventDescription}`);
      }, duration * 60 * 60 * 1000); // Convertir heures en millisecondes

      return {
        eventType,
        description: eventDescription,
        multiplier: eventMultiplier,
        bonus: eventBonus,
        duration
      };

    } catch (error) {
      logger.error('❌ Erreur lors du déclenchement de l\'événement:', error);
      throw error;
    }
  }

  /**
   * Initialiser les tâches automatiques
   */
  static initializeAutomaticTasks() {
    logger.info('🤖 Initialisation des tâches économiques automatiques...');

    // Analyse économique toutes les heures
    cron.schedule('0 * * * *', async () => {
      try {
        // Obtenir toutes les cryptomonnaies actives
        const currencies = await VirtualCurrency.findAll({
          where: { isActive: true }
        });

        for (const currency of currencies) {
          await this.analyzeAndAdjustEconomy(currency.id);
        }
      } catch (error) {
        logger.error('❌ Erreur lors de l\'analyse automatique:', error);
      }
    });

    // Événements spéciaux aléatoires (tous les dimanches)
    cron.schedule('0 10 * * 0', async () => {
      try {
        const currencies = await VirtualCurrency.findAll({
          where: { isActive: true }
        });

        // 30% de chance d'événement spécial
        if (Math.random() < 0.3) {
          const events = ['BLACK_FRIDAY', 'CHRISTMAS_SPECIAL', 'NEW_USER_PROMO'];
          const randomEvent = events[Math.floor(Math.random() * events.length)];
          
          for (const currency of currencies) {
            await this.triggerSpecialEvent(currency.id, randomEvent, 48); // 48h
          }
        }
      } catch (error) {
        logger.error('❌ Erreur lors du déclenchement d\'événement automatique:', error);
      }
    });

    logger.info('✅ Tâches économiques automatiques initialisées');
  }

  /**
   * Obtenir les prédictions économiques
   */
  static async getEconomicPredictions(currencyId) {
    try {
      const currency = await VirtualCurrency.findByPk(currencyId);
      if (!currency) {
        throw new Error('Cryptomonnaie non trouvée');
      }

      const priceHistory = currency.priceHistory || [];
      if (priceHistory.length < 10) {
        return {
          prediction: 'stable',
          confidence: 0.5,
          reason: 'Données insuffisantes pour une prédiction fiable'
        };
      }

      // Analyser les tendances récentes
      const recent = priceHistory.slice(-10);
      const priceChanges = recent.map((entry, index) => {
        if (index === 0) return 0;
        return (entry.price - recent[index - 1].price) / recent[index - 1].price;
      }).slice(1);

      const avgChange = priceChanges.reduce((sum, change) => sum + change, 0) / priceChanges.length;
      const volatility = Math.sqrt(priceChanges.reduce((sum, change) => sum + Math.pow(change - avgChange, 2), 0) / priceChanges.length);

      let prediction = 'stable';
      let confidence = 0.5;
      let reason = '';

      if (avgChange > 0.05) {
        prediction = 'rising';
        confidence = Math.min(0.9, 0.5 + volatility);
        reason = 'Tendance haussière observée dans les données récentes';
      } else if (avgChange < -0.05) {
        prediction = 'falling';
        confidence = Math.min(0.9, 0.5 + volatility);
        reason = 'Tendance baissière observée dans les données récentes';
      } else {
        prediction = 'stable';
        confidence = Math.max(0.3, 0.8 - volatility);
        reason = 'Prix relativement stable avec faible volatilité';
      }

      return {
        prediction,
        confidence: Math.round(confidence * 100),
        reason,
        technicalData: {
          avgChange: Math.round(avgChange * 10000) / 100, // en pourcentage
          volatility: Math.round(volatility * 10000) / 100,
          dataPoints: recent.length
        }
      };

    } catch (error) {
      logger.error('❌ Erreur lors de la prédiction économique:', error);
      throw error;
    }
  }

  /**
   * Calculer la volatilité du marché
   */
  static calculateMarketVolatility(currency, purchaseVolume24h, totalTransactions24h) {
    const currentMultiplier = parseFloat(currency.currentMultiplier);
    
    // Volatilité basée sur l'activité
    const activityVolatility = Math.min(0.05, totalTransactions24h / 1000);
    
    // Volatilité basée sur le volume
    const volumeVolatility = Math.min(0.03, purchaseVolume24h / 10000);
    
    // Volatilité basée sur l'écart par rapport à la normale
    const deviationVolatility = Math.abs(currentMultiplier - 1.0) * 0.01;
    
    // Volatilité aléatoire (10% de chance)
    const randomVolatility = Math.random() < 0.1 ? (Math.random() - 0.5) * 0.02 : 0;
    
    return activityVolatility + volumeVolatility + deviationVolatility + randomVolatility;
  }

  /**
   * Calculer le sentiment du marché
   */
  static calculateMarketSentiment(volumeGrowth, activityLevel, recentPurchases) {
    // Sentiment basé sur la croissance du volume
    let sentiment = 0;
    
    if (volumeGrowth > 0.5) {
      sentiment += 0.02; // Très positif
    } else if (volumeGrowth > 0.1) {
      sentiment += 0.01; // Positif
    } else if (volumeGrowth < -0.3) {
      sentiment -= 0.02; // Très négatif
    } else if (volumeGrowth < -0.1) {
      sentiment -= 0.01; // Négatif
    }
    
    // Sentiment basé sur l'activité
    if (activityLevel > 100) {
      sentiment += 0.01; // Activité élevée
    } else if (activityLevel < 10) {
      sentiment -= 0.01; // Activité faible
    }
    
    // Sentiment basé sur la fréquence des achats
    if (recentPurchases > 20) {
      sentiment += 0.005; // Beaucoup d'achats
    } else if (recentPurchases < 5) {
      sentiment -= 0.005; // Peu d'achats
    }
    
    return sentiment;
  }

  /**
   * Calculer l'effet de liquidité
   */
  static calculateLiquidityEffect(purchaseVolume24h, circulatingSupply) {
    // Ratio de liquidité (volume / supply)
    const liquidityRatio = purchaseVolume24h / Math.max(circulatingSupply, 1);
    
    // Effet de liquidité
    if (liquidityRatio > 0.1) {
      return 0.01; // Liquidité élevée = stabilité
    } else if (liquidityRatio > 0.05) {
      return 0.005; // Liquidité modérée
    } else if (liquidityRatio < 0.01) {
      return -0.01; // Liquidité faible = volatilité
    }
    
    return 0;
  }
}

module.exports = EconomicVariationsService;
