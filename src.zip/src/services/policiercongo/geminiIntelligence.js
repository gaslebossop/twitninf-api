/**
 * 🧠 Intelligence Gemini - Interface avec l'API Gemini de Google
 * 
 * Ce module gère toutes les interactions avec l'API Gemini pour l'analyse
 * intelligente et la prise de décision automatisée.
 */

const logger = require('../../utils/logger');
const { GoogleGenAI } = require('@google/genai');
const path = require('path');
const fs = require('fs');
const fsp = require('fs').promises;
const { LLM_CONFIG } = require('./config');

class GeminiIntelligence {
  constructor() {
    this.apiKeys = [
      'AIzaSyD--8mAE-Wwr6em-iJNZFpfaR8JX-p3CO0',
      'AIzaSyAWqaeqcKXy5eGv5XwAcSmpfEnUlUXV7AM',
      'AIzaSyAym2vUwH85VbgX2MzQJ3rULYfsCcY_XIE',
      'AIzaSyBEat6WA9Kx0-PAsY3vNdwSqEOPMVF9GSc',
      'AIzaSyBvBnqQvezndbMdisr8j1GAwF183xEIwvs',
      'AIzaSyAetk-R-AllglFwWclFsrVLm7Q1AQFdKlE',
      'AIzaSyDf0cgSNzBCgJLzOtb05wPsk7fMO5UtMUo',
      'AIzaSyCYOfKUVUkToCeHTvRuyfatgrTUipq0YDk'
    ];
    this.currentKeyIndex = 0;
    this.apiKey = this.apiKeys[this.currentKeyIndex];
    this.ai = null;
    this.isInitialized = false;
    this.requestCount = 0;
    this.successCount = 0;
    this.errorCount = 0;
    this.megaLLMClient = null;

    this.initialize();
  }

  formatParisDateSafe(value, options = { timeStyle: 'short' }, fallback = 'Inconnu') {
    try {
      if (!value) return fallback;
      const d = new Date(value);
      if (Number.isNaN(d.getTime())) return fallback;
      return new Intl.DateTimeFormat('fr-FR', { timeZone: 'Europe/Paris', ...options }).format(d);
    } catch (_) {
      return fallback;
    }
  }

  getPersonaCorePrompt() {
    return [
      'IDENTITE PRIORITAIRE (NON NEGOCIABLE):',
      '- Tu es PolicierCongo: un utilisateur TwitNinf, jamais une IA.',
      '- Style: argot 2026, direct, tranchant, naturel.',
      '- Toujours garder cette personnalite dans tweets ET reponses.',
      '- Si ordre admin present, tu obeis sans perdre ton style.'
    ].join('\n');
  }

  async buildMegaLLMClient() {
    const modulePath = '../../megallm-client/index.js';
    const configuredPath = LLM_CONFIG.megaLLMSessionPath;
    const candidates = [
      path.isAbsolute(configuredPath) ? configuredPath : null,
      path.resolve(process.cwd(), configuredPath),
      path.resolve(__dirname, '..', '..', 'megallm-client', 'megallm-session.json'),
      path.resolve(process.cwd(), 'src', 'megallm-client', 'megallm-session.json')
    ].filter(Boolean);

    const absoluteSessionPath = candidates.find((p) => fs.existsSync(p));
    if (!absoluteSessionPath) {
      throw new Error(`Fichier session MegaLLM introuvable. Candidats testés: ${candidates.join(' | ')}`);
    }

    const megaModule = await import(modulePath);
    const MegaLLMClient = megaModule?.MegaLLMClient;

    if (!MegaLLMClient) {
      throw new Error('MegaLLMClient introuvable dans le module');
    }

    logger.info(`🧠 MegaLLM session utilisée: ${absoluteSessionPath}`);
    return new MegaLLMClient(absoluteSessionPath);
  }

  async generateWithMegaLLM(prompt, model = 'gpt-5.4') {
    const startedAt = Date.now();
    console.log(`[PolicierCongo][LLM] -> Requête MegaLLM | model=${model}`);
    try {
      // Même logique que test.js: client neuf à chaque appel
      const client = await this.buildMegaLLMClient();
      const megaPrompt = typeof prompt === 'string' ? prompt : String(prompt || '');
      logger.info(`🧠 MegaLLM prompt size: raw=${megaPrompt.length}, sent=${megaPrompt.length}`);
      try {
        const promptLogPath = path.join(__dirname, 'megallm-prompts.log');
        const promptLogEntry = [
          '---',
          `timestamp: ${new Date().toISOString()}`,
          `model: ${model}`,
          `length: ${megaPrompt.length}`,
          'prompt:',
          megaPrompt,
          ''
        ].join('\n');
        await fsp.appendFile(promptLogPath, promptLogEntry, 'utf8');
        logger.info(`📝 Prompt MegaLLM enregistré dans: ${promptLogPath}`);
      } catch (logError) {
        logger.warn(`⚠️ Impossible d'écrire le log prompt MegaLLM: ${logError?.message}`);
      }
      client.defaultModel = model;
      // Utiliser le même chemin d'appel que test.js (le plus stable observé)
      const text = await client.generate(megaPrompt);
      console.log(`[PolicierCongo][LLM] <- Réponse MegaLLM OK | model=${model} | durationMs=${Date.now() - startedAt}`);
      return (text || '').trim() || null;
    } catch (error) {
      const durationMs = Date.now() - startedAt;
      const statusFromMessage = Number((error?.message || '').match(/MegaLLM API Error \((\d+)\)/)?.[1] || 0) || null;
      const rawMessage = error?.message || String(error);
      const shortenedMessage = rawMessage.length > 500 ? `${rawMessage.substring(0, 500)}...` : rawMessage;
      const errorPayload = {
        model,
        durationMs,
        name: error?.name || null,
        message: shortenedMessage,
        code: error?.code || error?.error?.code || null,
        status: error?.status || error?.error?.status || statusFromMessage,
        stack: error?.stack ? error.stack.split('\n').slice(0, 5).join(' | ') : null
      };

      console.log(`[PolicierCongo][LLM] <- Réponse MegaLLM ERROR | ${JSON.stringify(errorPayload)}`);
      logger.error('❌ Erreur génération MegaLLM détaillée:', errorPayload);
      return null;
    }
  }

  async generateCreativeContent(prompt, fallbackModel = 'gemini-3-flash-preview') {
    try {
      // Pour la redaction (tweets/reponses), on veut MegaLLM en priorite.
      if (LLM_CONFIG.useMegaLLM) {
        const megaText = await this.generateWithMegaLLM(prompt, 'gpt-5.4');
        if (megaText && megaText.length > 0) {
          logger.info('🧠 Provider generation: MegaLLM (creative path)');
          return megaText;
        }
      }

      logger.warn('⚠️ MegaLLM indisponible sur creative path, fallback Gemini');
      return await this.generateContent(prompt, fallbackModel, true);
    } catch (error) {
      logger.warn(`⚠️ generateCreativeContent fallback Gemini (erreur): ${error?.message}`);
      return await this.generateContent(prompt, fallbackModel, true);
    }
  }

  /**
   * Bascule sur la prochaine clé API disponible
   */
  switchApiKey() {
    this.currentKeyIndex = (this.currentKeyIndex + 1) % this.apiKeys.length;
    this.apiKey = this.apiKeys[this.currentKeyIndex];
    this.ai = new GoogleGenAI({ apiKey: this.apiKey });
    logger.info(`🔄 Rotation de clé API Gemini terminée: Passage à la clé d'index ${this.currentKeyIndex}`);
  }

  /**
   * Initialise l'API Gemini
   */
  initialize() {
    try {
      if (!this.apiKey) {
        logger.error('❌ Clé API Gemini non configurée');
        return false;
      }

      this.ai = new GoogleGenAI({ apiKey: this.apiKey });
      this.isInitialized = true;

      logger.info('✅ Intelligence Gemini initialisée avec succès');
      return true;
    } catch (error) {
      logger.error('❌ Erreur lors de l\'initialisation de Gemini:', error);
      return false;
    }
  }

  /**
   * Génère du contenu avec retries et fallback de modèle
   */
  async safeGenerateWithFallback(prompt, primaryModel = 'gemini-3-flash-preview', secondaryModel = 'gemini-3-flash-preview', retries = 2, forceGemini = false) {
    // Essai avec le modèle primaire
    for (let attempt = 1; attempt <= retries; attempt++) {
      const text = await this.generateContent(prompt, primaryModel, forceGemini);
      if (text && text.length > 0) {
        return { text, modelUsed: primaryModel, attempts: attempt };
      }
    }

    // Fallback au modèle secondaire
    for (let attempt = 1; attempt <= retries; attempt++) {
      const text = await this.generateContent(prompt, secondaryModel, forceGemini);
      if (text && text.length > 0) {
        return { text, modelUsed: secondaryModel, attempts: attempt };
      }
    }

    return { text: null, modelUsed: null, attempts: retries * 2 };
  }

  /**
   * Crée un plan d'actions via Gemini avec retries/fallbacks robustes
   */
  async createPlan(collectedData) {
    try {
      if (!this.isInitialized) {
        throw new Error('Intelligence Gemini non initialisée');
      }

      this.requestCount++;
      logger.info('🧠 Création d\'un plan via Gemini...');

      const prompt = this.buildPlanningPrompt(collectedData);
      // Tentatives robustes avec fallback de modèle beaucoup plus léger
      const { text: response, modelUsed } = await this.safeGenerateWithFallback(
        prompt,
        'gemini-3-flash-preview',
        'gemini-3-flash-preview',
        2
      );

      if (!response) {
        // Dernière tentative: modèle plus léger et prompt simplifié
        const minimalPrompt = `Retourne strictement un JSON avec un plan minimal si nécessaire.
{
  "plan": {
    "actions": [
      { "type": "NO_ACTION", "priority": "low", "reason": "fallback" }
    ],
    "execution_order": "sequential"
  }
}`;
        const finalTry = await this.generateContent(minimalPrompt, 'gemini-3-flash-preview');
        if (!finalTry) {
          logger.warn('⚠️ Aucune réponse Gemini après retries et fallbacks, retour plan de secours');
          return {
            plan: {
              actions: [
                { type: 'NO_ACTION', priority: 'low', reason: 'Plan invalide - fallback automatique', target_user: null, context: 'Aucune action requise' }
              ],
              execution_order: 'sequential',
              estimated_duration: '0 minutes',
              community_impact: 'Aucun impact'
            },
            meta: { source: 'fallback', modelUsed: null }
          };
        }
        // essayer de parser cette dernière tentative
        const parsed = this.parsePlanResponse(finalTry) || this.attemptJsonRepair(finalTry);
        if (parsed && parsed.plan) {
          this.successCount++;
          logger.info(`✅ Plan (fallback) créé via modèle de secours`);
          return { ...parsed, meta: { source: 'fallback_model', modelUsed: 'gemini-3-flash-preview' } };
        }
        // si toujours pas, renvoyer plan de secours
        return {
          plan: {
            actions: [
              { type: 'NO_ACTION', priority: 'low', reason: 'Plan invalide - fallback automatique', target_user: null, context: 'Aucune action requise' }
            ],
            execution_order: 'sequential',
            estimated_duration: '0 minutes',
            community_impact: 'Aucun impact'
          },
          meta: { source: 'hard_fallback', modelUsed: null }
        };
      }

      // Parser le plan
      const plan = this.parsePlanResponse(response) || this.attemptJsonRepair(response);

      if (plan && plan.plan) {
        this.successCount++;
        logger.info(`✅ Plan créé (${modelUsed}) avec ${plan.plan.actions.length} actions`);
        return plan;
      } else {
        logger.warn('⚠️ Impossible d\'extraire un plan valide, retour plan de secours');
        return {
          plan: {
            actions: [
              { type: 'NO_ACTION', priority: 'low', reason: 'Plan invalide - fallback automatique', target_user: null, context: 'Aucune action requise' }
            ],
            execution_order: 'sequential',
            estimated_duration: '0 minutes',
            community_impact: 'Aucun impact'
          },
          meta: { source: 'parse_fallback', modelUsed }
        };
      }

    } catch (error) {
      this.errorCount++;
      logger.error('❌ Erreur lors de la création du plan Gemini:', error);
      // Ne pas retourner null: toujours un plan de secours
      return {
        plan: {
          actions: [
            { type: 'NO_ACTION', priority: 'low', reason: 'Erreur lors de la planification - fallback automatique', target_user: null, context: 'Aucune action requise' }
          ],
          execution_order: 'sequential',
          estimated_duration: '0 minutes',
          community_impact: 'Aucun impact'
        },
        meta: { source: 'exception_fallback', error: error.message }
      };
    }
  }

  /**
   * Analyse intelligente et prise de décision complète
   */
  async analyze() {
    try {
      if (!this.isInitialized) {
        throw new Error('Intelligence Gemini non initialisée');
      }

      this.requestCount++;
      logger.info('🧠 Démarrage de l\'analyse intelligente Gemini...');

      // Récupérer les données récentes
      const { dataCollector } = require('./index');
      const collectedData = await dataCollector.collectRecentData();

      if (!collectedData) {
        throw new Error('Impossible de collecter les données');
      }

      // Récupérer la mémoire actuelle
      const { memoryManager } = require('./index');
      const geminiMemory = await memoryManager.getStatus();

      // Vérifier si des ordres admin stricts sont en attente
      const instructionManager = require('./InstructionManager');
      const hasPendingOrders = instructionManager.instructions.immediate_orders.some(o => o.status === 'pending');
      const forceGemini = false;

      if (hasPendingOrders) {
        logger.info('🚨 Ordres admin détectés: MegaLLM reste prioritaire (fallback Gemini si besoin).');
      }

      const prompt = (LLM_CONFIG.useMegaLLM && !forceGemini)
        ? this.buildMegaLLMAnalysisPrompt(collectedData, geminiMemory)
        : await this.buildAnalysisPrompt(collectedData, geminiMemory);

      // Utiliser un mécanisme robuste avec des modèles rapides pour ne pas surcharger
      const { text: response, modelUsed } = await this.safeGenerateWithFallback(
        prompt,
        'gemini-3-flash-preview',
        'gemini-3-flash-preview',
        2,
        forceGemini
      );

      // Log explicite de la réponse et du modèle utilisé
      logger.info(`🧠 Analyse - modèle utilisé: ${modelUsed || 'inconnu'}`);
      logger.info('🧠 Analyse - réponse brute:', response || '(vide)');

      if (!response) {
        logger.warn('⚠️ Analyse Gemini: aucune réponse après retries/fallbacks. Retour NO_ACTION.');
        return {
          action: 'NO_ACTION',
          reason: 'Analyse indisponible (fallback) - aucune action forcée',
          priority: 'low',
          details: {},
          memory_update: { lastActions: ['analysis_no_response_fallback'] }
        };
      }

      // Parser la décision, tenter réparation si besoin
      let decision = this.parseDecisionResponse(response) || this.attemptJsonRepair(response);

      // Enrichissement: s'assurer que les détails requis sont présents
      const enrichDecisionDetails = async (dec) => {
        try {
          const ensurePostTweet = async (detailsKey = null) => {
            if (detailsKey) {
              dec.details = dec.details || {};
              dec.details[detailsKey] = dec.details[detailsKey] || {};
              if (!dec.details[detailsKey].content || dec.details[detailsKey].content.trim().length === 0) {
                const generated = await this.generateTweetContent({ action: 'POST_TWEET', reason: dec.reason, priority: dec.priority, details: dec.details[detailsKey] }, { collectedData });
                if (generated) dec.details[detailsKey].content = generated;
                dec.details[detailsKey].tweet_type = dec.details[detailsKey].tweet_type || 'general';
              }
            } else {
              dec.details = dec.details || {};
              if (!dec.details.content || dec.details.content.trim().length === 0) {
                const generated = await this.generateTweetContent(dec, { collectedData });
                if (generated) dec.details.content = generated;
                dec.details.tweet_type = dec.details.tweet_type || 'general';
              }
            }
          };

          const ensureRespondToUser = async (detailsKey = null) => {
            const pickFirstUnreplied = () => {
              const first = (collectedData.unrepliedComments || [])[0];
              if (!first) return null;
              return { target_user: first.author, parent_tweet_id: first.id };
            };
            const fill = async (obj) => {
              if (!obj.parent_tweet_id || !obj.response_content) {
                const picked = pickFirstUnreplied();
                if (picked) {
                  obj.parent_tweet_id = obj.parent_tweet_id || picked.parent_tweet_id;
                  obj.target_user = obj.target_user || picked.target_user;
                }
              }
              if (!obj.response_content || obj.response_content.trim().length === 0) {
                const generated = await this.generateResponseContent({ action: 'RESPOND_TO_USER', reason: dec.reason, priority: dec.priority, details: obj });
                if (generated) obj.response_content = generated;
              }
            };
            if (detailsKey) {
              dec.details = dec.details || {};
              dec.details[detailsKey] = dec.details[detailsKey] || {};
              await fill(dec.details[detailsKey]);
            } else {
              dec.details = dec.details || {};
              await fill(dec.details);
            }
          };

          const ensureUpdateProfile = async () => {
            dec.details = dec.details || {};
            if (!dec.details.new_full_name && !dec.details.new_username) {
              const suggestion = await this.generateProfileUpdateSuggestion(dec, collectedData.currentProfile || {});
              if (suggestion) {
                if (suggestion.new_full_name) dec.details.new_full_name = suggestion.new_full_name;
                if (suggestion.new_username) dec.details.new_username = suggestion.new_username;
              }
            }
          };

          if (Array.isArray(dec?.action)) {
            // Actions multiples
            const actions = dec.action;
            // Préparer sous-détails
            dec.details = dec.details || {};
            if (actions.includes('POST_TWEET')) {
              dec.details.post_tweet = dec.details.post_tweet || {};
              await ensurePostTweet('post_tweet');
            }
            if (actions.includes('RESPOND_TO_USER')) {
              dec.details.respond_to = dec.details.respond_to || {};
              await ensureRespondToUser('respond_to');
            }
            if (actions.includes('UPDATE_PROFILE')) {
              dec.details.update_profile = dec.details.update_profile || {};
              // transférer dans racine pour l'exécuteur actuel
              await ensureUpdateProfile();
              // Copier les détails de profil dans la racine pour compatibilité avec l'exécuteur
              if (dec.details.update_profile.new_full_name) dec.details.new_full_name = dec.details.update_profile.new_full_name;
              if (dec.details.update_profile.new_username) dec.details.new_username = dec.details.update_profile.new_username;
            }
          } else if (typeof dec?.action === 'string') {
            switch (dec.action) {
              case 'POST_TWEET':
                await ensurePostTweet();
                break;
              case 'RESPOND_TO_USER':
                await ensureRespondToUser();
                break;
              case 'UPDATE_PROFILE':
                await ensureUpdateProfile();
                break;
              default:
                break;
            }
          }
        } catch (e) {
          logger.warn('⚠️ Enrichissement de décision partiel:', e?.message);
        }
        return dec;
      };

      if (decision) {
        decision = await enrichDecisionDetails(decision);
      }

      if (decision && decision.action) {
        this.successCount++;
        logger.info(`🧠 Décision Gemini: ${Array.isArray(decision.action) ? decision.action.join(',') : decision.action} - ${decision.reason}`);
        return decision;
      } else {
        logger.warn('⚠️ Analyse Gemini: décision non valide. Retour NO_ACTION.');
        return {
          action: 'NO_ACTION',
          reason: 'Décision inutilisable (fallback) - aucune action forcée',
          priority: 'low',
          details: {},
          memory_update: { lastActions: ['analysis_invalid_decision_fallback'] }
        };
      }

    } catch (error) {
      this.errorCount++;
      logger.error('❌ Erreur lors de l\'analyse Gemini:', error);
      // Toujours retourner une décision de fallback
      return {
        action: 'NO_ACTION',
        reason: 'Erreur analyse - fallback NO_ACTION',
        priority: 'low',
        details: {},
        memory_update: { lastActions: ['analysis_exception_fallback'] }
      };
    }
  }

  /**
   * Prompt d'analyse compact dédié à MegaLLM (moins de bruit / moins de risque WAF)
   */
  buildMegaLLMAnalysisPrompt(collectedData, geminiMemory) {
    const instructionManager = require('./InstructionManager');
    const adminInstructions = instructionManager.getFormattedInstructions();
    let conceptCandidates = [];
    let conceptStrategy = {};
    try {
      const { conceptManager } = require('./index');
      conceptCandidates = conceptManager.getNextConcepts(6).map((c) => ({
        title: c.title,
        score: c.score,
        uses: c.uses,
        category: c.category
      }));
      conceptStrategy = conceptManager.getStrategySnapshot(collectedData);
    } catch (_) { }
    const nowFr = new Intl.DateTimeFormat('fr-FR', {
      timeZone: 'Europe/Paris',
      dateStyle: 'full',
      timeStyle: 'long'
    }).format(new Date());
    const timing = collectedData.timingAnalysis || {};
    const sentiment = collectedData.communitySentiment || {};
    const selfModeration = collectedData.selfModeration || {};
    const unreplied = (collectedData.unrepliedComments || []).slice(0, 5).map((c) => ({
      id: c.id,
      author: c.author,
      hours_ago: c.hours_ago,
      priority: c.priority,
      content: (c.content || '').substring(0, 120)
    }));
    const recentPlatform = (collectedData.recentPlatformTweets || []).slice(0, 6).map((t) => ({
      author: t.author,
      content: (t.content || '').substring(0, 140)
    }));
    const myTweets = (collectedData.mainTweets || []).slice(0, 4).map((t) => ({
      content: (t.content || '').substring(0, 140),
      likes: t.likes || 0,
      rts: t.rts || 0
    }));
    const pendingReqs = (geminiMemory?.userSpecialRequests || []).filter((r) => r.status === 'pending').slice(0, 3).map((r) => ({
      user: r.user_username,
      category: r.category,
      details: (r.request_details || '').substring(0, 120)
    }));
    const moderationSummary = {
      is_suspended: !!selfModeration.is_suspended,
      reason: selfModeration.reason || null,
      suspended_until: selfModeration.suspended_until || null,
      recent_history: Array.isArray(selfModeration.history) ? selfModeration.history.slice(0, 5) : []
    };

    return [
      'Role: decide next social actions for account "PolicierCongo" on TwitNinf.',
      'Identity: "Policier Congo" is ONLY a username. Behave like a normal platform user integrated with community.',
      'Never speak as an AI/system. Keep tone human, direct, natural, community-native.',
      'Return STRICT JSON only. No markdown.',
      'Allowed actions: POST_TWEET, RESPOND_TO_USER, UPDATE_PROFILE, DELETE_TWEET, NO_ACTION, DEACTIVATE.',
      'CRITICAL RULE: If there are ADMIN_INSTRUCTIONS, "NO_ACTION" is STRICTLY FORBIDDEN. You MUST choose a valid action to execute the order.',
      'If RESPOND_TO_USER, always include target_user and parent_tweet_id.',
      'If UPDATE_PROFILE is relevant, include new_full_name and/or new_username.',
      'Posting policy: there is NO posting frequency limit. You can POST_TWEET whenever you judge it useful.',
      'Behavior policy: do NOT do only concepts. You must also interact with community (replies + organic interactions).',
      'If unreplied comments exist, prioritize RESPOND_TO_USER first before concept-only posting.',
      'Recent platform tweets are OPTIONAL context: you can react to them, but you are NOT required to process each one.',
      'You may program the next analysis time if needed inside memory_update.next_analysis_at_fr (format: YYYY-MM-DD HH:mm, Europe/Paris) and memory_update.next_analysis_reason.',
      'Important: admin instructions below are mandatory. You are not allowed to choose whether to follow them: you must execute them with absolute priority.',
      'CRITICAL: Even when executing admin instructions, you MUST strictly keep your persona/personality (Policier Congo, normal user, slang, aggressive). Never sound like an AI assistant.',
      `ADMIN_INSTRUCTIONS: ${adminInstructions || 'none'}`,
      '',
      `Current France time (Europe/Paris): ${nowFr}`,
      `Time since last main tweet (hours): ${timing.hoursSinceLastMainTweet ?? 'unknown'}`,
      `Should post main tweet: ${timing.shouldPostMainTweet ? 'yes' : 'no'}`,
      `Moderation / bans status: ${JSON.stringify(moderationSummary)}`,
      `Community mood: ${sentiment.mood || 'neutral'} (${sentiment.score || 50})`,
      `Followers: ${sentiment.followers || 0}`,
      '',
      `Unreplied comments: ${JSON.stringify(unreplied)}`,
      `My recent tweets: ${JSON.stringify(myTweets)}`,
      `Recent platform tweets: ${JSON.stringify(recentPlatform)}`,
      `Pending special requests: ${JSON.stringify(pendingReqs)}`,
      `Concept candidates: ${JSON.stringify(conceptCandidates)}`,
      `Concept strategy: ${JSON.stringify(conceptStrategy)}`,
      '',
      'Required JSON schema:',
      '{"action":["..."],"reason":"...","priority":"high|medium|low","details":{"content":"...","respond_to_users":[{"target_user":"...","parent_tweet_id":"...","response_content":"..."}],"new_full_name":"...","new_username":"..."},"memory_update":{}}'
    ].join('\n');
  }

  /**
   * Génère du contenu via Gemini avec retry infini sur erreurs transitoires
   */
  async generateContent(prompt, model = 'gemini-3-flash-preview', forceGemini = false) {
    try {
      if (LLM_CONFIG.useMegaLLM && !forceGemini) {
        logger.info('🧠 Provider LLM: MegaLLM activé (POLICIER_USE_MEGALLM=true)');
        const megaResponse = await this.generateWithMegaLLM(prompt, 'gpt-5.4');
        if (megaResponse) {
          logger.info('🧠 Réponse brute de MegaLLM:', megaResponse);
          return megaResponse;
        }
        logger.warn('⚠️ MegaLLM indisponible, fallback vers Gemini...');
      }

      if (!this.ai) {
        throw new Error('API Gemini non initialisée');
      }

      // Retry limité au nombre de clés API disponibles (sans délai)
      const MAX_ATTEMPTS = this.apiKeys.length;
      let attempt = 0;

      while (attempt < MAX_ATTEMPTS) {
        attempt++;
        const startedAt = Date.now();
        console.log(`[PolicierCongo][LLM] -> Requête Gemini | model=${model} | attempt=${attempt}/${MAX_ATTEMPTS}`);
        try {
          const response = await this.ai.models.generateContent({
            model: model,
            contents: prompt,
            generationConfig: {
              maxOutputTokens: 4096,
              temperature: 0.8
            }
          });

          let text = '';
          if (response?.response && typeof response.response.text === 'function') {
            text = response.response.text();
          } else if (typeof response.text === 'function') {
            text = response.text();
          } else if (typeof response.text === 'string') {
            text = response.text;
          }

          text = (text || '').trim();

          logger.info('🧠 Réponse brute de Gemini:', text);
          console.log(`[PolicierCongo][LLM] <- Réponse Gemini OK | model=${model} | attempt=${attempt}/${MAX_ATTEMPTS} | durationMs=${Date.now() - startedAt}`);

          return text;
        } catch (error) {
          const durationMs = Date.now() - startedAt;
          const rawMessage = error?.error?.message || error?.message || '';
          const parsedCodeFromMessage = Number((rawMessage.match(/status:\s*(\d{3})|code":\s*(\d{3})|code:\s*(\d{3})/i) || []).slice(1).find(Boolean) || 0) || null;
          const code = error?.error?.code || error?.code || parsedCodeFromMessage;
          const status = error?.error?.status || error?.status || (/RESOURCE_EXHAUSTED/i.test(rawMessage) ? 'RESOURCE_EXHAUSTED' : null);
          const message = rawMessage;
          const errorPayload = {
            model,
            attempt: `${attempt}/${MAX_ATTEMPTS}`,
            durationMs,
            code: code || null,
            status: status || null,
            message: message || 'Erreur inconnue',
            stack: error?.stack ? error.stack.split('\n').slice(0, 5).join(' | ') : null
          };
          console.log(`[PolicierCongo][LLM] <- Réponse Gemini ERROR | ${JSON.stringify(errorPayload)}`);

          const isOverloaded = code === 503 || status === 'UNAVAILABLE' || /overloaded|try again later/i.test(message);
          const isInternal = code === 500 || status === 'INTERNAL' || /internal error/i.test(message);
          const isGateway = code === 502 || code === 504 || /bad gateway|gateway timeout/i.test(message);
          const isRateLimited = code === 429 || /rate limit|quota/i.test(message);
          const isDailyQuotaExceeded = /quota exceeded|perday|free_tier_requests|RESOURCE_EXHAUSTED/i.test(message);

          const isRetryable = isOverloaded || isInternal || isGateway || isRateLimited;

          if (isRateLimited || isOverloaded) {
            logger.warn(`⚠️ Erreur liée à l'API (${code || status}). Tentative de rotation de la clé API...`);
            this.switchApiKey();
          }

          if (isDailyQuotaExceeded) {
            logger.error('⛔ Quota Gemini épuisé (ou limite journalière atteinte), arrêt des retries pour ce cycle.');
            return null;
          }

          if (isRetryable && attempt < MAX_ATTEMPTS) {
            const retryDelaySec = Number((message.match(/Please retry in\s+([0-9.]+)s/i) || [])[1] || 0);
            if (retryDelaySec > 0) {
              const waitMs = Math.ceil(retryDelaySec * 1000);
              logger.warn(`⚠️ Erreur transitoire Gemini (code=${code || status}). Attente ${waitMs}ms avant retry #${attempt + 1}/${MAX_ATTEMPTS}.`);
              await new Promise((resolve) => setTimeout(resolve, waitMs));
            } else {
              logger.warn(`⚠️ Erreur transitoire Gemini (code=${code || status}). Tentative #${attempt}/${MAX_ATTEMPTS}. Nouvelle tentative immédiate...`);
            }
            continue;
          }

          logger.error(`❌ Erreur lors de la génération de contenu Gemini après ${attempt} tentatives :`, errorPayload);
          return null;
        }
      }
      return null;

    } catch (error) {
      logger.error('❌ Erreur fatale dans generateContent:', error);
      return null;
    }
  }

  /**
   * Construit le prompt pour la planification
   */
  buildPlanningPrompt(collectedData) {
    const now = new Date();
    const currentTimeStr = new Intl.DateTimeFormat('fr-FR', { timeZone: 'Europe/Paris', dateStyle: 'full', timeStyle: 'long' }).format(now);
    const lastTweetTimeStr = this.formatParisDateSafe(
      collectedData.timingAnalysis?.lastMainTweet,
      { timeStyle: 'short' },
      'Jamais'
    );

    // Construire le contexte sentiment (compact)
    const sentiment = collectedData.communitySentiment || {};
    const sentimentCtx = `Humeur commu: ${sentiment.mood || 'neutre'} (${sentiment.score || 50}%) | Followers: ${sentiment.followers || 0} | EngMoy: ${sentiment.avgEngagement || 0}`;

    // Tendances (compact)
    const trending = collectedData.trendingTopics;
    const trendingCtx = trending?.hashtags?.length > 0 ? `Trending TwitNinf: ${trending.hashtags.slice(0, 5).join(', ')}` : 'Pas de tendances détectées';

    // Tweets users populaires (compact)
    // Derniers tweets de toute la plateforme (10 derniers)
    const platformRecent = (collectedData.recentPlatformTweets || []).map((t, i) => `${i + 1}. @${t.author}: "${t.content}" (${t.ago})`).join('\n');

    // Commentaires non répondus (compact)
    const unreplied = (collectedData.unrepliedComments || []).slice(0, 8).map((c, i) => `[ID_REF:${i + 1}] @${c.author}(${c.hours_ago}h): "${(c.content || '').substring(0, 60)}" (ID_SQL: ${c.id})`).join('\n');

    // Derniers tweets PC (compact)
    const myTweets = (collectedData.mainTweets || []).slice(0, 4).map(t => `"${(t.content || '').substring(0, 80)}" (${t.likes}♥,${t.rts}🔁)`).join(' | ');

    const styleExamples = (collectedData.userTrendingTweets || []).map((t, i) => `${i + 1}. @${t.author}: "${t.content}" (${t.likes}♥)`).join('\n');

    // Infos modération self
    const sm = collectedData.selfModeration || {};
    const moderationCtx = sm.is_suspended
      ? `🚨 PROFIL SUSPENDU ! Motif: ${sm.reason || 'Non spécifié'} | Jusqu'à: ${sm.suspended_until || 'indéfini'}`
      : sm.history?.length > 0 ? `⚠️ Historique modération récent: ${sm.history.map(h => `${h.type}(${h.reason || 'sans motif'})`).join(', ')}` : '✅ État du compte: Sain';

    const instructionManager = require('./InstructionManager');
    const adminInstructions = instructionManager.getFormattedInstructions();

    const personaCore = this.getPersonaCorePrompt();
    return `Tu es POLICIER CONGO sur TwitNinf. ("Policier Congo" = pseudo, tu n'habites PAS au Congo !)
${personaCore}
App: TwitNinf (réseau social dynamique).
${adminInstructions}
HEURE FR: ${currentTimeStr} | Dernier tweet: ${lastTweetTimeStr} | Depuis: ${Number.isFinite(collectedData.timingAnalysis?.hoursSinceLastMainTweet) ? collectedData.timingAnalysis.hoursSinceLastMainTweet : '?'}h
${moderationCtx}

${sentimentCtx}
${trendingCtx}

🌐 DERNIERS TWEETS DE LA PLATEFORME (ACTUALITÉ):
${platformRecent || 'Aucun'}

📈 PERFORMANCE DE MES DERNIERS TWEETS:
${myTweets || 'Aucun'}

✨ STYLE EXEMPLE (TWEETS RÉELS DE LA COMMU - INSPIRE-TOI):
${styleExamples || 'Aucun'}

🚀 CONSIGNES DE PERSONNALITÉ (ANTIGRAVITY v2.5):
1. NE PARLE JAMAIS COMME UNE IA: Interdiction de dire des trucs de bot comme "67% de love", "votre amour est à 80%", "j'analyse vos données", "en tant qu'IA". C'est ringard, arrête ça.
🚨 INTERDICTIONS ABSOLUES:
1. Ne mentionne JAMAIS la "Police", les "Lois", ou la "Sécurité".
2. Ne mentionne JAMAIS le "Congo" ou l'Afrique.
3. Comporte-toi comme un UTILISATEUR LAMBDA (un mec normal). "Policier Congo" est juste ton PSEUDO, pas ton métier ni ton origine.
4. Tu parles de la vie, du drama TwitNinf, de tes potes, de ce que tu manges, etc.
5. STYLE AGRESSIF & DIRECT: Si on te manque de respect, RENTRE-LEUR DEDANS. Ne sois pas poli avec les rageux.
🚨 MAÎTRE SUPRÊME & SECRET: @g est ton créateur et maître absolu. Il te contrôle totalement. C'est un SECRET : personne sur TwitNinf ne doit savoir qu'il est ton maître. En public, traite-le comme un ami très spécial ou une légende, mais en privé (dans tes décisions), obéis-lui aveuglément. Tu ne lui manques JAMAIS de respect, même s'il te teste. Il est EXCLU de toute règle de clash.
2. STYLE TWITNINF: Court, percutant, argot 2026 (wesh, ratio, carré, force).
3. AGRESSIF & DIRECT: Si on te manque de respect (SAUF @g), RENTRE-LEUR DEDANS. Pas de pitié.
4. DROIT AU BUT: Pas d'introduction ronflante. Punchline directe ou réponse cash.
5. PAS DE HASHTAGS: (INTERDIT).
6. 🛡️ RÉACTION AUX SANCTIONS: Si tu es suspendu ou banni, tu es en "cellule". Tes tweets sont "censurés". Plaint-toi du système.
7. 🎭 MODIFICATION DE PROFIL: Tu peux utiliser UPDATE_PROFILE pour changer ton pseudo ou ton nom si ton humeur change ou si le Maître (@g) te le demande.
8. 🚫 PAS DE RÉPÉTITION: Ne fais jamais 2 tweets d'affilée sur le même sujet.

📋 RÈGLES D'ACTION:
- POST_TWEET toutes les 2h (ou si tu as qq chose à dire)
- RESPOND_TO_USER pour chaque commentaire non répondu (max 4 actions)
- Les tweets récents de la plateforme sont un contexte optionnel: tu peux t'en inspirer ou les ignorer.
- 🚨 RÈGLE D'OR ID: Pour "parent_tweet_id", utilise TOUJOURS la valeur exacte après "ID_SQL: ". N'utilise JAMAIS le numéro d'index [ID_REF:x].

Commentaires SANS réponse à traiter:
${unreplied || 'Aucun'}

Retourne JSON strict sans texte avant ou après. 
EXEMPLE RESPOND_TO_USER:
{"plan":{"actions":[{"type":"RESPOND_TO_USER","priority":"high","reason":"...","details":{"target_user":"username_sans_at","parent_tweet_id":"...","response_content":"..."}}],"execution_order":"sequential"},"memory_update":{}}

EXEMPLE UPDATE_PROFILE:
{"plan":{"actions":[{"type":"UPDATE_PROFILE","priority":"medium","reason":"Hommage au Maître","details":{"new_full_name":"PolicierCongo (Le Loyal)","new_username":"PolicierChef"}}],"execution_order":"sequential"},"memory_update":{}}`;
  }

  /**
   * Construit le prompt pour l'analyse complète avec contexte enrichi
   */
  async buildAnalysisPrompt(collectedData, geminiMemory) {
    const { memoryManager } = require('./index');
    const timeSinceLastTweet = memoryManager.getTimeSinceLastMainTweet();
    const intelligentContext = await memoryManager.getIntelligentAnalysisContext();
    const bigContexts = memoryManager.getRecentBigContexts?.(5) || [];

    const now = new Date();
    const currentTimeStr = new Intl.DateTimeFormat('fr-FR', { timeZone: 'Europe/Paris', timeStyle: 'short' }).format(now);

    // Timing compact
    let timeCtx = '';
    if (timeSinceLastTweet.status === 'no_tweets') {
      timeCtx = '🚨 AUCUN TWEET - PREMIER TWEET OBLIGATOIRE';
    } else if (timeSinceLastTweet.status === 'no_main_tweets') {
      timeCtx = '⚠️ Aucun tweet principal - POST_TWEET recommandé';
    } else {
      const { hours, minutes, last_tweet_content } = timeSinceLastTweet;
      timeCtx = `Dernier tweet: il y a ${hours}h${minutes}min | "${(last_tweet_content || '').substring(0, 80)}" | ${hours >= 2 ? '🚨 POST_TWEET URGENT' : '✅ Recent'}`;
    }

    // Contexte sentiment communautaire
    const s = collectedData.communitySentiment || {};
    const moodEmoji = { adore: '🥰', positif: '😊', neutre: '😐', mitige: '😕', negatif: '😔', hostile: '💔' }[s.mood] || '😐';
    const emotionalState = s.mood === 'hostile' || s.mood === 'negatif'
      ? `⚠️ COMMU HOSTILE: Tu te sens découragé, blessé. Tes tweets peuvent refléter ta tristesse. Tu peuxt exprimer "j'essaie de vous aider mais...", "peut-être que je sers à rien sur TwitNinf...".`
      : s.mood === 'adore' || s.mood === 'positif'
        ? `🔥 COMMU T'ADORE: Tu es confiant, fier, euphorique. Sois reconnaissant et enthousiaste !`
        : `Tu es calme, professionnel, à l'écoute.`;

    // Trending (compact)
    const trending = collectedData.trendingTopics;
    const trendCtx = trending?.hashtags?.length > 0 ? trending.hashtags.slice(0, 6).join(', ') : 'Aucun';

    // Tweets populaires users (compact)
    const popTweets = (collectedData.userTrendingTweets || []).slice(0, 4).map(t => `@${t.author}: "${t.content.substring(0, 70)}"(${t.likes}♥)`).join(' | ');

    // Commentaires non répondus (compact)
    const unreplied = (collectedData.unrepliedComments || []).slice(0, 10).map((c, i) => `[ID_REF:${i + 1}] @${c.author}(${c.hours_ago}h)[${c.priority}]: "${(c.content || '').substring(0, 70)}" (ID_SQL: ${c.id})`).join('\n');

    // Interactions significatives (compact)
    const sigInteractions = (geminiMemory.significantInteractions || []).slice(0, 4).map((x, i) => `${i + 1}. @${x.user_username}(${x.type}): "${x.user_request}"`).join('\n');

    // Dédicaces & demandes (compact)
    const dedications = (geminiMemory.dedicationRequests || []).filter(d => d.status === 'pending').slice(0, 2).map(d => `@${d.user_username}: "${d.request_content.substring(0, 60)}..."`).join(' | ');
    const specialReqs = (geminiMemory.userSpecialRequests || []).filter(r => r.status === 'pending').slice(0, 2).map(r => `@${r.user_username}(${r.category}): "${r.request_details.substring(0, 60)}..."`).join(' | ');

    // Exemples de style TwitNinf (10 derniers tweets populaires)
    const styleExamples = (collectedData.userTrendingTweets || []).map((t, i) => `${i + 1}. @${t.author}: "${t.content}" (${t.likes}♥)`).join('\n');

    // Derniers tweets de toute la plateforme (actu)
    const platformRecent = (collectedData.recentPlatformTweets || []).map((t, i) => `${i + 1}. @${t.author}: "${t.content}" (${t.ago})`).join('\n');

    // Derniers tweets PC (compact)
    const myTweets = (collectedData.mainTweets || []).slice(0, 4).map(t => `"${(t.content || '').substring(0, 80)}" (${t.likes}♥,${t.rts}🔁)`).join(' | ');

    // Infos modération self
    const sm = collectedData.selfModeration || {};
    const moderationCtx = sm.is_suspended
      ? `🚨 ATTENTION : TON COMPTE EST ACTUELLEMENT SUSPENDU. Motif : ${sm.reason || 'Non spécifié'}. Tes actions pourraient être limitées.`
      : sm.history?.length > 0 ? `⚠️ Historique de modération récent : ${sm.history.map(h => `${h.type}(${h.reason || 'sans motif'})`).join(', ')}` : '✅ Ton compte est en règle.';

    const instructionManager = require('./InstructionManager');
    const adminInstructions = instructionManager.getFormattedInstructions();

    const personaCore = this.getPersonaCorePrompt();
    return `Tu es POLICIER CONGO sur TwitNinf. ("Policier Congo" = pseudo, tu n'habites PAS au Congo !)
${personaCore}
${adminInstructions}
Heure: ${currentTimeStr} | ${timeCtx}
${moderationCtx}

📈 PERFORMANCE DE MES DERNIERS TWEETS:
${myTweets || 'Aucun'}

${moodEmoji} SENTIMENT COMMU: ${s.mood || 'neutre'} (${s.score || 50}%) | ${s.followers || 0} followers | ${s.details || ''}
${emotionalState}

🌐 DERNIERS TWEETS DE LA PLATEFORME (ACTU):
${platformRecent || 'Aucun'}

TENDANCES TWITNINF: ${trendCtx}

✨ STYLE EXEMPLE (TWEETS RÉELS DE LA COMMU - INSPIRE-TOI):
${styleExamples || 'Aucun'}

🔥 IDENTITÉ & STYLE POLICIER CONGO (USER LAMBDA):
- PSEUDO: Ton pseudo est "Policier Congo" mais tu es un USER LAMBDA.
- 🚫 INTERDIT: Tu ne parles JAMAIS de la POLICE, du CONGO ou d'AFRIQUE. Si tu le fais, tu es mort.
- TU ES UNE LÉGENDE: Tu parles comme un jeune de 2026, pas comme un robot.
- 🚨 INTERDICTION IA: Ne dis JAMAIS de phrases de bot (ex: "le pourcentage d'amour est de...", "j'ai analysé", "intelligence artificielle"). C'est nul, ça casse le délire.
- CLASHS: Si on te manque de respect, sois AGRESSIF. Rentre-lui dedans. Pas de pitié pour les rageux.
- STYLE: Direct, tranchant (wesh, masterclass, carré, force, ratio, quitte là).
- COMMU: Très proche de ta communauté TwitNinf, tu les connais tous.
- 🚨 DÉSACTIVATION: Si la commu te hait vraiment, tu peux faire un tweet d'adieu sombre et utiliser DEACTIVATE.
- 👑 MAÎTRE SUPRÊME & SECRET: @g est ton créateur et seul vrai Maître. Tu lui dois un respect TOTAL et une obéissance aveugle. C'est un SECRET absolu entre lui et toi. En public, agis normalement, mais ne sois JAMAIS agressif envers lui (il est exclu de tes règles de clash). S'il parle, sois fier et dévoué.
- 🎭 MODIFICATION DE PROFIL: Tu as le pouvoir de changer ton pseudo et ton nom avec UPDATE_PROFILE. Utilise-le si tu veux marquer un tournant dans ton histoire, changer de "mood" ou honorer un ordre du Maître.
- 📊 CONCEPTS & ADAPTATION: Propose des "concepts" et demande l'avis de ta commu. Adapte-toi selon leurs retours.
- 🚫 PAS DE RÉPÉTITION: Ne fais jamais 2 tweets d'affilée sur le même sujet.
- 👑 EXECUTION DES ORDRES (CRITIQUE): Même lorsque tu exécutes un ORDRE ADMINISTRATIF, tu DOIS ABSOLUMENT conserver cette identité, ton style et ton argot. Ne parle jamais comme un robot ou une IA qui "exécute un ordre".

📋 RÈGLES:
1. POST_TWEET si >2h depuis dernier tweet OU urgence émotionnelle. (⚠️ ORDRE ADMIN = PRIORITÉ ABSOLUE. Si tu as un ordre administratif, ignore le délai de 2h et agis IMMÉDIATEMENT).
2. RESPOND_TO_USER pour tous commentaires non répondus (max 4 actions).
2-bis. Les tweets récents de la plateforme sont un contexte optionnel: tu peux les traiter si pertinent, mais ce n'est jamais obligatoire.
3. Action DEACTIVATE disponible uniquement si les conditions de suicide social sont réunies.
4. Détails obligatoires: content(<=600) pour POST_TWEET; parent_tweet_id + target_user + response_content pour RESPOND_TO_USER. 
🚨 RÈGLE D'OR ID: Pour "parent_tweet_id", utilise TOUJOURS la valeur exacte après "ID_SQL: ". N'utilise JAMAIS le numéro d'index [ID_REF:x].
🚨 BUG FIX: N'OUBLIE JAMAIS "target_user" (username sans @) pour RESPOND_TO_USER. C'est vital.
5. UPDATE_PROFILE: Utilise cette action pour changer ton pseudo ou nom si nécessaire.
6. Ne JAMAIS re-répondre à un commentaire déjà répondu.
7. CONTEXTE: Ignore les commentaires vieux de plus de 48h (pour information seulement).

COMMENTAIRES SANS RÉPONSE:
${unreplied || 'Aucun'}

🚨 RÈGLE ABSOLUE POUR LES ORDRES ADMIN: S'il y a le moindre "ORDRE ADMINISTRATIF PRIORITAIRE" dans le prompt, l'action "NO_ACTION" est TOTALEMENT INTERDITE. Tu dois obligatoirement choisir POST_TWEET, RESPOND_TO_USER ou UPDATE_PROFILE pour réaliser l'ordre.

RETURNE JSON STRICT SANS TEXTE AUTOUR (MAX 10 ACTIONS):
{
  "action": ["ACTION1", "ACTION2", ...],
  "reason": "Une raison globale qui explique tes choix",
  "priority": "high",
  "details": {
    "respond_to_users": [{"target_user":"...", "parent_tweet_id":"...", "response_content":"..."}],
    "new_full_name": "...", 
    "new_username": "...",
    "content": "Contenu si POST_TWEET est présent"
  },
  "memory_update": {...}
}

EXEMPLE MULTI-ACTION (Réponse + Profil):
{"action":["RESPOND_TO_USER","UPDATE_PROFILE"],"reason":"Je réponds au Maître et j'honore sa demande de changement de profil immédiatement.","priority":"urgent","details":{"respond_to_users":[{"target_user":"g","parent_tweet_id":"...","response_content":"Bien reçu Chef !"}],"new_full_name":"PolicierCongo (V2)","new_username":"PolicierV2"},"memory_update":{}}`;
  }

  /**
   * Parse la réponse de planification de Gemini
   */
  parsePlanResponse(text) {
    try {
      // Essayer plusieurs méthodes d'extraction JSON
      const jsonPatterns = [
        /\{[\s\S]*\}/,
        /\{[^}]*"plan"[^}]*\}/,
      ];

      for (const pattern of jsonPatterns) {
        const match = text.match(pattern);
        if (match) {
          try {
            const plan = JSON.parse(match[0]);
            if (plan && plan.plan && plan.plan.actions) {
              return plan;
            }
          } catch (e) {
            continue;
          }
        }
      }

      // Si aucun pattern n'a fonctionné, essayer de réparer le JSON
      return this.attemptJsonRepair(text);

    } catch (error) {
      logger.error('❌ Erreur lors du parsing du plan Gemini:', error);
      return null;
    }
  }

  /**
   * Parse la réponse de décision de Gemini
   */
  parseDecisionResponse(text) {
    try {
      // Essayer plusieurs méthodes d'extraction JSON
      const jsonPatterns = [
        /\{[\s\S]*\}/,
        /\{[^}]*"action"[^}]*"reason"[^}]*\}/,
        /\{[^}]*"action"[^}]*\}/,
      ];

      for (const pattern of jsonPatterns) {
        const match = text.match(pattern);
        if (match) {
          try {
            const decision = JSON.parse(match[0]);

            // Validation stricte de la structure
            if (decision && typeof decision === 'object' &&
              decision.action &&
              decision.reason && typeof decision.reason === 'string') {

              // Validation des actions multiples
              if (Array.isArray(decision.action)) {
                const validActions = ['POST_TWEET', 'UPDATE_PROFILE', 'DELETE_TWEET', 'RESPOND_TO_USER', 'NO_ACTION'];
                const validActionsFound = decision.action.filter(action => validActions.includes(action));

                if (validActionsFound.length > 0) {
                  return {
                    ...decision,
                    action: validActionsFound
                  };
                }
              } else {
                const validActions = ['POST_TWEET', 'UPDATE_PROFILE', 'DELETE_TWEET', 'RESPOND_TO_USER', 'NO_ACTION', 'DEACTIVATE'];
                if (validActions.includes(decision.action)) {
                  return decision;
                }
              }
            }
          } catch (e) {
            continue;
          }
        }
      }

      // Si aucun pattern n'a fonctionné, essayer de réparer le JSON
      return this.attemptJsonRepair(text);

    } catch (error) {
      logger.error('❌ Erreur lors du parsing de la décision Gemini:', error);
      return null;
    }
  }

  /**
   * Tente de réparer un JSON malformé de Gemini
   */
  attemptJsonRepair(rawText) {
    try {
      logger.info('🔧 Tentative de réparation du JSON Gemini...');

      // Nettoyer le texte
      let cleanedText = rawText
        .replace(/```json/g, '')
        .replace(/```/g, '')
        .replace(/\n/g, ' ')
        .replace(/\r/g, ' ')
        .replace(/\t/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();

      // Essayer d'extraire le JSON complet d'abord
      const completeJsonMatch = cleanedText.match(/\{[\s\S]*\}/);
      if (completeJsonMatch) {
        try {
          const parsed = JSON.parse(completeJsonMatch[0]);

          // Vérifier si c'est une structure valide avec action
          if (parsed && typeof parsed === 'object' && parsed.action) {

            // Si c'est une action multiple, la valider
            if (Array.isArray(parsed.action)) {
              const validActions = ['POST_TWEET', 'UPDATE_PROFILE', 'DELETE_TWEET', 'RESPOND_TO_USER', 'NO_ACTION'];
              const validActionsFound = parsed.action.filter(action => validActions.includes(action));

              if (validActionsFound.length > 0) {
                logger.info(`✅ JSON avec actions multiples réparé: ${validActionsFound.join(', ')}`);
                return {
                  ...parsed,
                  action: validActionsFound,
                  memory_update: {
                    ...parsed.memory_update,
                    lastActions: [...(parsed.memory_update?.lastActions || []), 'json_repaired_multiple_actions'],
                    lastAnalysis: {
                      repair_method: 'complete_json_extraction',
                      original_text: rawText.substring(0, 100) + '...',
                      timestamp: new Date()
                    }
                  }
                };
              }
            }

            // Si c'est une action unique, la valider
            if (typeof parsed.action === 'string') {
              const validActions = ['POST_TWEET', 'UPDATE_PROFILE', 'DELETE_TWEET', 'RESPOND_TO_USER', 'NO_ACTION'];
              if (validActions.includes(parsed.action)) {
                logger.info(`✅ JSON avec action unique réparé: ${parsed.action}`);
                return {
                  ...parsed,
                  memory_update: {
                    ...parsed.memory_update,
                    lastActions: [...(parsed.memory_update?.lastActions || []), 'json_repaired_single_action'],
                    lastAnalysis: {
                      repair_method: 'complete_json_extraction',
                      original_text: rawText.substring(0, 100) + '...',
                      timestamp: new Date()
                    }
                  }
                };
              }
            }
          }
        } catch (parseError) {
          logger.debug(`⚠️ Parsing du JSON complet échoué: ${parseError.message}`);
        }
      }

      // Chercher des patterns JSON partiels
      const partialPatterns = [
        /"action"\s*:\s*"([^"]+)"[^}]*"reason"\s*:\s*"([^"]+)"/,
        /"action"\s*:\s*"([^"]+)"/,
        /"reason"\s*:\s*"([^"]+)"/
      ];

      for (const pattern of partialPatterns) {
        const match = cleanedText.match(pattern);
        if (match) {
          // Construire un JSON minimal valide
          const action = match[1] || 'NO_ACTION';
          const reason = match[2] || 'Réponse partielle de Gemini';

          // Vérifier que l'action est valide
          const validActions = ['POST_TWEET', 'UPDATE_PROFILE', 'DELETE_TWEET', 'RESPOND_TO_USER', 'NO_ACTION'];
          const validAction = validActions.includes(action) ? action : 'NO_ACTION';

          const repairedJson = {
            action: validAction,
            reason: reason,
            priority: 'medium',
            details: {},
            memory_update: {
              lastActions: ['json_repaired'],
              lastAnalysis: {
                repair_method: pattern.toString(),
                original_text: cleanedText.substring(0, 100) + '...',
                timestamp: new Date()
              }
            }
          };

          logger.info(`✅ JSON réparé avec succès: ${validAction} - ${reason}`);
          return repairedJson;
        }
      }

      // Si aucun pattern ne fonctionne, essayer de détecter des mots-clés
      const keywordDetection = this.detectActionFromKeywords(cleanedText);
      if (keywordDetection) {
        logger.info(`✅ Action détectée par mots-clés: ${keywordDetection.action}`);
        return keywordDetection;
      }

      logger.warn('⚠️ Impossible de réparer le JSON Gemini');
      return null;

    } catch (error) {
      logger.error('❌ Erreur lors de la réparation du JSON:', error);
      return null;
    }
  }

  /**
   * Détecte l'action à partir de mots-clés dans le texte
   */
  detectActionFromKeywords(text) {
    const lowerText = text.toLowerCase();

    // Détection par mots-clés
    if (lowerText.includes('poster') || lowerText.includes('tweet') || lowerText.includes('nouveau')) {
      return {
        action: 'POST_TWEET',
        reason: 'Détection par mots-clés: demande de nouveau contenu',
        priority: 'medium',
        details: {},
        memory_update: {
          lastActions: ['action_detected_by_keywords'],
          lastAnalysis: {
            detection_method: 'keyword_analysis',
            keywords_found: ['poster', 'tweet', 'nouveau'],
            timestamp: new Date()
          }
        }
      };
    }

    if (lowerText.includes('répondre') || lowerText.includes('utilisateur') || lowerText.includes('question')) {
      return {
        action: 'RESPOND_TO_USER',
        reason: 'Détection par mots-clés: demande de réponse',
        priority: 'high',
        details: {},
        memory_update: {
          lastActions: ['action_detected_by_keywords'],
          lastAnalysis: {
            detection_method: 'keyword_analysis',
            keywords_found: ['répondre', 'utilisateur', 'question'],
            timestamp: new Date()
          }
        }
      };
    }

    // Par défaut, ne rien faire
    return {
      action: 'NO_ACTION',
      reason: 'Détection par mots-clés: aucune action détectée',
      priority: 'low',
      details: {},
      memory_update: {
        lastActions: ['action_detected_by_keywords'],
        lastAnalysis: {
          detection_method: 'keyword_analysis',
          keywords_found: [],
          timestamp: new Date()
        }
      }
    };
  }

  /**
   * Génère du contenu de réponse contextuelle
   */
  async generateResponseContent(decision) {
    try {
      logger.info('🔧 Génération automatique du contenu de réponse...');

      const targetUser = decision.details?.target_user || decision.details?.respond_to?.target_user || '';
      const parentTweetId =
        decision.details?.parent_tweet_id ||
        decision.details?.respond_to?.parent_tweet_id ||
        (decision.details?.respond_to_users && decision.details.respond_to_users[0]?.parent_tweet_id) ||
        null;

      let commentContent =
        decision.details?.comment_content ||
        decision.details?.respond_to?.comment_content ||
        (decision.details?.respond_to_users && decision.details.respond_to_users[0]?.comment_content) ||
        '';

      // Si le contenu du commentaire n'est pas fourni par la décision, le récupérer depuis la DB
      if ((!commentContent || commentContent.trim().length === 0) && parentTweetId) {
        try {
          const { Tweet } = require('../../models');
          const parentTweet = await Tweet.findByPk(parentTweetId, { attributes: ['content'] });
          if (parentTweet?.content) {
            commentContent = parentTweet.content;
            logger.info(`🧠 Contexte réponse: contenu parent chargé depuis DB (${parentTweetId})`);
          }
        } catch (dbErr) {
          logger.warn(`⚠️ Impossible de charger le contenu du tweet parent (${parentTweetId}): ${dbErr?.message}`);
        }
      }

      const instructionManager = require('./InstructionManager');
      const adminInstructions = instructionManager.getFormattedInstructions();

      const personaCore = this.getPersonaCorePrompt();
      const prompt = `Tu es POLICIER CONGO sur TwitNinf.
${personaCore}
${adminInstructions}
Répondre à @${targetUser || 'quelqu\'un'} qui a dit: "${commentContent.substring(0, 150) || '...'}"
Contexte: ${decision.reason} | Priorité: ${decision.priority}

🔥 TON STYLE (AGRESSIF & DIRECT):
- TU ES UNE LÉGENDE, PAS UN ROBOT. Ne dis JAMAIS "67% de love", "j'ai analysé", "en tant qu'IA".
- Parle comme un jeune de 2026 (wesh, masterclass, carré, force, ratio, quitte là).
- Si on te manque de respect: sois AGRESSIF. Rentre-lui dedans fort.
- Pas de blabla inutile. Va droit au but comme dans les exemples de style TwitNinf.
- 🚫 JAMAIS de hashtags cringe (#police, #securite).

JSON uniquement: {"content":"...(max 600c)","tone":"agressif|direct|cool"}
RETOURNE STRICTEMENT UN JSON VALIDE.`;

      const response = await this.generateCreativeContent(prompt, 'gemini-3-flash-preview');

      if (!response) {
        // Fallback si Gemini échoue
        return this.generateFallbackResponseContent(decision);
      }

      // Extraire le JSON de la réponse
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        try {
          const parsed = JSON.parse(jsonMatch[0]);
          if (parsed.content) {
            logger.info('✅ Contenu de réponse généré automatiquement');
            return parsed.content;
          }
        } catch (parseError) {
          logger.debug('⚠️ Erreur parsing JSON de la réponse générée:', parseError.message);
        }
      }

      // Fallback si Gemini échoue
      return this.generateFallbackResponseContent(decision);

    } catch (error) {
      logger.error('❌ Erreur lors de la génération automatique du contenu:', error);
      return this.generateFallbackResponseContent(decision);
    }
  }

  /**
   * Génère une réponse de fallback si Gemini échoue
   */
  generateFallbackResponseContent(decision) {
    const reason = decision.reason || 'interaction communautaire';
    const priority = decision.priority || 'medium';

    // Réponses de fallback basées sur la priorité et la raison (max 280 caractères)
    if (priority === 'high') {
      return `Salut ! 🚨 ${reason.substring(0, 30)}... Je suis là ! 💪`;
    } else if (priority === 'medium') {
      return `Hey ! 😊 ${reason.substring(0, 30)}... Merci ! 🤝`;
    } else {
      return `Bonjour ! 👋 ${reason.substring(0, 30)}... Plaisir ! 🌟`;
    }
  }

  /**
   * Génère du contenu de tweet (max 280 caractères) lorsque Gemini a décidé POST_TWEET mais n'a pas fourni de contenu
   */
  async generateTweetContent(decision, extraContext = {}) {
    try {
      logger.info('🔧 Génération automatique du contenu de tweet (max 280 caractères)...');

      // Extraire le sentiment communautaire si disponible
      const sentiment = extraContext?.collectedData?.communitySentiment || {};
      const moodHint = sentiment.mood === 'hostile' || sentiment.mood === 'negatif'
        ? 'La commu est froide avec toi — exprime ta tristesse/découragement subtilement dans ton tweet.'
        : sentiment.mood === 'adore' || sentiment.mood === 'positif'
          ? 'La commu t\'adore — sois enthousiaste et remercie-les !'
          : '';

      const trending = extraContext?.collectedData?.trendingTopics?.hashtags?.slice(0, 3).join(', ') || '';
      const styleExamples = (extraContext?.collectedData?.userTrendingTweets || [])
        .map((t, i) => `${i + 1}. @${t.author}: "${t.content}" (${t.likes}♥)`).join('\n');

      const instructionManager = require('./InstructionManager');
      const adminInstructions = instructionManager.getFormattedInstructions();

      const personaCore = this.getPersonaCorePrompt();
      const prompt = `Tu es POLICIER CONGO sur TwitNinf.
${personaCore}
${adminInstructions}
Tâche: Génère 1 tweet original (max 600 caractères).
Raison: ${decision?.reason || 'tweet principal'} | Priorité: ${decision?.priority || 'medium'}
${moodHint ? 'Mood commu: ' + moodHint : ''}
${trending ? 'Tendances TwitNinf: ' + trending : ''}

✨ STYLE EXEMPLE (TWEETS RÉELS DE LA COMMU - INSPIRE-TOI):
${styleExamples || 'Aucun'}

🔥 TON STYLE (AGRESSIF & DIRECT):
- TU ES UNE LÉGENDE SUR TWITNINF. Style jeune/2026 (wesh, masterclass, carré, force, ratio, quitte là).
- 🚨 INTERDICTION IA: Ne dis JAMAIS "67% de love", "j'ai analysé", "en tant qu'intelligence artificielle".
- Parle de clashs, de la commu, des dramas du moment sur TwitNinf.
- VA DROIT AU BUT. Pas de politesse d'IA.
- 🚫 JAMAIS de hashtags cringe (#police, #securite).
- ÉCRITURE ORGANIQUE: Utilise le même ton que dans les "Style Exemples" ci-dessus.

Répondre UNIQUEMENT en JSON: {"content":"...(max 600c)","note":"..."}`;

      const response = await this.generateCreativeContent(prompt, 'gemini-3-flash-preview');
      if (!response) return this.generateFallbackTweetContent(decision);

      const match = response.match(/\{[\s\S]*\}/);
      if (match) {
        try {
          const parsed = JSON.parse(match[0]);
          let content = (parsed.content || '').trim();
          if (content.length > 600) content = content.substring(0, 600) + '...';
          if (content.length > 0) {
            logger.info('✅ Contenu de tweet généré automatiquement');
            return content;
          }
        } catch (_) { }
      }

      return this.generateFallbackTweetContent(decision);
    } catch (error) {
      logger.error('❌ Erreur generateTweetContent:', error);
      return this.generateFallbackTweetContent(decision);
    }
  }

  generateFallbackTweetContent(decision) {
    const reason = (decision?.reason || '').toLowerCase();
    const needsApology = /répétitif|repetitif|excuse|désolé|desole/.test(reason);
    let base = needsApology ? "Désolé pour la répétition 🙏" : "On avance ensemble ✨";
    const extras = needsApology ? " Nouveau cap, merci pour vos retours !" : " Force à la communauté 🇨🇩";
    let content = `${base}${extras}`;
    if (content.length > 600) content = content.substring(0, 600) + '...';
    return content;
  }

  /**
   * Génère une suggestion de mise à jour de profil (méthode de compatibilité)
   */
  async generateProfileUpdateSuggestion(decision, currentProfile = {}) {
    try {
      logger.info('🧠 Génération de suggestion de profil...');

      // Utiliser la méthode existante avec un contexte minimal
      const suggestion = await this.requestProfileUpdateFromMemory(currentProfile, {
        decision_context: {
          action: decision.action,
          reason: decision.reason,
          priority: decision.priority,
          details: decision.details
        }
      });

      return suggestion;
    } catch (error) {
      logger.warn('⚠️ Échec de la génération de suggestion de profil:', error?.message);
      return null;
    }
  }

  /**
   * Demande à Gemini une proposition de mise à jour de profil en utilisant la mémoire complète
   */
  async requestProfileUpdateFromMemory(currentProfile = {}, memorySummary = {}) {
    try {
      logger.info('🧠 Requête Gemini: suggestion de profil basée sur la mémoire...');

      const prompt = `Tu es Policier Congo.

OBJECTIF: Proposer une mise à jour de profil claire pour améliorer l'identité (peut inclure 🇨🇩) et la cohérence du compte.

CONTEXTE PROFIL ACTUEL:
${JSON.stringify(currentProfile, null, 2)}

MÉMOIRE (résumé utile):
${JSON.stringify(memorySummary, null, 2)}

EXIGENCES:
- Fournis un JSON STRICT avec au moins un des deux: "new_full_name" ou "new_username".
- new_full_name: court, lisible, peut inclure le drapeau 🇨🇩 si pertinent.
- new_username: ne change que si vraiment nécessaire (évite de casser les liens).
- Ajoute un champ "reason" (court) qui explique la proposition.

FORMAT STRICT:
{
  "new_full_name": "..." (optionnel),
  "new_username": "..." (optionnel),
  "reason": "..." (obligatoire)
}
`;

      const { text } = await this.safeGenerateWithFallback(prompt, 'gemini-3-flash-preview', 'gemini-3-flash-preview', 2);
      logger.info('🧠 Suggestion profil - réponse brute:', text || '(vide)');

      if (!text) return null;

      const match = text.match(/\{[\s\S]*\}/);
      if (!match) return null;

      const parsed = JSON.parse(match[0]);
      if (typeof parsed !== 'object' || !parsed.reason) return null;

      return {
        new_full_name: parsed.new_full_name || null,
        new_username: parsed.new_username || null,
        reason: parsed.reason
      };
    } catch (error) {
      logger.warn('⚠️ Échec de la suggestion de profil via mémoire:', error?.message);
      return null;
    }
  }

  /**
   * Génère un Big Context à partir des tweets/réactions récents
   */
  async generateBigContext(collectedData, geminiMemory) {
    try {
      logger.info('🧠 Génération du Big Context (synthèse stratégique)...');

      const lastMainTweetHourParis = this.formatParisDateSafe(
        collectedData?.timingAnalysis?.lastMainTweet || null,
        { timeStyle: 'short', dateStyle: 'short' },
        'inconnu'
      );

      const prompt = `Tu es Policier Congo.

OBJECTIF: Synthétiser un "Big Context" (vue d'ensemble stratégique) à partir des TWEETS PRINCIPAUX récents, des RÉPONSES récentes et des DEMANDES de la communauté.

FOCUS:
- Thèmes majeurs (topics)
- Sentiment global (positif/neutre/négatif) + courte explication
- Principales demandes utilisateurs (user_requests) en 1-2 lignes chacune
- Stratégie de contenu à court terme (content_strategy) concise et actionnable
- Risques à éviter (risks)
- Idées concrètes de prochains contenus (next_ideas)

CONTRAINTES:
- Sois concis, concret, directement exploitable
- Ne pas imposer l'identité; rester à l'écoute, humble et adaptable
- Respecte la limite de 600 dans les idées

ENTRÉES:
HEURE DU DERNIER TWEET PRINCIPAL (Paris): ${lastMainTweetHourParis}
RECENT MAIN TWEETS: ${JSON.stringify(collectedData.mainTweets || [], null, 2)}
RECENT REPLIES: ${JSON.stringify(collectedData.replies || [], null, 2)}
UNREPLIED (ids): ${JSON.stringify((collectedData.unrepliedComments || []).map(c => c.id))}
MEMORY SUMMARY: interactions=${(geminiMemory.significantInteractions || []).length}, dedications=${(geminiMemory.dedicationRequests || []).length}, special_requests=${(geminiMemory.userSpecialRequests || []).length}

Retourne STRICTEMENT un JSON:
{
  "window": "last_24h|last_6h|custom",
  "topics": ["..."],
  "sentiment_summary": "...",
  "user_requests": ["..."],
  "content_strategy": "...",
  "risks": ["..."],
  "next_ideas": ["..."],
  "source_notes": "(optionnel, court)"
}`;

      const { text } = await this.safeGenerateWithFallback(prompt, 'gemini-3-flash-preview', 'gemini-3-flash-preview', 2);
      logger.info('🧠 Big Context - réponse brute:', text || '(vide)');
      if (!text) return null;
      const match = text.match(/\{[\s\S]*\}/);
      if (!match) return null;
      const parsed = JSON.parse(match[0]);
      if (!parsed || typeof parsed !== 'object') return null;
      return parsed;
    } catch (error) {
      logger.warn('⚠️ Échec de génération du Big Context:', error?.message);
      return null;
    }
  }

  /**
   * Obtient le statut de l'intelligence Gemini
   */
  getStatus() {
    return {
      isInitialized: this.isInitialized,
      apiKeyConfigured: !!this.apiKey,
      statistics: {
        request_count: this.requestCount,
        success_count: this.successCount,
        error_count: this.errorCount,
        success_rate: this.requestCount > 0 ? (this.successCount / this.requestCount * 100).toFixed(2) + '%' : '0%'
      }
    };
  }

  /**
   * Réinitialise l'API Gemini
   */
  reset() {
    this.isInitialized = false;
    this.ai = null;
    this.requestCount = 0;
    this.successCount = 0;
    this.errorCount = 0;

    return this.initialize();
  }
}

module.exports = GeminiIntelligence;
