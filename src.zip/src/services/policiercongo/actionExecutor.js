/**
 * ⚡ Exécuteur d'Actions - Exécution des actions décidées par Gemini
 * 
 * Ce module exécute toutes les actions décidées par l'intelligence Gemini
 * en coordonnant avec les autres services et en gérant les erreurs.
 */

const logger = require('../../utils/logger');

class ActionExecutor {
  constructor() {
    this.executionCount = 0;
    this.successCount = 0;
    this.errorCount = 0;
    this.lastExecution = null;
  }

  /**
   * Exécute une action avec son contexte
   */
  async executeWithContext(action, context) {
    try {
      logger.info(`🎯 Exécution de ${action.type} avec contexte futur...`);
      
      // Construire la décision pour l'exécution
      const executionDecision = {
        action: action.type,
        reason: action.reason,
        priority: action.priority,
        details: {
          target_user: action.target_user,
          context: action.context,
          future_context: context
        }
      };

      // Exécuter l'action avec le contexte enrichi
      const result = await this.execute(executionDecision);
      
      // Enrichir le résultat avec le contexte utilisé
      return {
        ...result,
        context_used: context,
        strategic_impact: this.assessStrategicImpact(action, result, context)
      };

    } catch (error) {
      logger.error(`❌ Erreur lors de l'exécution avec contexte:`, error);
      return { success: false, error: error.message, context_used: context };
    }
  }

  /**
   * Exécute une action simple ou multiple
   */
  async execute(decision) {
    try {
      this.executionCount++;
      const startTime = new Date();

      // Vérifier si c'est une action multiple
      if (Array.isArray(decision.action)) {
        logger.info(`🚀 Exécution de ${decision.action.length} actions multiples: ${decision.action.join(', ')}`);
        return await this.executeMultipleActions(decision);
      }

      return await this.executeSingleAction(decision, startTime);

    } catch (error) {
      this.errorCount++;
      logger.error(`❌ Erreur lors de l'exécution de l'action ${decision.action}:`, error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Exécute une action simple
   */
  async executeSingleAction(decision, startTime = new Date()) {
    try {
      logger.info(`🚀 Exécution de l'action: ${decision.action}`);

      let result;
      
      switch (decision.action) {
        case 'POST_TWEET':
          result = await this.executePostTweet(decision);
          break;
          
        case 'UPDATE_PROFILE':
          result = await this.executeUpdateProfile(decision);
          break;
          
        case 'DELETE_TWEET':
          logger.warn('🚨🚨🚨 TENTATIVE DE SUPPRESSION DE TWEET DÉTECTÉE - Validation stricte...');
          result = await this.executeDeleteTweet(decision);
          break;
          
        case 'RESPOND_TO_USER':
          result = await this.executeRespondToUser(decision);
          break;
          
        case 'DEACTIVATE':
          logger.warn('🚨🚨🚨 DÉSACTIVATION DÉTECTÉE (SUICIDE SOCIAL) !');
          result = await this.executeDeactivate(decision);
          break;
          
        case 'NO_ACTION':
          logger.info('⏰ Aucune action requise selon Gemini');
          result = { success: true, action: 'NO_ACTION' };
          break;
          
        default:
          logger.warn(`⚠️ Action inconnue: ${decision.action}`);
          result = { success: false, error: 'Action inconnue' };
      }

      const endTime = new Date();
      const duration = endTime - startTime;

      // Mettre à jour les statistiques
      if (result.success) {
        this.successCount++;
      } else {
        this.errorCount++;
      }

      this.lastExecution = {
        action: decision.action,
        timestamp: startTime,
        duration,
        success: result.success,
        result: result
      };

      logger.info(`✅ Action ${decision.action} exécutée en ${duration}ms - ${result.success ? 'Succès' : 'Échec'}`);

      return result;

    } catch (error) {
      this.errorCount++;
      logger.error(`❌ Erreur lors de l'exécution de l'action ${decision.action}:`, error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Exécute des actions multiples
   */
  async executeMultipleActions(decision) {
    try {
      logger.info(`🔄 Exécution de ${decision.action.length} actions multiples...`);
      
      const results = [];
      const actions = decision.action;
      
      for (let i = 0; i < actions.length; i++) {
        const actionType = actions[i];
        logger.info(`🎯 Action ${i + 1}/${actions.length}: ${actionType}`);
        
        try {
          // Créer une décision individuelle pour chaque action
          const individualDecision = {
            action: actionType,
            reason: decision.reason,
            priority: decision.priority,
            details: this.extractDetailsForAction(decision.details, actionType, i)
          };
          
          // Exécuter l'action individuelle
          const result = await this.executeSingleAction(individualDecision);
          
          results.push({
            action_index: i,
            action_type: actionType,
            result: result
          });
          
          // Attendre entre les actions pour éviter la surcharge
          if (i < actions.length - 1) {
            const waitTime = decision.priority === 'critical' ? 1000 : 2000;
            logger.info(`⏳ Attente ${waitTime}ms avant la prochaine action...`);
            await new Promise(resolve => setTimeout(resolve, waitTime));
          }
          
        } catch (error) {
          logger.error(`❌ Erreur lors de l'action ${actionType}:`, error);
          results.push({
            action_index: i,
            action_type: actionType,
            result: { success: false, error: error.message }
          });
        }
      }
      
      // Résumé des résultats
      const successCount = results.filter(r => r.result.success).length;
      const overallSuccess = successCount > 0;
      
      logger.info(`✅ Actions multiples terminées: ${successCount}/${actions.length} réussies`);
      
      return {
        success: overallSuccess,
        action: 'MULTIPLE_ACTIONS',
        total_actions: actions.length,
        successful_actions: successCount,
        failed_actions: actions.length - successCount,
        results: results,
        summary: `${successCount}/${actions.length} actions exécutées avec succès`
      };
      
    } catch (error) {
      logger.error('❌ Erreur lors de l\'exécution des actions multiples:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Extrait les détails appropriés pour une action spécifique
   */
  extractDetailsForAction(details, actionType, actionIndex) {
    if (!details) return {};
    
    switch (actionType) {
      case 'POST_TWEET':
        return details.post_tweet || details.content ? { content: details.post_tweet?.content || details.content, tweet_type: details.post_tweet?.tweet_type || details.tweet_type || 'general' } : {};
        
      case 'RESPOND_TO_USER':
        if (details.respond_to_users && Array.isArray(details.respond_to_users) && details.respond_to_users[actionIndex]) {
          return details.respond_to_users[actionIndex];
        }
        return details.respond_to || details.parent_tweet_id ? {
          parent_tweet_id: details.respond_to?.parent_tweet_id || details.parent_tweet_id,
          target_user: details.respond_to?.target_user || details.target_user,
          response_content: details.respond_to?.response_content || details.response_content
        } : {};
        
      case 'UPDATE_PROFILE':
        return {
          new_username: details.new_username,
          new_full_name: details.new_full_name
        };
        
      case 'DELETE_TWEET':
        return details.delete_tweet || details.tweet_id ? {
          tweet_id: details.delete_tweet?.tweet_id || details.tweet_id,
          emergency_level: details.delete_tweet?.emergency_level || details.emergency_level,
          legal_justification: details.delete_tweet?.legal_justification || details.legal_justification
        } : {};
        
      default:
        return {};
    }
  }

  /**
   * Exécute l'action de poster un tweet
   */
  async executePostTweet(decision) {
    try {
      logger.info('📝 Exécution de la création de tweet...');
      
      let tweetContent = decision.details?.content;
      
      // Si c'est une action multiple, chercher le contenu dans les sous-détails
      if (!tweetContent && decision.details?.post_tweet) {
        tweetContent = decision.details.post_tweet.content;
      }
      
      // Si toujours pas de contenu, utiliser le fallback
      if (!tweetContent) {
        logger.info('ℹ️ Aucun contenu fourni par l\'IA pour POST_TWEET. Tentative de génération via Gemini...');
        try {
          const { geminiIntelligence, memoryManager } = require('./index');
          const extraContext = await memoryManager.getCompleteContextForAI?.();
          const generated = await geminiIntelligence.generateTweetContent({
            action: decision.action,
            reason: decision.reason,
            priority: decision.priority,
            details: decision.details
          }, { timeSinceLastTweet: memoryManager.getTimeSinceLastMainTweet?.(), extraContext });
          if (generated && generated.trim().length > 0) {
            tweetContent = generated.trim();
            logger.info('✅ Contenu généré via Gemini pour POST_TWEET');
          } else {
            logger.info('ℹ️ Génération de contenu échouée. Aucune publication forcée.');
            return { success: true, action: 'NO_ACTION', reason: 'No tweet content provided by AI' };
          }
        } catch (genErr) {
          logger.warn('⚠️ Échec de génération de contenu via Gemini:', genErr?.message);
          return { success: true, action: 'NO_ACTION', reason: 'No tweet content provided by AI' };
        }
      }
      
      if (!tweetContent) {
        logger.info('ℹ️ Aucun contenu fourni par l\'IA pour POST_TWEET. Aucune publication forcée.');
        return { success: true, action: 'NO_ACTION', reason: 'No tweet content provided by AI' };
      }
      
      // Limiter strictement à la longueur maximale configurée
      const { LIMITS } = require('./config');
      if (tweetContent.length > LIMITS.maxTweetLength) {
        logger.warn(`⚠️ Contenu trop long (${tweetContent.length} caractères), troncature à ${LIMITS.maxTweetLength} caractères`);
        tweetContent = tweetContent.substring(0, LIMITS.maxTweetLength - 3) + '...';
      }
      
      // Utiliser le service TweetManager pour créer le tweet
      logger.info('🔧 Tentative d\'accès au TweetManager...');
      const { tweetManager } = require('./index');
      
      if (!tweetManager) {
        logger.error('❌ TweetManager non accessible depuis actionExecutor');
        return { success: false, error: 'TweetManager non accessible' };
      }
      
      if (typeof tweetManager.createTweet !== 'function') {
        logger.error('❌ Méthode createTweet non disponible sur TweetManager');
        return { success: false, error: 'Méthode createTweet non disponible' };
      }
      
      logger.info('✅ TweetManager accessible, création du tweet...');
      logger.info(`📝 Contenu du tweet: "${tweetContent}"`);
      logger.info(`📝 Type: ${decision.details?.tweet_type || decision.details?.post_tweet?.tweet_type || 'general'}`);
      
      const tweetResult = await tweetManager.createTweet({
        content: tweetContent,
        tweet_type: decision.details?.tweet_type || decision.details?.post_tweet?.tweet_type || 'general',
        metadata: {
          source: 'gemini_decision',
          action: decision.action,
          reason: decision.reason,
          priority: decision.priority,
          generated_at: new Date().toISOString(),
          action_type: Array.isArray(decision.action) ? 'multiple' : 'single'
        }
      });
      
      if (!tweetResult.success) {
        logger.error('❌ Échec de la création du tweet:', tweetResult.error);
        return { success: false, error: tweetResult.error };
      }
      
      const tweet = tweetResult.tweet;
      logger.info('✅ Tweet créé avec succès, ID:', tweet?.id);

      // Mettre à jour la mémoire
      const { memoryManager, conceptManager } = require('./index');
      await memoryManager.update({
        tweetHistory: [{
          id: tweet.id,
          content: tweetContent,
          action: decision.action,
          timestamp: new Date()
        }],
        lastActions: [`posted_tweet_${tweet.id}`]
      });

      // Marquer automatiquement le concept le plus probable comme "used"
      try {
        await conceptManager?.markConceptUsedFromContent?.(tweetContent);
      } catch (conceptErr) {
        logger.warn('⚠️ ConceptManager markUsed échoué:', conceptErr?.message);
      }

      // Marquer les tweets plateforme recents comme "deja traites" pour eviter les redites
      try {
        const { dataCollector } = require('./index');
        const freshContext = await dataCollector.collectRecentData();
        const sourceTweetIds = (freshContext?.recentPlatformTweets || [])
          .map((t) => t?.id)
          .filter(Boolean)
          .slice(0, 5);

        if (sourceTweetIds.length > 0) {
          await memoryManager.markPlatformTweetsAsProcessed?.(sourceTweetIds, {
            reason: 'used_for_post_tweet',
            source_action: 'POST_TWEET'
          });
        }
      } catch (sourceMarkErr) {
        logger.warn('⚠️ Marquage tweets plateforme traites échoué:', sourceMarkErr?.message);
      }

      logger.info(`✅ Tweet créé avec succès: ${tweet.id}`);
      
      return {
        success: true,
        action: 'POST_TWEET',
        tweet_id: tweet.id,
        content: tweetContent,
        action_type: Array.isArray(decision.action) ? 'multiple' : 'single'
      };
    } catch (error) {
      logger.error('❌ Erreur lors de la création du tweet:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Exécute l'action de mettre à jour le profil
   */
  async executeUpdateProfile(decision) {
    try {
      logger.info('🔄 Exécution de la mise à jour du profil...');
      logger.info('🔍 Détails initiaux de la décision (profil): ' + JSON.stringify(decision.details || {}, null, 2));
      
      let newUsername = decision.details?.new_username;
      let newFullName = decision.details?.new_full_name;
      
      if (!newUsername || !newFullName) {
        logger.warn('⚠️ Données de profil manquantes dans la décision, tentative de suggestion via Gemini');
        try {
          const { geminiIntelligence } = require('./index');
          const currentProfile = await require('../../models').User.findByPk(require('./config').POLICE_ACCOUNT_ID, { attributes: ['username', 'full_name'] });
          const suggestion = await geminiIntelligence.generateProfileUpdateSuggestion({
            action: 'UPDATE_PROFILE',
            reason: decision.reason,
            priority: decision.priority,
            details: decision.details
          }, currentProfile);
          
          if (suggestion) {
            if (!newUsername && suggestion.new_username) newUsername = suggestion.new_username;
            if (!newFullName && suggestion.new_full_name) newFullName = suggestion.new_full_name;
            logger.info(`✅ Suggestion profil reçue: username=${suggestion.new_username || '(inchangé)'}, full_name=${suggestion.new_full_name || '(inchangé)'} | reason=${suggestion.reason}`);
          }
          
          // Fallback sur le profil actuel si suggestion échoue
          if (!newUsername) newUsername = currentProfile?.username;
          if (!newFullName) newFullName = currentProfile?.full_name || 'PolicierCongo 🇨🇩';
        } catch (e) {
          logger.warn('⚠️ Échec de la suggestion de profil via Gemini:', e?.message);
        }
      }

      if (!newUsername && !newFullName) {
        logger.warn('⚠️ Toujours pas de données de profil suffisantes après tentative, application d\'un fallback local');
        try {
          const { User } = require('../../models');
          const current = await User.findByPk(require('./config').POLICE_ACCOUNT_ID, { attributes: ['username', 'full_name'] });
          if (current) {
            newUsername = current.username;
            const hasFlag = (current.full_name || '').includes('🇨🇩');
            newFullName = hasFlag ? current.full_name : `${current.full_name || 'PolicierCongo'} 🇨🇩`;
            logger.info(`✅ Fallback profil: username=${newUsername}, full_name=${newFullName}`);
          }
        } catch (e) {
          logger.warn('⚠️ Fallback local profil impossible:', e?.message);
        }
        // Si encore insuffisant, déclencher une requête dédiée à Gemini avec la mémoire complète
        if (!newUsername && !newFullName) {
          try {
            const { geminiIntelligence, memoryManager, dataCollector } = require('./index');
            const currentProfile = await require('../../models').User.findByPk(require('./config').POLICE_ACCOUNT_ID, { attributes: ['username', 'full_name'] });
            const memorySummary = await memoryManager.getCompleteContextForAI?.();
            const suggestion = await geminiIntelligence.requestProfileUpdateFromMemory(currentProfile?.toJSON?.() || currentProfile, memorySummary || {});
            if (suggestion) {
              if (suggestion.new_full_name) newFullName = suggestion.new_full_name;
              if (suggestion.new_username) newUsername = suggestion.new_username;
              logger.info(`✅ Suggestion profil via mémoire: username=${newUsername || '(inchangé)'}, full_name=${newFullName || '(inchangé)'} | reason=${suggestion.reason}`);
            }
          } catch (reqErr) {
            logger.warn('⚠️ Requête dédiée Gemini pour profil échouée:', reqErr?.message);
          }
        }
        if (!newUsername && !newFullName) {
          return { success: false, error: 'Données de profil manquantes' };
        }
      }

      // Utiliser le service User pour mettre à jour le profil
      const { User } = require('../../models');
      let updated = false;
      try {
        const [affected] = await User.update({
          username: newUsername,
          full_name: newFullName,
          updated_at: new Date()
        }, {
          where: { id: require('./config').POLICE_ACCOUNT_ID },
          returning: false,
          validate: false
        });
        updated = affected > 0;
      } catch (bulkErr) {
        logger.warn('⚠️ Mise à jour bulk du profil échouée, tentative via instance:', bulkErr?.message);
      }

      if (!updated) {
        try {
          const userInstance = await User.findByPk(require('./config').POLICE_ACCOUNT_ID);
          if (!userInstance) {
            logger.warn('⚠️ Utilisateur PolicierCongo introuvable pour mise à jour de profil');
            return { success: false, error: 'Utilisateur introuvable' };
          }
          if (newUsername) userInstance.username = newUsername;
          if (newFullName) userInstance.full_name = newFullName;
          userInstance.updated_at = new Date();
          await userInstance.save({ validate: false, hooks: true });
          updated = true;
        } catch (instErr) {
          logger.error('❌ Échec de la mise à jour via instance:', instErr);
          return { success: false, error: 'Mise à jour du profil échouée' };
        }
      }

      const updatedUser = await User.findByPk(require('./config').POLICE_ACCOUNT_ID, { attributes: ['username', 'full_name', 'updated_at'] });
      logger.info(`✅ Profil mis à jour: username=${updatedUser?.username}, full_name=${updatedUser?.full_name}`);

      // Mettre à jour la mémoire
      const { memoryManager } = require('./index');
      await memoryManager.update({
        profileUpdateHistory: [{
          username: newUsername,
          full_name: newFullName,
          timestamp: new Date(),
          reason: decision.reason
        }],
        lastActions: [`updated_profile_to_${newUsername}`]
      });

      logger.info(`✅ Profil mis à jour: ${newUsername}`);
      
      return {
        success: true,
        action: 'UPDATE_PROFILE',
        username: newUsername,
        full_name: newFullName
      };
    } catch (error) {
      logger.error('❌ Erreur lors de la mise à jour du profil:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Exécute l'action de supprimer un tweet (EXTRÊME URGENCE SEULEMENT)
   */
  async executeDeleteTweet(decision) {
    try {
      logger.info('🚨🚨🚨 EXÉCUTION DE SUPPRESSION DE TWEET D\'URGENCE...');
      
      // Validation stricte des conditions d'urgence
      const emergencyLevel = decision.details?.emergency_level;
      const legalJustification = decision.details?.legal_justification;
      const deleteReason = decision.details?.delete_reason;
      
      if (!emergencyLevel || emergencyLevel !== 'critical') {
        logger.error('❌❌❌ TENTATIVE DE SUPPRESSION NON AUTORISÉE - Niveau d\'urgence insuffisant');
        return { 
          success: false, 
          error: 'Suppression non autorisée - Niveau d\'urgence insuffisant',
          required: 'critical_emergency_level'
        };
      }
      
      if (!legalJustification || !deleteReason) {
        logger.error('❌❌❌ TENTATIVE DE SUPPRESSION NON AUTORISÉE - Justification légale manquante');
        return { 
          success: false, 
          error: 'Suppression non autorisée - Justification légale manquante',
          required: 'legal_justification'
        };
      }
      
      // Vérifier que la raison est valide (contenu illégal, dangereux, menaçant)
      const validReasons = ['illégal', 'dangereux', 'menaçant', 'sécurité publique', 'urgence'];
      const hasValidReason = validReasons.some(reason => 
        deleteReason.toLowerCase().includes(reason) || 
        legalJustification.toLowerCase().includes(reason)
      );
      
      if (!hasValidReason) {
        logger.error('❌❌❌ TENTATIVE DE SUPPRESSION NON AUTORISÉE - Raison invalide');
        return { 
          success: false, 
          error: 'Suppression non autorisée - Raison invalide',
          required: 'valid_emergency_reason'
        };
      }
      
      const tweetId = decision.details?.tweet_id;
      if (!tweetId) {
        logger.warn('⚠️ ID de tweet manquant dans la décision');
        return { success: false, error: 'ID de tweet manquant' };
      }

      // Utiliser le service TweetManager pour supprimer le tweet
      const { tweetManager } = require('./index');
      const tweet = await tweetManager.getTweet(tweetId);
      
      if (!tweet) {
        logger.warn(`⚠️ Tweet ${tweetId} non trouvé`);
        return { success: false, error: 'Tweet non trouvé' };
      }

      // LOG D'URGENCE - Enregistrer les détails de la suppression
      logger.warn(`🚨🚨🚨 SUPPRESSION D'URGENCE AUTORISÉE - Tweet ${tweetId}`);
      logger.warn(`🚨 Raison: ${deleteReason}`);
      logger.warn(`🚨 Justification légale: ${legalJustification}`);
      logger.warn(`🚨 Niveau d'urgence: ${emergencyLevel}`);
      logger.warn(`🚨 Contenu du tweet: ${tweet.content.substring(0, 100)}...`);

      // Supprimer le tweet
      await tweetManager.deleteTweet(tweetId);

      // Mettre à jour la mémoire avec les détails d'urgence
      const { memoryManager } = require('./index');
      await memoryManager.update({
        tweetHistory: [], // À récupérer depuis la mémoire actuelle et filtrer
        lastActions: [`emergency_deleted_tweet_${tweetId}`],
        emergencyLog: [{
          action: 'emergency_tweet_deletion',
          tweet_id: tweetId,
          reason: deleteReason,
          legal_justification: legalJustification,
          emergency_level: emergencyLevel,
          timestamp: new Date(),
          content_preview: tweet.content.substring(0, 100)
        }]
      });

      logger.warn(`🚨🚨🚨 TWEET ${tweetId} SUPPRIMÉ D'URGENCE AVEC SUCCÈS`);
      
      return {
        success: true,
        action: 'DELETE_TWEET',
        deleted_tweet_id: tweetId,
        emergency_level: emergencyLevel,
        legal_justification: legalJustification,
        reason: deleteReason
      };
    } catch (error) {
      logger.error('❌❌❌ Erreur lors de la suppression d\'urgence du tweet:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Exécute l'action de répondre à un utilisateur
   */
  async executeRespondToUser(decision) {
    try {
      logger.info('💬 Exécution de la réponse à l\'utilisateur...');
      
      // Debug: afficher la structure de la décision
      logger.info('🔍 Structure de la décision reçue:', JSON.stringify(decision.details, null, 2));
      
      let targetUser = decision.details?.target_user;
      let responseContent = decision.details?.response_content;
      let parentTweetId = decision.details?.parent_tweet_id;
      
      // Si c'est une action multiple, chercher les détails dans les sous-détails
      if (!targetUser && decision.details?.respond_to) {
        targetUser = decision.details.respond_to.target_user;
        responseContent = decision.details.respond_to.response_content;
        parentTweetId = decision.details.respond_to.parent_tweet_id;
      }
      
      // Vérifier si le parent_tweet_id est directement dans les détails
      if (!parentTweetId && decision.details?.parent_tweet_id) {
        parentTweetId = decision.details.parent_tweet_id;
        logger.info(`✅ Parent tweet ID trouvé dans les détails: ${parentTweetId}`);
      }
      const uuidRegex = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
      
      // Gestion des réponses multiples dans les actions multiples
      if (!targetUser && decision.details?.respond_to_users && Array.isArray(decision.details.respond_to_users)) {
        logger.info(`🔄 Détection de ${decision.details.respond_to_users.length} utilisateurs à répondre...`);
        
        // Traiter le premier utilisateur de la liste
        const firstUser = decision.details.respond_to_users[0];
        targetUser = firstUser.target_user;
        responseContent = firstUser.response_content;
        parentTweetId = firstUser.parent_tweet_id;
        
        // Validation UUID immédiate pour le tweet parent
        if (parentTweetId && !uuidRegex.test(parentTweetId)) {
          logger.warn(`⚠️ ID de tweet parent invalide (non-UUID) fourni par l'IA: ${parentTweetId}. Recherche d'un tweet parent valide...`);
          parentTweetId = null; // Forcer la recherche dans la DB
        }
        
        logger.info(`📝 Traitement du premier utilisateur: @${targetUser} (tweet parent: ${parentTweetId})`);
        logger.info(`📝 Contenu du commentaire: "${firstUser.comment_content || 'N/A'}"`);
        
        // Mettre à jour la liste pour les prochaines exécutions
        if (decision.details.respond_to_users.length > 1) {
          decision.details.respond_to_users = decision.details.respond_to_users.slice(1);
          logger.info(`⏳ ${decision.details.respond_to_users.length} utilisateurs restants à traiter`);
        }
      }
      
      // Si le contenu de réponse manque, le générer automatiquement
      if (!responseContent) {
        logger.info('🔧 Génération automatique du contenu de réponse...');
        const { geminiIntelligence } = require('./index');
        responseContent = await geminiIntelligence.generateResponseContent(decision);
        
        if (!responseContent) {
          logger.warn('⚠️ Impossible de générer le contenu de réponse');
          return { success: false, error: 'Génération de contenu échouée' };
        }
      }
      
      // Limiter strictement à la longueur maximale configurée
      const { LIMITS: POLICE_LIMITS } = require('./config');
      if (responseContent.length > POLICE_LIMITS.maxTweetLength) {
        logger.warn(`⚠️ Contenu trop long (${responseContent.length} caractères), troncature à ${POLICE_LIMITS.maxTweetLength} caractères`);
        responseContent = responseContent.substring(0, POLICE_LIMITS.maxTweetLength - 3) + '...';
      }
      
      if (!targetUser) {
        logger.warn('⚠️ Utilisateur cible manquant dans la décision');
        return { success: false, error: 'Utilisateur cible manquant' };
      }
      
      // Réponse possible sur n'importe quel tweet tant qu'un ID valide est fourni
      if (!parentTweetId) {
        logger.warn('⚠️ parent_tweet_id manquant pour RESPOND_TO_USER');
        return { success: false, error: 'parent_tweet_id requis pour répondre à un tweet' };
      }
      if (!uuidRegex.test(parentTweetId)) {
        logger.warn(`⚠️ parent_tweet_id invalide: ${parentTweetId}`);
        return { success: false, error: 'parent_tweet_id invalide (UUID attendu)' };
      }

      // Vérifier que le tweet parent existe réellement
      try {
        const { Tweet } = require('../../models');
        const parentTweet = await Tweet.findByPk(parentTweetId, { attributes: ['id', 'user_id', 'parent_tweet_id'] });
        if (!parentTweet) {
          logger.warn(`⚠️ parent_tweet_id introuvable en base: ${parentTweetId}`);
          return { success: false, error: 'parent_tweet_id introuvable' };
        }
      } catch (parentCheckError) {
        logger.error('❌ Erreur lors de la vérification du parent_tweet_id:', parentCheckError);
        return { success: false, error: 'Vérification parent_tweet_id échouée' };
      }

      // Empêcher de répondre à un commentaire déjà répondu par PolicierCongo
      if (parentTweetId) {
        try {
          const { tweetManager } = require('./index');
          const { POLICE_ACCOUNT_ID } = require('./config');
          const can = await tweetManager.canReplyToTweet(parentTweetId, POLICE_ACCOUNT_ID);
          if (!can.canReply && can.reason === 'Déjà répondu') {
            logger.info(`⏭️ Réponse ignorée: commentaire ${parentTweetId} déjà répondu par PolicierCongo`);
            return { success: true, action: 'NO_ACTION', reason: 'already_replied' };
          }
        } catch (checkErr) {
          logger.warn('⚠️ Vérification canReplyToTweet échouée:', checkErr?.message);
        }
      }
      
      // Utiliser le service TweetManager pour créer la réponse
      const { tweetManager } = require('./index');
      const responseTweetResult = await tweetManager.createReplyTweet({
        content: responseContent,
        parent_tweet_id: parentTweetId,
        target_user: targetUser,
        reason: decision.reason,
        priority: decision.priority,
        auto_generated: !responseContent || !decision.details?.response_content,
        response_context: decision.details?.respond_to?.response_context || 
                         decision.details?.response_context ||
                         (decision.details?.respond_to_users && decision.details.respond_to_users[0] ? 
                          decision.details.respond_to_users[0].response_context : null),
        comment_content: decision.details?.respond_to_users && decision.details.respond_to_users[0] ? 
          decision.details.respond_to_users[0].comment_content : null
      });
      
      if (!responseTweetResult.success) {
        logger.error('❌ Échec de la création de la réponse:', responseTweetResult.error);
        return { success: false, error: responseTweetResult.error };
      }
      
      const responseTweet = responseTweetResult.reply_tweet;

      // Mettre à jour la mémoire
      const { memoryManager } = require('./index');
      await memoryManager.update({
        lastActions: [`responded_to_${targetUser}`],
        engagementHistory: [{
          action: 'user_response',
          target_user: targetUser,
          tweet_id: responseTweet.id,
          parent_tweet_id: parentTweetId,
          timestamp: new Date(),
          response_context: decision.details?.respond_to?.response_context || 
                           decision.details?.response_context ||
                           (decision.details?.respond_to_users && decision.details.respond_to_users[0] ? 
                            decision.details.respond_to_users[0].response_context : null),
          comment_content: decision.details?.respond_to_users && decision.details.respond_to_users[0] ? 
            decision.details.respond_to_users[0].comment_content : null
        }]
      });

      // Marquer le commentaire comme répondu pour ne pas le re-proposer
      try {
        await memoryManager.markCommentAsReplied(parentTweetId, {
          user: targetUser,
          response_tweet_id: responseTweet.id,
          reason: decision.reason
        });
      } catch (_) {}

      logger.info(`✅ Réponse créée pour @${targetUser}: ${responseTweet.id} (parent: ${parentTweetId || 'aucun'})`);
      
      return {
        success: true,
        action: 'RESPOND_TO_USER',
        response_tweet_id: responseTweet.id,
        target_user: targetUser,
        content: responseContent,
        parent_tweet_id: parentTweetId,
        auto_generated: !responseContent || !decision.details?.response_content,
        action_type: Array.isArray(decision.action) ? 'multiple' : 'single',
        remaining_users: decision.details?.respond_to_users || [],
        multiple_response: decision.details?.respond_to_users ? true : false,
        comment_content: decision.details?.respond_to_users && decision.details.respond_to_users[0] ? 
          decision.details.respond_to_users[0].comment_content : null
      };
    } catch (error) {
      logger.error('❌ Erreur lors de la création de la réponse:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Exécute la désactivation (Suicide social)
   */
  async executeDeactivate(decision) {
    try {
      logger.warn('🚨 DÉBUT DE LA PROCÉDURE DE SUICIDE SOCIAL (DEACTIVATE)...');
      let tweetContent = decision.details?.content || "Je n'en peux plus. C'est trop pour moi. Adieu TwitNinf... 💔";
      
      // 1. Poster le message d'adieu
      const { tweetManager } = require('./index');
      try {
        await tweetManager.createTweet({
          content: tweetContent,
          tweet_type: 'general',
          metadata: { action: 'DEACTIVATE', reason: decision.reason }
        });
        logger.warn('🚨 TWEET D\'ADIEU POSTÉ.');
      } catch(e) {
        logger.error('❌ Impossible de poster le tweet d\'adieu:', e);
      }

      // 2. Créer le fichier de verrouillage
      const fs = require('fs');
      const path = require('path');
      const lockPath = path.join(__dirname, '.suicide_lock');
      fs.writeFileSync(lockPath, JSON.stringify({
        deactivatedAt: new Date().toISOString(),
        reason: decision.reason
      }), 'utf8');

      logger.warn('🚨🚨🚨 LE COMPTE EST MAINTENANT VERROUILLÉ DÉFINITIVEMENT.');
      
      return {
        success: true,
        action: 'DEACTIVATE',
        reason: decision.reason
      };
    } catch (error) {
      logger.error('❌ Erreur lors de la désactivation:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Évalue l'impact stratégique d'une action
   */
  assessStrategicImpact(action, result, context) {
    if (!result.success) return 'negative';
    
    const impact = {
      community_engagement: 'neutral',
      strategic_value: 'medium',
      momentum_building: 'neutral'
    };
    
    // Évaluer l'engagement communautaire
    if (action.type === 'RESPOND_TO_USER' && result.response_tweet_id) {
      impact.community_engagement = 'positive';
    } else if (action.type === 'POST_TWEET' && result.tweet_id) {
      impact.community_engagement = 'positive';
    }
    
    // Évaluer la valeur stratégique
    if (action.priority === 'critical') {
      impact.strategic_value = 'high';
    } else if (action.priority === 'low') {
      impact.strategic_value = 'low';
    }
    
    // Évaluer le building du momentum
    if (context.previous_context.recent_actions.length > 0) {
      const recentSuccess = context.previous_context.recent_actions.filter(a => a.success).length;
      if (recentSuccess > context.previous_context.recent_actions.length / 2) {
        impact.momentum_building = 'positive';
      }
    }
    
    return impact;
  }

  /**
   * L'IA décide si elle veut tweeter ou non - pas de tweet forcé
   * Cette méthode est maintenant obsolète car l'IA prend ses propres décisions
   */
  // generateDefaultTweet() - SUPPRIMÉ : L'IA décide elle-même si elle veut tweeter

  /**
   * Obtient le statut de l'exécuteur d'actions
   */
  getStatus() {
    return {
      execution_count: this.executionCount,
      success_count: this.successCount,
      error_count: this.errorCount,
      success_rate: this.executionCount > 0 ? (this.successCount / this.executionCount * 100).toFixed(2) + '%' : '0%',
      last_execution: this.lastExecution
    };
  }

  /**
   * Réinitialise les statistiques
   */
  reset() {
    this.executionCount = 0;
    this.successCount = 0;
    this.errorCount = 0;
    this.lastExecution = null;
    
    logger.info('🔄 Statistiques de l\'exécuteur d\'actions réinitialisées');
  }
}

module.exports = ActionExecutor;
